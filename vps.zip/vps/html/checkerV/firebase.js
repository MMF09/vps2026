import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getDatabase, ref, set, push, onValue, remove } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBPCTP4POvfvpV2NPE2vx26FxgeHpQ_FNE",
  authDomain: "qhx2nn.firebaseapp.com",
  databaseURL: "https://qhx2nn-default-rtdb.firebaseio.com",
  projectId: "qhx2nn",
  storageBucket: "qhx2nn.firebasestorage.app",
  messagingSenderId: "244078324179",
  appId: "1:244078324179:web:7c594263b8f17b03b2e726"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
let unsubscribe = null;

const path = () => `medical_sessions/${auth.currentUser.uid}`;

export const onUser = (cb) => onAuthStateChanged(auth, cb);
export const loginEmail = (e, p) => signInWithEmailAndPassword(auth, e, p);
export const registerEmail = (e, p) => createUserWithEmailAndPassword(auth, e, p);
export const loginGoogle = () => signInWithPopup(auth, new GoogleAuthProvider());
export const logout = () => signOut(auth);

export const saveSession = (data) => set(push(ref(db, path())), data);
export const deleteSession = (key) => remove(ref(db, `${path()}/${key}`));

export function watchHistory(cb) {
  if (!auth.currentUser) return;
  if (unsubscribe) unsubscribe();
  unsubscribe = onValue(ref(db, path()), (snap) => cb(snap.val()));
}
