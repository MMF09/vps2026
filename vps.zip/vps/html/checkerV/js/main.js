import { serviceData } from './data.js';
import * as fb from './firebase.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => n.toLocaleString('vi-VN');
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icons = () => window.lucide && lucide.createIcons();
const fail = (prefix) => (err) => alert(prefix + err.message);

let cart = [];

/* ---------- Tính toán ---------- */
function compute() {
  const rate = parseFloat($('bhytRate').value);
  let rawTotal = 0, bhytCover = 0, outOfPocketExtra = 0;
  cart.forEach(i => {
    const line = i.price * i.qty;
    rawTotal += line;
    if (i.bhytApply) bhytCover += line * rate; else outOfPocketExtra += line;
  });
  return { rate, rawTotal, bhytCover, outOfPocketExtra, patientPay: rawTotal - bhytCover };
}

function calculateTotal() {
  const t = compute();
  $('rawTotal').textContent = fmt(t.rawTotal) + ' VNĐ';
  $('bhytCover').textContent = fmt(t.bhytCover) + ' VNĐ';
  $('outOfPocketExtra').textContent = fmt(t.outOfPocketExtra) + ' VNĐ';
  $('patientPay').textContent = fmt(t.patientPay) + ' VNĐ';
}

/* ---------- Giao diện ---------- */
function switchTab(tab) {
  const isCalc = tab === 'calc';
  $('calcTab').classList.toggle('hidden', !isCalc);
  $('historyTab').classList.toggle('hidden', isCalc);
  $('tabCalcBtn').classList.toggle('active', isCalc);
  $('tabHistoryBtn').classList.toggle('active', !isCalc);
}

function updateServiceOptions() {
  const cat = $('categorySelect').value;
  const sel = $('serviceSelect');
  sel.innerHTML = '<option value="">-- Chọn dịch vụ --</option>';
  (serviceData[cat] || []).forEach((item, i) => sel.add(new Option(item.name, i)));
  $('inputPrice').value = '';
}

function setSuggestedPrice() {
  const cat = $('categorySelect').value, idx = $('serviceSelect').value;
  if (cat && idx !== '') $('inputPrice').value = serviceData[cat][idx].price;
}

function addItem() {
  const cat = $('categorySelect').value, idx = $('serviceSelect').value;
  const price = parseFloat($('inputPrice').value), qty = parseInt($('inputQty').value);
  if (!cat || idx === '' || isNaN(price) || isNaN(qty) || qty <= 0)
    return alert('Vui lòng chọn dịch vụ và nhập đơn giá hợp lệ!');
  cart.push({ name: serviceData[cat][idx].name, price, qty, bhytApply: true });
  renderCart();
}

function addExtraItem() {
  const name = $('extraName').value.trim();
  const price = parseFloat($('extraPrice').value);
  if (!name || isNaN(price) || price <= 0) return alert('Vui lòng nhập tên và số tiền hợp lệ!');
  cart.push({ name: '[Phát sinh] ' + name, price, qty: 1, bhytApply: $('extraBhytApply').checked });
  $('extraName').value = '';
  $('extraPrice').value = '';
  renderCart();
}

function removeItem(index) { cart.splice(index, 1); renderCart(); }

function renderCart() {
  $('itemCount').textContent = `${cart.length} mục`;
  $('selectedList').innerHTML = cart.map((item, i) => `
    <li class="py-3 flex justify-between items-center text-sm">
      <div>
        <p class="font-medium text-slate-800">${esc(item.name)}</p>
        <p class="text-xs text-slate-500">${fmt(item.price)} đ × ${item.qty}
          ${item.bhytApply ? '<span class="text-emerald-600">(Áp BHYT)</span>' : '<span class="text-amber-600">(Tự trả 100%)</span>'}
        </p>
      </div>
      <div class="flex items-center gap-3">
        <span class="font-bold text-slate-700">${fmt(item.price * item.qty)} đ</span>
        <button onclick="removeItem(${i})" class="text-red-500 hover:text-red-700 p-1 rounded-lg hover:bg-red-50">
          <i data-lucide="trash" class="w-4 h-4"></i>
        </button>
      </div>
    </li>`).join('');
  icons();
  calculateTotal();
}

/* ---------- Lịch sử ---------- */
function renderHistory(data) {
  const el = $('historyList');
  if (!data) {
    el.innerHTML = '<p class="text-sm text-slate-500 col-span-2 text-center py-8">Chưa có lịch sử đợt khám nào.</p>';
    return;
  }
  el.innerHTML = Object.keys(data).reverse().map(key => {
    const s = data[key];
    return `
      <div class="p-4 bg-slate-50 rounded-xl border border-slate-200">
        <div class="flex justify-between items-start mb-2">
          <h4 class="font-bold text-slate-800 text-sm">${esc(s.sessionName)}</h4>
          <button onclick="deleteSession('${esc(key)}')" class="text-slate-400 hover:text-red-600 transition"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
        </div>
        <p class="text-xs text-slate-500 mb-3">${new Date(s.createdAt).toLocaleString('vi-VN')}</p>
        <div class="text-xs space-y-1 bg-white p-3 rounded-lg border border-slate-100">
          <div class="flex justify-between"><span>Tổng chi phí:</span><span>${fmt(s.rawTotal)} đ</span></div>
          <div class="flex justify-between text-emerald-600"><span>BHYT trả:</span><span>-${fmt(s.bhytCover)} đ</span></div>
          <div class="flex justify-between font-bold text-blue-600 border-t pt-1"><span>Thực trả:</span><span>${fmt(s.patientPay)} đ</span></div>
        </div>
      </div>`;
  }).join('');
  icons();
}

const loadHistory = () => fb.watchHistory(renderHistory);

function saveSession() {
  if (cart.length === 0) return alert('Vui lòng thêm ít nhất một dịch vụ!');
  const t = compute();
  const sessionName = $('sessionName').value.trim() || 'Đợt khám ' + new Date().toLocaleDateString('vi-VN');
  fb.saveSession({ sessionName, createdAt: new Date().toISOString(), cart, bhytRate: t.rate, rawTotal: t.rawTotal, bhytCover: t.bhytCover, patientPay: t.patientPay })
    .then(() => { alert('Lưu thành công!'); cart = []; renderCart(); $('sessionName').value = ''; })
    .catch(fail('Lỗi lưu: '));
}

/* ---------- Xác thực ---------- */
const credentials = () => [$('loginEmail').value.trim(), $('loginPassword').value];

function loginEmail() {
  const [e, p] = credentials();
  if (!e || !p) return alert('Vui lòng nhập email và mật khẩu!');
  fb.loginEmail(e, p).catch(fail('Lỗi đăng nhập: '));
}

function registerEmail() {
  const [e, p] = credentials();
  if (!e || p.length < 6) return alert('Email và mật khẩu (tối thiểu 6 ký tự) là bắt buộc!');
  fb.registerEmail(e, p).then(() => alert('Tạo tài khoản thành công! Đang đăng nhập...')).catch(fail('Lỗi đăng ký: '));
}

fb.onUser((user) => {
  $('authScreen').classList.toggle('hidden', !!user);
  $('appScreen').classList.toggle('hidden', !user);
  if (!user) return;
  $('userUid').textContent = user.uid.slice(0, 12) + '...';
  $('userAvatar').src = user.photoURL ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(user.email || 'U')}&background=3b82f6&color=fff`;
  icons();
  loadHistory();
});

/* ---------- Xuất ra window cho các onclick trong HTML ---------- */
Object.assign(window, {
  switchTab, updateServiceOptions, setSuggestedPrice, addItem, addExtraItem, removeItem,
  calculateTotal, loginEmail, registerEmail,
  loginGoogle: () => fb.loginGoogle().catch(fail('Lỗi Google: ')),
  logoutGoogle: () => fb.logout(),
  saveSessionToFirebase: saveSession,
  loadHistoryFromFirebase: loadHistory,
  deleteSession: (key) => confirm('Xóa đợt khám này?') && fb.deleteSession(key)
});

icons();
