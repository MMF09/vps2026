export const serviceData = {
  kham: [
    { name: "Khám chuyên khoa (Có BHYT)", price: 45000 },
    { name: "Khám theo yêu cầu", price: 200000 },
    { name: "Siêu âm ổ bụng/tuyến giáp/vú", price: 50000 },
    { name: "Chụp X-quang số hóa", price: 80000 },
    { name: "Chụp CT-Scanner (không thuốc)", price: 500000 },
    { name: "Chụp CT-Scanner (có thuốc cản quang)", price: 1200000 },
    { name: "Chụp MRI (Cộng hưởng từ)", price: 1800000 },
    { name: "Xét nghiệm dấu ấn ung thư (CEA, AFP...)", price: 150000 }
  ],
  hoatri: [
    { name: "Công truyền hóa chất/đích/miễn dịch (ngày)", price: 200000 },
    { name: "Thuốc hóa chất (Ước tính đợt)", price: 5000000 }
  ],
  giamdau: [
    { name: "Giường bệnh nội khoa/ngày (BHYT)", price: 350000 },
    { name: "Dịch vụ giảm đau/truyền dịch nâng thể trạng", price: 300000 }
  ]
};
