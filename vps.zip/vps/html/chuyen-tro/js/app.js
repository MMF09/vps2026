/**
 * Chuyển Trọ Fast - Main Application
 * Separated & Fixed version
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  getDatabase, 
  ref, 
  set, 
  push, 
  onValue, 
  off,
  remove 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

// ==================== Firebase Config ====================
const firebaseConfig = {
  apiKey: "AIzaSyAj1c-6VbwPdu22Ug5A7ygzCuxUk0zA-7E",
  authDomain: "home-521c1.firebaseapp.com",
  databaseURL: "https://home-521c1-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "home-521c1",
  storageBucket: "home-521c1.firebasestorage.app",
  messagingSenderId: "451194987727",
  appId: "1:451194987727:web:067ef92389aa85c79943ba"
};

// Khởi tạo SDK
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// ==================== Global State ====================
let currentUser = null;
let isRegisterMode = false;
let driversListener = null;
let movesListener = null;

// ==================== Toast Notification ====================
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type} text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 min-w-[250px]`;
  
  const icons = {
    success: 'check-circle',
    error: 'alert-circle',
    info: 'info'
  };
  
  toast.innerHTML = `
    <i data-lucide="${icons[type] || 'info'}" class="w-5 h-5"></i>
    <span class="text-sm font-medium">${message}</span>
  `;
  
  container.appendChild(toast);
  lucide.createIcons();
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ==================== Auth State Management ====================
onAuthStateChanged(auth, (user) => {
  currentUser = user;
  const loginModalBtn = document.getElementById('loginModalBtn');
  const userInfo = document.getElementById('userInfo');
  const userName = document.getElementById('userName');

  // Cleanup previous listeners to prevent memory leaks & duplicate renders
  cleanupListeners();

  if (user) {
    loginModalBtn.classList.add('hidden');
    userInfo.classList.remove('hidden');
    userName.textContent = user.displayName || user.email;
    closeAuthModal();
    loadUserData(user.uid);
    showToast(`Xin chào, ${user.displayName || user.email}!`, 'success');
  } else {
    loginModalBtn.classList.remove('hidden');
    userInfo.classList.add('hidden');
    document.getElementById('driversList').innerHTML = 
      `<p class="text-slate-400 col-span-full text-center py-6">Vui lòng đăng nhập để xem danh sách tài xế của bạn.</p>`;
    document.getElementById('movesList').innerHTML = 
      `<p class="text-slate-400 text-center py-6">Vui lòng đăng nhập để xem thông tin cá nhân.</p>`;
  }
});

function cleanupListeners() {
  if (driversListener) {
    off(driversListener);
    driversListener = null;
  }
  if (movesListener) {
    off(movesListener);
    movesListener = null;
  }
}

// ==================== Authentication Functions ====================
window.loginWithGoogle = async () => {
  try {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  } catch (error) {
    console.error(error);
    showToast("Lỗi đăng nhập Google: " + error.message, 'error');
  }
};

window.handleEmailAuth = async (e) => {
  e.preventDefault();
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  const submitBtn = document.getElementById('authSubmitBtn');

  if (isRegisterMode) {
    const confirmPassword = document.getElementById('authConfirmPassword').value;
    if (password !== confirmPassword) {
      showToast("Mật khẩu xác nhận không khớp!", 'error');
      return;
    }
    if (password.length < 6) {
      showToast("Mật khẩu phải có ít nhất 6 ký tự!", 'error');
      return;
    }
  }

  submitBtn.disabled = true;
  submitBtn.classList.add('btn-loading');
  submitBtn.textContent = isRegisterMode ? 'Đang đăng ký...' : 'Đang đăng nhập...';

  try {
    if (isRegisterMode) {
      await createUserWithEmailAndPassword(auth, email, password);
      showToast("Đăng ký thành công!", 'success');
    } else {
      await signInWithEmailAndPassword(auth, email, password);
      // Toast sẽ hiện ở onAuthStateChanged
    }
  } catch (error) {
    console.error(error);
    let msg = error.message;
    if (error.code === 'auth/email-already-in-use') msg = 'Email đã được sử dụng!';
    else if (error.code === 'auth/invalid-email') msg = 'Email không hợp lệ!';
    else if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
      msg = 'Email hoặc mật khẩu không đúng!';
    } else if (error.code === 'auth/weak-password') msg = 'Mật khẩu quá yếu!';
    showToast(msg, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.classList.remove('btn-loading');
    submitBtn.textContent = isRegisterMode ? 'Đăng Ký' : 'Đăng Nhập';
  }
};

window.toggleAuthMode = () => {
  isRegisterMode = !isRegisterMode;
  const title = document.getElementById('authModalTitle');
  const submitBtn = document.getElementById('authSubmitBtn');
  const toggleText = document.getElementById('toggleAuthText');
  const toggleBtn = document.getElementById('toggleAuthBtn');
  const confirmContainer = document.getElementById('confirmPasswordContainer');
  const confirmInput = document.getElementById('authConfirmPassword');

  if (isRegisterMode) {
    title.textContent = 'Đăng Ký Tài Khoản';
    submitBtn.textContent = 'Đăng Ký';
    toggleText.textContent = 'Đã có tài khoản?';
    toggleBtn.textContent = 'Đăng nhập';
    confirmContainer.classList.remove('hidden');
    confirmInput.required = true;
  } else {
    title.textContent = 'Đăng Nhập Tài Khoản';
    submitBtn.textContent = 'Đăng Nhập';
    toggleText.textContent = 'Chưa có tài khoản?';
    toggleBtn.textContent = 'Đăng ký ngay';
    confirmContainer.classList.add('hidden');
    confirmInput.required = false;
    confirmInput.value = '';
  }
};

window.logout = async () => {
  try {
    await signOut(auth);
    showToast("Đã đăng xuất thành công!", 'info');
  } catch (error) {
    showToast("Lỗi đăng xuất: " + error.message, 'error');
  }
};

// ==================== Modal Controls ====================
window.openAuthModal = () => {
  const modal = document.getElementById('authModal');
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  // Reset form
  document.getElementById('emailAuthForm').reset();
  if (isRegisterMode) toggleAuthMode(); // ensure login mode by default sometimes, but keep current
};

window.closeAuthModal = () => {
  const modal = document.getElementById('authModal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
};

window.openDriverModal = () => {
  if (!currentUser) {
    showToast("Vui lòng đăng nhập để thực hiện!", 'error');
    openAuthModal();
    return;
  }
  const modal = document.getElementById('driverModal');
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  document.getElementById('driverForm').reset();
};

window.closeDriverModal = () => {
  const modal = document.getElementById('driverModal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
};

// ==================== Data Loading (Fixed: no duplicate listeners) ====================
function loadUserData(userId) {
  // 1. Drivers
  const driversRef = ref(db, `users/${userId}/drivers`);
  driversListener = driversRef;
  
  onValue(driversRef, (snapshot) => {
    const driversList = document.getElementById('driversList');
    const data = snapshot.val();
    
    if (data) {
      // Build HTML string once (performance fix instead of += in loop)
      let html = '';
      Object.keys(data).forEach(key => {
        const driver = data[key];
        html += `
          <div class="driver-card bg-slate-50 border border-slate-200 rounded-xl p-4 flex justify-between items-start transition">
            <div>
              <h4 class="font-bold text-slate-900">${escapeHtml(driver.name)}</h4>
              <p class="text-indigo-600 font-semibold text-sm mt-0.5">
                <i data-lucide="phone" class="w-3.5 h-3.5 inline"></i> 
                <a href="tel:${escapeHtml(driver.phone)}" class="hover:underline">${escapeHtml(driver.phone)}</a>
              </p>
              <p class="text-slate-500 text-xs mt-1">Xe: ${escapeHtml(driver.vehicle)}</p>
            </div>
            <button onclick="deleteItem('drivers/${key}')" class="text-slate-400 hover:text-red-500 transition p-1" title="Xóa">
              <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
          </div>
        `;
      });
      driversList.innerHTML = html;
    } else {
      driversList.innerHTML = `<p class="text-slate-400 col-span-full text-center py-4">Chưa có tài xế nào được lưu.</p>`;
    }
    lucide.createIcons();
  }, (error) => {
    console.error("Drivers load error:", error);
    showToast("Lỗi tải danh sách tài xế", 'error');
  });

  // 2. Moves
  const movesRef = ref(db, `users/${userId}/moves`);
  movesListener = movesRef;
  
  onValue(movesRef, (snapshot) => {
    const movesList = document.getElementById('movesList');
    const data = snapshot.val();
    
    if (data) {
      // Sort by createdAt descending (newest first)
      const sortedKeys = Object.keys(data).sort((a, b) => {
        const dateA = data[a].createdAt || '';
        const dateB = data[b].createdAt || '';
        return dateB.localeCompare(dateA);
      });

      let html = '';
      sortedKeys.forEach(key => {
        const move = data[key];
        html += `
          <div class="move-card border border-slate-200 rounded-xl p-4 relative hover:border-indigo-200 transition">
            <button onclick="deleteItem('moves/${key}')" class="absolute top-4 right-4 text-slate-400 hover:text-red-500 p-1" title="Xóa">
              <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-3 pr-8">
              <p><span class="font-semibold text-slate-700">Trọ cũ:</span> ${escapeHtml(move.oldAddress)}</p>
              <p><span class="font-semibold text-slate-700">Trọ mới:</span> ${escapeHtml(move.newAddress)}</p>
              <p><span class="font-semibold text-slate-700">Thời gian thuê:</span> ${escapeHtml(move.rentalPeriod)}</p>
              <p><span class="font-semibold text-slate-700">Ngày chuyển:</span> ${escapeHtml(move.moveDate)}</p>
            </div>
            <div class="bg-slate-50 p-3 rounded-lg text-xs text-slate-600 space-y-1">
              <p><strong>Lý do chuyển:</strong> ${escapeHtml(move.reason)}</p>
              ${move.notes ? `<p><strong>Ghi chú:</strong> ${escapeHtml(move.notes)}</p>` : ''}
              ${move.createdAt ? `<p class="text-slate-400 mt-1">Lưu lúc: ${formatDate(move.createdAt)}</p>` : ''}
            </div>
          </div>
        `;
      });
      movesList.innerHTML = html;
    } else {
      movesList.innerHTML = `<p class="text-slate-400 text-center py-4">Chưa có kế hoạch chuyển trọ nào.</p>`;
    }
    lucide.createIcons();
  }, (error) => {
    console.error("Moves load error:", error);
    showToast("Lỗi tải lịch sử chuyển trọ", 'error');
  });
}

// ==================== Form Handlers ====================
window.handleDriverSubmit = async (e) => {
  e.preventDefault();
  if (!currentUser) {
    showToast("Vui lòng đăng nhập!", 'error');
    return;
  }

  const name = document.getElementById('driverName').value.trim();
  const phone = document.getElementById('driverPhone').value.trim();
  const vehicle = document.getElementById('driverVehicle').value.trim();
  const submitBtn = document.getElementById('driverSubmitBtn');

  if (!name || !phone || !vehicle) {
    showToast("Vui lòng điền đầy đủ thông tin!", 'error');
    return;
  }

  // Simple phone validation for VN
  if (!/^(0[3|5|7|8|9])+([0-9]{8})$/.test(phone) && !/^\+84[0-9]{9,10}$/.test(phone)) {
    showToast("Số điện thoại không hợp lệ (VD: 0901234567)", 'error');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Đang lưu...';

  try {
    const newDriverRef = push(ref(db, `users/${currentUser.uid}/drivers`));
    await set(newDriverRef, { 
      name, 
      phone, 
      vehicle,
      createdAt: new Date().toISOString()
    });
    closeDriverModal();
    document.getElementById('driverForm').reset();
    showToast("Đã thêm tài xế thành công!", 'success');
  } catch (error) {
    console.error(error);
    showToast("Lỗi khi lưu tài xế: " + error.message, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Lưu thông tin';
  }
};

window.handleMoveSubmit = async (e) => {
  e.preventDefault();
  if (!currentUser) {
    showToast("Vui lòng đăng nhập!", 'error');
    openAuthModal();
    return;
  }

  const submitBtn = document.getElementById('moveSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.classList.add('btn-loading');
  submitBtn.innerHTML = `<i data-lucide="loader" class="w-5 h-5 animate-spin"></i> Đang lưu...`;
  lucide.createIcons();

  try {
    const moveData = {
      oldAddress: document.getElementById('oldAddress').value.trim(),
      newAddress: document.getElementById('newAddress').value.trim(),
      rentalPeriod: document.getElementById('rentalPeriod').value.trim(),
      moveDate: document.getElementById('moveDate').value,
      reason: document.getElementById('reason').value.trim(),
      notes: document.getElementById('notes').value.trim(),
      createdAt: new Date().toISOString()
    };

    const newMoveRef = push(ref(db, `users/${currentUser.uid}/moves`));
    await set(newMoveRef, moveData);
    
    document.getElementById('moveForm').reset();
    showToast("Đã lưu kế hoạch chuyển trọ thành công!", 'success');
  } catch (error) {
    console.error(error);
    showToast("Lỗi khi lưu kế hoạch: " + error.message, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.classList.remove('btn-loading');
    submitBtn.innerHTML = `<i data-lucide="save" class="w-5 h-5"></i> Lưu Kế Hoạch Chuyển Trọ`;
    lucide.createIcons();
  }
};

// ==================== Delete ====================
window.deleteItem = async (path) => {
  if (!currentUser) {
    showToast("Vui lòng đăng nhập!", 'error');
    return;
  }
  
  if (!confirm("Bạn có chắc chắn muốn xóa mục này?")) return;

  try {
    await remove(ref(db, `users/${currentUser.uid}/${path}`));
    showToast("Đã xóa thành công!", 'success');
  } catch (error) {
    console.error(error);
    showToast("Lỗi khi xóa: " + error.message, 'error');
  }
};

// ==================== Helpers ====================
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function formatDate(isoString) {
  try {
    const date = new Date(isoString);
    return date.toLocaleString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoString;
  }
}

// ==================== Init ====================
document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  
  // Close modals on backdrop click
  document.getElementById('authModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'authModal') closeAuthModal();
  });
  document.getElementById('driverModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'driverModal') closeDriverModal();
  });
});
