# Chuyển Trọ Fast - Quản Lý Dịch Vụ Chuyển Trọ

Ứng dụng web giúp quản lý danh sách tài xế chuyển trọ và kế hoạch chuyển chỗ ở cá nhân.

## Cấu trúc thư mục (đã tách mã nguồn)

```
chuyen-tro/
├── index.html          # Cấu trúc HTML chính
├── css/
│   └── style.css       # CSS tùy chỉnh (toast, animation, hover...)
├── js/
│   └── app.js          # Toàn bộ logic JavaScript + Firebase
└── README.md           # File này
```

## Các lỗi đã được sửa (Bug Fixes)

1. **Memory Leak / Duplicate Listeners**  
   Trước đây mỗi lần login/logout đều gắn thêm `onValue` → dữ liệu bị render nhiều lần.  
   → Đã thêm `cleanupListeners()` dùng `off()` trước khi gắn listener mới.

2. **Performance khi render list**  
   Dùng `innerHTML +=` trong vòng lặp gây reflow nhiều lần.  
   → Xây dựng chuỗi HTML một lần rồi gán `innerHTML` duy nhất.

3. **Thiếu feedback cho người dùng**  
   Không có thông báo khi lưu/xóa thành công hoặc lỗi.  
   → Thêm hệ thống Toast notification đẹp.

4. **Bảo mật XSS cơ bản**  
   Dữ liệu user input được render trực tiếp.  
   → Thêm hàm `escapeHtml()` để escape trước khi đưa vào HTML.

5. **Xác nhận mật khẩu khi đăng ký**  
   Trước đây không có trường xác nhận mật khẩu.  
   → Thêm trường + validation.

6. **Validation số điện thoại**  
   Thêm kiểm tra định dạng số điện thoại Việt Nam.

7. **Sắp xếp lịch sử**  
   Danh sách kế hoạch chuyển trọ được sắp xếp mới nhất lên đầu.

8. **Loading state**  
   Nút submit có trạng thái "Đang lưu..." / disabled để tránh double-submit.

9. **Click backdrop để đóng modal**  
   UX tốt hơn.

10. **Hiển thị thời gian lưu**  
    Thêm `createdAt` và format theo tiếng Việt.

11. **Link gọi điện**  
    Số điện thoại tài xế có thể click để gọi (`tel:`).

## Cách chạy

1. Mở file `index.html` bằng trình duyệt (hoặc dùng Live Server / bất kỳ static server nào).
2. Cần kết nối internet để tải Tailwind, Lucide Icons và Firebase SDK.
3. Đăng nhập bằng Google hoặc Email/Password (Firebase Auth đã cấu hình sẵn).

## Lưu ý Firebase

- Database rules nên được cấu hình để chỉ cho phép user đọc/ghi dữ liệu của chính mình:
  ```json
  {
    "rules": {
      "users": {
        "$uid": {
          ".read": "$uid === auth.uid",
          ".write": "$uid === auth.uid"
        }
      }
    }
  }
  ```
- Domain của bạn cần được thêm vào **Authorized domains** trong Firebase Console nếu dùng Google Login trên production.

## Công nghệ sử dụng

- HTML5 + Tailwind CSS (CDN)
- Lucide Icons
- Firebase Authentication (Email + Google)
- Firebase Realtime Database
- Vanilla JavaScript (ES Modules)
