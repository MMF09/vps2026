// Cấu hình Firebase (khóa web của Firebase không phải bí mật;
// hãy bảo vệ dữ liệu bằng Database Rules - xem hướng dẫn cuối).
const firebaseConfig = {
    apiKey: "AIzaSyCrGw3XrCMnExaw66X4a5P6rN_mY_eelGw",
    authDomain: "barcarataz.firebaseapp.com",
    databaseURL: "https://barcarataz-default-rtdb.firebaseio.com",
    projectId: "barcarataz",
    storageBucket: "barcarataz.firebasestorage.app",
    messagingSenderId: "26303330608",
    appId: "1:26303330608:web:27e2ee6b5025636c8ff0f5"
};
