'use strict';

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

const $ = id => document.getElementById(id);
const state = {
    user: null, category: null, tasks: {},
    page: 1, perPage: 10,
    catRef: null, taskRef: null,
    authMode: 'login' // 'login' | 'register'
};

/* ---------- Tiện ích ---------- */
const URL_RE = /\bhttps?:\/\/[^\s<>"']+/gi;
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = s => String(s).replace(/[&<>"']/g, c => ESC[c]);

// Escape toàn bộ nội dung (chống XSS) rồi mới biến URL thành link
function linkify(text) {
    let out = '', last = 0;
    text.replace(URL_RE, (url, i) => {
        out += esc(text.slice(last, i)) +
            `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(url)}</a>`;
        last = i + url.length;
        return url;
    });
    return out + esc(text.slice(last));
}
const firstUrl = text => (text.match(URL_RE) || [null])[0];

function levenshtein(a, b) {
    let prev = Array.from({ length: a.length + 1 }, (_, i) => i);
    for (let i = 1; i <= b.length; i++) {
        const cur = [i];
        for (let j = 1; j <= a.length; j++) {
            cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[j - 1] === b[i - 1] ? 0 : 1));
        }
        prev = cur;
    }
    return prev[a.length];
}
function similarity(s1, s2) {
    s1 = s1.toLowerCase().trim(); s2 = s2.toLowerCase().trim();
    if (s1 === s2) return 100;
    const len = Math.max(s1.length, s2.length);
    return len ? Math.round(((len - levenshtein(s1, s2)) / len) * 100) : 100;
}

const openModal = id => $(id).classList.add('open');
const closeModals = () => document.querySelectorAll('.modal.open').forEach(m => {
    if (m.id !== 'login-modal') m.classList.remove('open');
});
function showBox(el, html, ms) {
    el.innerHTML = html; el.hidden = false;
    if (ms) setTimeout(() => { el.hidden = true; }, ms);
}

/* ---------- Đăng nhập Email ---------- */
const AUTH_ERRORS = {
    'auth/invalid-email': 'Email không hợp lệ.',
    'auth/missing-password': 'Vui lòng nhập mật khẩu.',
    'auth/user-not-found': 'Tài khoản không tồn tại.',
    'auth/wrong-password': 'Sai mật khẩu.',
    'auth/invalid-credential': 'Email hoặc mật khẩu không đúng.',
    'auth/email-already-in-use': 'Email này đã được đăng ký.',
    'auth/weak-password': 'Mật khẩu quá yếu (tối thiểu 6 ký tự).',
    'auth/too-many-requests': 'Thử quá nhiều lần, vui lòng đợi rồi thử lại.',
    'auth/network-request-failed': 'Lỗi mạng, hãy kiểm tra kết nối.',
    'auth/operation-not-allowed': 'Chưa bật Email/Password trong Firebase Console.'
};
function authMsg(text, ok = false) {
    const box = $('auth-message');
    box.textContent = text;
    box.classList.toggle('ok', ok);
    box.hidden = !text;
}
function setAuthMode(mode) {
    state.authMode = mode;
    const reg = mode === 'register';
    $('auth-title').textContent = reg ? 'Đăng ký' : 'Đăng nhập';
    $('auth-submit').textContent = reg ? 'Tạo tài khoản' : 'Đăng nhập';
    $('auth-toggle').textContent = reg ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký';
    $('auth-confirm').hidden = !reg;
    $('auth-forgot').hidden = reg;
    $('auth-password').autocomplete = reg ? 'new-password' : 'current-password';
    authMsg('');
}

async function handleAuthSubmit(e) {
    e.preventDefault();
    const email = $('auth-email').value.trim();
    const password = $('auth-password').value;
    if (!email || !password) return authMsg('Vui lòng nhập email và mật khẩu.');
    if (state.authMode === 'register' && password !== $('auth-confirm').value) {
        return authMsg('Mật khẩu nhập lại không khớp.');
    }
    const btn = $('auth-submit');
    btn.disabled = true; authMsg('');
    try {
        if (state.authMode === 'register') await auth.createUserWithEmailAndPassword(email, password);
        else await auth.signInWithEmailAndPassword(email, password);
        $('auth-form').reset();
    } catch (err) {
        authMsg(AUTH_ERRORS[err.code] || 'Có lỗi xảy ra: ' + err.message);
    } finally {
        btn.disabled = false;
    }
}

async function handleForgot() {
    const email = $('auth-email').value.trim();
    if (!email) return authMsg('Nhập email của bạn ở trên rồi bấm "Quên mật khẩu?".');
    try {
        await auth.sendPasswordResetEmail(email);
        authMsg('Đã gửi email đặt lại mật khẩu. Hãy kiểm tra hộp thư (cả mục Spam).', true);
    } catch (err) {
        authMsg(AUTH_ERRORS[err.code] || 'Có lỗi xảy ra: ' + err.message);
    }
}

// Đăng nhập mạng xã hội (đang ẩn trên giao diện, bật lại bằng cách bỏ "hidden" ở #social-login)
function loginWithProvider(name) {
    const providers = {
        google: firebase.auth.GoogleAuthProvider,
        facebook: firebase.auth.FacebookAuthProvider,
        twitter: firebase.auth.TwitterAuthProvider
    };
    const P = providers[name];
    if (P) auth.signInWithPopup(new P()).catch(err => authMsg(AUTH_ERRORS[err.code] || err.message));
}

auth.onAuthStateChanged(user => {
    state.user = user;
    if (user) {
        $('login-modal').classList.remove('open');
        $('user-info').textContent = '👋 ' + (user.displayName || user.email.split('@')[0]);
        loadCategories();
    } else {
        resetSession();
        $('login-modal').classList.add('open');
    }
});

function resetSession() {
    if (state.catRef) state.catRef.off();
    if (state.taskRef) state.taskRef.off();
    Object.assign(state, { category: null, tasks: {}, page: 1, catRef: null, taskRef: null });
    $('user-info').textContent = '';
    $('current-category-name').textContent = 'Chọn danh mục';
    $('category-list').innerHTML = '';
    $('task-list').innerHTML = '';
    $('pagination-bar').hidden = true;
    $('incomplete-badge').hidden = true;
}

/* ---------- Danh mục ---------- */
const userPath = () => `users/${state.user.uid}/categories`;

function openDrawer() { $('drawer-overlay').hidden = false; $('drawer').classList.add('show'); }
function closeDrawer() { $('drawer-overlay').hidden = true; $('drawer').classList.remove('show'); }

function loadCategories() {
    if (state.catRef) state.catRef.off();
    state.catRef = db.ref(userPath());
    state.catRef.on('value', snap => {
        const cats = snap.val() || {};
        if (!state.category || !cats[state.category]) {
            const first = Object.keys(cats)[0];
            if (first) selectCategory(first, cats[first].name, cats);
            else renderCategories(cats);
        } else {
            renderCategories(cats);
        }
    });
}

function renderCategories(cats) {
    const box = $('category-list');
    box.innerHTML = '';
    Object.entries(cats).forEach(([key, cat]) => {
        const div = document.createElement('div');
        div.className = 'category-item' + (state.category === key ? ' active' : '');
        div.innerHTML = `<span>${esc(cat.name)}</span><span>${state.category === key ? '✓' : ''}</span>`;
        div.onclick = () => { selectCategory(key, cat.name, cats); closeDrawer(); };
        box.appendChild(div);
    });
}

function selectCategory(key, name, cats) {
    state.category = key; state.page = 1;
    $('current-category-name').textContent = name;
    if (cats) renderCategories(cats);
    loadTasks(key);
}

function addCategory() {
    const input = $('new-category-name');
    const name = input.value.trim();
    if (!name) return;
    db.ref(userPath()).push({ name });
    input.value = '';
    closeModals();
}

/* ---------- Công việc ---------- */
function loadTasks(catId) {
    if (state.taskRef) state.taskRef.off();   // tránh rò rỉ listener khi đổi danh mục
    state.taskRef = db.ref(`${userPath()}/${catId}/tasks`);
    state.taskRef.on('value', snap => { state.tasks = snap.val() || {}; renderTasks(); });
}
const taskRef = id => db.ref(`${userPath()}/${state.category}/tasks/${id}`);

function renderTasks() {
    const box = $('task-list');
    const keys = Object.keys(state.tasks)
        .sort((a, b) => (state.tasks[b].createdAt || 0) - (state.tasks[a].createdAt || 0));

    const pending = keys.filter(k => !state.tasks[k].completed).length;
    const badge = $('incomplete-badge');
    badge.hidden = pending === 0;
    badge.textContent = pending > 99 ? '99+' : pending;

    if (!keys.length) {
        box.innerHTML = '<p class="empty">Chưa có công việc nào.</p>';
        $('pagination-bar').hidden = true;
        return;
    }

    const totalPages = Math.ceil(keys.length / state.perPage);
    state.page = Math.min(Math.max(state.page, 1), totalPages);
    const start = (state.page - 1) * state.perPage;

    box.innerHTML = keys.slice(start, start + state.perPage).map(key => {
        const t = state.tasks[key], url = firstUrl(t.title);
        return `<div class="task-item">
            <input type="checkbox" class="task-checkbox" data-id="${esc(key)}" ${t.completed ? 'checked' : ''}>
            <div class="task-content">
                <div class="task-title ${t.completed ? 'completed' : ''}">${linkify(t.title)}</div>
                <div class="task-actions">
                    ${url ? `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer" class="btn-sm btn-link-sm">🌐 Link</a>` : ''}
                    <button class="btn-sm btn-delete-sm" data-delete="${esc(key)}">Xóa</button>
                </div>
            </div>
        </div>`;
    }).join('');

    $('pagination-bar').hidden = false;
    $('page-info').textContent = `Trang ${state.page} / ${totalPages}`;
    $('btn-prev').disabled = state.page <= 1;
    $('btn-next').disabled = state.page >= totalPages;
}

function showAddTask() {
    if (!state.category) return alert('Vui lòng chọn hoặc tạo danh mục trước!');
    openModal('add-task-modal');
    $('new-task-title').focus();
}

function addTask() {
    const input = $('new-task-title');
    const title = input.value.trim();
    if (!title || !state.category) return;

    let best = { sim: 0, title: '' };
    Object.values(state.tasks).forEach(t => {
        const sim = similarity(title, t.title);
        if (sim > best.sim) best = { sim, title: t.title };
    });
    if (best.sim >= 80) {
        return showBox($('similarity-warning'), `⚠️ Trùng <strong>${best.sim}%</strong> với: "${esc(best.title)}"`);
    }

    db.ref(`${userPath()}/${state.category}/tasks`).push({ title, completed: false, createdAt: Date.now() });
    input.value = '';
    $('similarity-warning').hidden = true;
    state.page = 1;
    closeModals();
}

function checkDuplicates() {
    const tasks = Object.values(state.tasks);
    if (tasks.length < 2) return alert('Cần ít nhất 2 công việc để kiểm tra!');
    const found = [];
    for (let i = 0; i < tasks.length; i++) {
        for (let j = i + 1; j < tasks.length; j++) {
            const sim = similarity(tasks[i].title, tasks[j].title);
            if (sim >= 80) found.push({ a: tasks[i].title, b: tasks[j].title, sim });
        }
    }
    const box = $('duplicate-warning');
    if (found.length) {
        showBox(box, `<strong>Có ${found.length} cặp trùng:</strong><br>` +
            found.map(f => `• ${esc(f.a)} ~ ${esc(f.b)} (${f.sim}%)`).join('<br>'));
    } else {
        showBox(box, '✅ Không có công việc trùng lặp (≥80%)', 4000);
    }
}

/* ---------- Sự kiện ---------- */
$('auth-form').addEventListener('submit', handleAuthSubmit);
$('auth-toggle').onclick = () => setAuthMode(state.authMode === 'login' ? 'register' : 'login');
$('auth-forgot').onclick = handleForgot;
document.querySelectorAll('[data-provider]').forEach(b => b.onclick = () => loginWithProvider(b.dataset.provider));

$('btn-logout').onclick = () => auth.signOut();
$('btn-check-dup').onclick = checkDuplicates;
$('btn-save-category').onclick = addCategory;
$('btn-save-task').onclick = addTask;
$('drawer-overlay').onclick = closeDrawer;
$('new-task-title').addEventListener('keydown', e => e.key === 'Enter' && addTask());
$('new-category-name').addEventListener('keydown', e => e.key === 'Enter' && addCategory());

$('btn-prev').onclick = () => { state.page--; renderTasks(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
$('btn-next').onclick = () => { state.page++; renderTasks(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
$('items-per-page').onchange = e => { state.perPage = parseInt(e.target.value, 10); state.page = 1; renderTasks(); };

document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el) return;
    const act = el.dataset.action;
    if (act === 'open-drawer') openDrawer();
    else if (act === 'add-task') showAddTask();
    else if (act === 'close-modal') closeModals();
    else if (act === 'add-category') { closeDrawer(); openModal('add-category-modal'); $('new-category-name').focus(); }
});

// Event delegation cho danh sách công việc
$('task-list').addEventListener('change', e => {
    if (e.target.matches('.task-checkbox')) taskRef(e.target.dataset.id).update({ completed: e.target.checked });
});
$('task-list').addEventListener('click', e => {
    const id = e.target.dataset.delete;
    if (id && confirm('Xóa công việc này?')) taskRef(id).remove();
});
