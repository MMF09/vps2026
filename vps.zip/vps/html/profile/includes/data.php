<?php
/**
 * Portfolio data — fallback khi Firebase chưa load
 * Dữ liệu thật lấy từ Firebase Realtime Database
 */

$projects = [
    [
        'id' => 'taskflow',
        'title' => 'TaskFlow',
        'tag' => 'SaaS',
        'category' => 'saas',
        'desc' => 'Ứng dụng quản lý công việc realtime với board Kanban, thông báo push và báo cáo tiến độ.',
        'tech' => ['Next.js', 'TypeScript', 'Supabase', 'Tailwind'],
        'link' => '#',
        'year' => '2025'
    ],
];

$skills = [
    'PHP' => 90,
    'JavaScript' => 88,
    'TypeScript' => 82,
    'React / Next.js' => 85,
    'Node.js' => 80,
    'MySQL / PostgreSQL' => 78,
    'Tailwind CSS' => 92,
    'Docker' => 70,
    'Git' => 95,
];

$profile = [
    'name' => 'Nguyễn Đức Giang',
    'initial' => 'G',
    'titles' => [
        'Full-stack Developer',
        'Product Builder',
        'Open Source Enthusiast',
        'Clean Code Advocate',
    ],
    'bio' => 'Đam mê xây dựng sản phẩm web hiện đại, clean code và trải nghiệm người dùng tốt. Hiện đang tập trung vào các dự án open-source và SaaS.',
    'status' => 'Available for freelance & collaboration',
    'email' => 'amin@iq920.fun',
    'github' => 'https://github.com/MMF09',
    'github_label' => 'github.com/MMF09',
    'location' => 'Hà Nội, Việt Nam',
];
