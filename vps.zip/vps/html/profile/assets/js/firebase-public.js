/**
 * Public portfolio — auto login project@gmail.com
 * Path: users/{uid}/projects|skills|messages
 */
import {
    auth, db, ref, get, push,
    signInWithEmailAndPassword,
    PROJECT_EMAIL, PROJECT_PASS, userPath
} from './firebase-config.js';

const statusEl = () => document.getElementById('firebaseStatus');

async function ensureProjectAuth() {
    try {
        if (auth.currentUser && auth.currentUser.email === PROJECT_EMAIL) {
            return auth.currentUser;
        }
        const cred = await signInWithEmailAndPassword(auth, PROJECT_EMAIL, PROJECT_PASS);
        return cred.user;
    } catch (err) {
        console.warn('[Firebase] Auto-login failed:', err.code, err.message);
        if (statusEl()) {
            statusEl().textContent = 'Offline mode — dùng dữ liệu local';
            statusEl().classList.add('warn');
        }
        return null;
    }
}

function normalizeProjects(raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) {
        return raw.filter(Boolean).map((p, i) => ({
            id: p.id || 'p' + i,
            title: p.title || 'Untitled',
            tag: p.tag || 'Project',
            category: p.category || 'tool',
            desc: p.desc || p.description || '',
            tech: Array.isArray(p.tech) ? p.tech : (p.tech ? String(p.tech).split(',').map(s => s.trim()) : []),
            link: p.link || '#',
            year: p.year || ''
        }));
    }
    return Object.entries(raw).map(([key, p]) => ({
        id: p.id || key,
        title: p.title || 'Untitled',
        tag: p.tag || 'Project',
        category: p.category || 'tool',
        desc: p.desc || p.description || '',
        tech: Array.isArray(p.tech) ? p.tech : (p.tech ? String(p.tech).split(',').map(s => s.trim()) : []),
        link: p.link || '#',
        year: p.year || ''
    }));
}

function normalizeSkills(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const out = {};
    for (const [k, v] of Object.entries(raw)) {
        const n = typeof v === 'number' ? v : parseInt(v, 10);
        if (!isNaN(n)) out[k] = Math.min(100, Math.max(0, n));
    }
    return Object.keys(out).length ? out : null;
}

function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
}
function escapeAttr(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;');
}

function renderProjects(projects) {
    const grid = document.getElementById('projectGrid');
    const countEl = document.querySelector('#projects .count');
    if (!grid) return;
    if (countEl) countEl.textContent = projects.length;

    grid.innerHTML = projects.map((p, i) => `
        <article class="project-card visible" data-category="${escapeAttr(p.category)}" data-id="${escapeAttr(p.id)}" style="transition-delay: ${i * 0.06}s">
            <span class="year">${escapeHtml(p.year)}</span>
            <h3>
                ${escapeHtml(p.title)}
                <span class="tag">${escapeHtml(p.tag)}</span>
            </h3>
            <p>${escapeHtml(p.desc)}</p>
            <div class="tech-list">
                ${(p.tech || []).map(t => `<span class="tech">${escapeHtml(t)}</span>`).join('')}
            </div>
        </article>
    `).join('');

    if (window.PORTFOLIO_DATA) window.PORTFOLIO_DATA.projects = projects;
    if (typeof window.bindProjectCards === 'function') window.bindProjectCards();
}

function renderSkills(skills) {
    const grid = document.querySelector('.skills-grid');
    if (!grid || !skills) return;
    grid.innerHTML = Object.entries(skills).map(([name, pct]) => `
        <div class="skill-row">
            <span class="skill-name">${escapeHtml(name)}</span>
            <div class="skill-bar"><div class="skill-fill" data-width="${pct}" style="width:${pct}%"></div></div>
            <span class="skill-pct">${pct}%</span>
        </div>
    `).join('');
}

export async function loadPortfolioFromFirebase() {
    const user = await ensureProjectAuth();
    if (!user) return false;

    try {
        const uid = user.uid;
        const [projSnap, skillSnap] = await Promise.all([
            get(ref(db, userPath(uid, 'projects'))),
            get(ref(db, userPath(uid, 'skills')))
        ]);

        const projects = normalizeProjects(projSnap.val());
        const skills = normalizeSkills(skillSnap.val());

        if (projects.length) renderProjects(projects);
        if (skills) renderSkills(skills);

        if (statusEl()) {
            statusEl().textContent = 'Đã đồng bộ từ server';
            statusEl().classList.remove('warn');
            statusEl().classList.add('ok');
        }
        return true;
    } catch (err) {
        console.error('[Firebase] Load error:', err);
        if (statusEl()) {
            statusEl().textContent = 'Không tải được dữ liệu server';
            statusEl().classList.add('warn');
        }
        return false;
    }
}

export async function submitContactMessage(name, email, message) {
    const user = await ensureProjectAuth();
    if (!user) throw new Error('Chưa đăng nhập được server');

    const payload = {
        name: String(name).trim(),
        email: String(email).trim(),
        message: String(message).trim(),
        createdAt: Date.now(),
        read: false
    };
    await push(ref(db, userPath(user.uid, 'messages')), payload);
    return true;
}

loadPortfolioFromFirebase();
