/**
 * Nguyễn Đức Giang Portfolio — Interactive JS
 * Expects window.PORTFOLIO_DATA = { projects, titles }
 * Firebase: contact form + project cards rebind
 */

(function () {
    'use strict';

    const DATA = window.PORTFOLIO_DATA || { projects: [], titles: [] };

    // ========== THEME ==========
    const html = document.documentElement;
    const themeBtn = document.getElementById('themeBtn');
    const themeIcon = document.getElementById('themeIcon');
    const savedTheme = localStorage.getItem('theme') || 'dark';
    html.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
            updateThemeIcon(next);
        });
    }

    function updateThemeIcon(theme) {
        if (!themeIcon) return;
        if (theme === 'dark') {
            themeIcon.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
        } else {
            themeIcon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
        }
    }

    // ========== MOBILE MENU ==========
    const menuBtn = document.getElementById('menuBtn');
    const navLinks = document.getElementById('navLinks');
    if (menuBtn && navLinks) {
        menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
        document.querySelectorAll('.nav-link').forEach(a => {
            a.addEventListener('click', () => navLinks.classList.remove('open'));
        });
    }

    // ========== TYPING EFFECT ==========
    const titles = DATA.titles.length ? DATA.titles : [
        'Full-stack Developer',
        'Product Builder',
        'Open Source Enthusiast',
        'Clean Code Advocate'
    ];
    let titleIdx = 0, charIdx = 0, deleting = false;
    const typedEl = document.getElementById('typedTitle');

    function typeLoop() {
        if (!typedEl) return;
        const current = titles[titleIdx];
        if (!deleting) {
            typedEl.textContent = current.slice(0, ++charIdx);
            if (charIdx === current.length) {
                deleting = true;
                setTimeout(typeLoop, 1800);
                return;
            }
        } else {
            typedEl.textContent = current.slice(0, --charIdx);
            if (charIdx === 0) {
                deleting = false;
                titleIdx = (titleIdx + 1) % titles.length;
            }
        }
        setTimeout(typeLoop, deleting ? 40 : 70);
    }
    setTimeout(typeLoop, 600);

    // ========== SCROLL PROGRESS ==========
    const progress = document.getElementById('progress');
    window.addEventListener('scroll', () => {
        if (!progress) return;
        const h = document.documentElement;
        const pct = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
        progress.style.width = pct + '%';
    });

    // ========== INTERSECTION OBSERVER ==========
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                entry.target.querySelectorAll('.skill-fill').forEach(bar => {
                    if (!bar.style.width || bar.style.width === '0px') {
                        bar.style.width = bar.dataset.width + '%';
                    }
                });
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.fade-up, .project-card, .info-card').forEach(el => observer.observe(el));

    // ========== PROJECT FILTER ==========
    const filterBtns = document.querySelectorAll('.filter-btn');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const filter = btn.dataset.filter;
            const cards = document.querySelectorAll('.project-card');

            cards.forEach((card, i) => {
                const cat = card.dataset.category;
                const show = filter === 'all' || cat === filter;
                if (show) {
                    card.classList.remove('hidden');
                    card.style.transitionDelay = (i % 6) * 0.06 + 's';
                    card.classList.remove('visible');
                    requestAnimationFrame(() => {
                        requestAnimationFrame(() => card.classList.add('visible'));
                    });
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });

    // ========== PROJECT MODAL ==========
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modalTitle');
    const modalTag = document.getElementById('modalTag');
    const modalDesc = document.getElementById('modalDesc');
    const modalTech = document.getElementById('modalTech');
    const modalLink = document.getElementById('modalLink');

    function bindProjectCards() {
        document.querySelectorAll('.project-card').forEach(card => {
            card.onclick = () => {
                const id = card.dataset.id;
                const projects = (window.PORTFOLIO_DATA && window.PORTFOLIO_DATA.projects) || [];
                const p = projects.find(x => x.id === id);
                if (!p || !modal) return;
                modalTitle.textContent = p.title;
                modalTag.textContent = p.tag;
                modalDesc.textContent = p.desc;
                modalTech.innerHTML = (p.tech || []).map(t => `<span class="tech">${t}</span>`).join('');
                modalLink.href = p.link || '#';
                modal.classList.add('open');
                document.body.style.overflow = 'hidden';
            };
        });
    }
    window.bindProjectCards = bindProjectCards;
    bindProjectCards();

    function closeModal() {
        if (!modal) return;
        modal.classList.remove('open');
        document.body.style.overflow = '';
    }
    const modalClose = document.getElementById('modalClose');
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

    // ========== QR SCAN SIMULATION ==========
    const qrWrapper = document.getElementById('qrWrapper');
    const scanBtn = document.getElementById('scanBtn');

    function simulateScan() {
        if (!qrWrapper) return;
        qrWrapper.classList.add('scanning');
        showToast('Đang quét mã QR...');
        setTimeout(() => {
            qrWrapper.classList.remove('scanning');
            showToast('Quét thành công! Xem projects bên dưới ↓');
            const projectsEl = document.getElementById('projects');
            if (projectsEl) projectsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 2000);
    }
    if (qrWrapper) qrWrapper.addEventListener('click', simulateScan);
    if (scanBtn) scanBtn.addEventListener('click', simulateScan);

    // ========== COPY LINK ==========
    const copyLinkBtn = document.getElementById('copyLinkBtn');
    if (copyLinkBtn) {
        copyLinkBtn.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(window.location.href);
                showToast('Đã copy link trang này!');
            } catch {
                showToast('Không thể copy, hãy copy thủ công.');
            }
        });
    }

    // ========== TOAST ==========
    const toast = document.getElementById('toast');
    const toastText = document.getElementById('toastText');
    let toastTimer;
    function showToast(msg) {
        if (!toast || !toastText) return;
        toastText.textContent = msg;
        toast.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
    }
    window.showToast = showToast;

    // ========== CONTACT FORM → Firebase ==========
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const msgEl = document.getElementById('formMsg');
            const name = contactForm.name.value;
            const email = contactForm.email.value;
            const message = contactForm.message.value;
            const btn = contactForm.querySelector('button[type="submit"]');

            btn.disabled = true;
            btn.textContent = 'Đang gửi...';

            try {
                // Dynamic import to use Firebase module
                const mod = await import('./firebase-public.js');
                await mod.submitContactMessage(name, email, message);
                if (msgEl) {
                    msgEl.className = 'form-msg success';
                    msgEl.textContent = 'Cảm ơn bạn! Tin nhắn đã gửi lên server.';
                }
                contactForm.reset();
                showToast('Tin nhắn đã gửi thành công!');
            } catch (err) {
                console.error(err);
                if (msgEl) {
                    msgEl.className = 'form-msg error';
                    msgEl.textContent = 'Gửi thất bại. Thử lại sau.';
                }
                showToast('Không gửi được tin nhắn.');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Gửi tin nhắn';
            }
        });
    }

    // ========== ACTIVE NAV LINK ==========
    const sections = document.querySelectorAll('section[id], h2[id], #skills, #contact');
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(sec => {
            const top = sec.offsetTop - 120;
            if (scrollY >= top) current = sec.getAttribute('id') || sec.id;
        });
        document.querySelectorAll('.nav-link').forEach(a => {
            a.classList.toggle('active', a.getAttribute('href') === '#' + current);
        });
    });
})();
