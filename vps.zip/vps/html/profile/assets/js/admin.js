/**
 * Admin panel
 * Rules: users/$user_id — mỗi account chỉ đọc/ghi node của mình
 * Để sửa dữ liệu hiển thị trên site public → login project@gmail.com
 * admin@localhost.com quản lý node riêng của account đó
 */
import {
    auth, db, ref, get, set, push, remove, update,
    signInWithEmailAndPassword, signOut, onAuthStateChanged,
    ADMIN_EMAIL, PROJECT_EMAIL, userPath
} from './firebase-config.js';

const loginScreen = document.getElementById('loginScreen');
const adminApp = document.getElementById('adminApp');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const adminUserEmail = document.getElementById('adminUserEmail');

let projectsCache = {};
let skillsCache = {};

function uid() {
    return auth.currentUser ? auth.currentUser.uid : null;
}

function showToast(msg) {
    const t = document.getElementById('toast');
    const text = document.getElementById('toastText');
    if (!t || !text) return;
    text.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}

function showLogin() {
    loginScreen.style.display = 'flex';
    adminApp.style.display = 'none';
}

function showApp(user) {
    loginScreen.style.display = 'none';
    adminApp.style.display = 'grid';
    if (adminUserEmail) {
        const note = user.email === PROJECT_EMAIL
            ? ' (đang sửa dữ liệu site public)'
            : ' (node riêng của account này)';
        adminUserEmail.textContent = user.email + note;
    }
    loadProjects();
    loadSkills().then(() => renderSkillAnalytics());
    loadMessages();
}

onAuthStateChanged(auth, (user) => {
    if (user) {
        showApp(user);
    } else {
        showLogin();
    }
});

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.style.display = 'none';
    loginBtn.disabled = true;
    loginBtn.textContent = 'Đang đăng nhập...';
    const email = document.getElementById('adminEmail').value.trim();
    const pass = document.getElementById('adminPass').value;

    try {
        await signInWithEmailAndPassword(auth, email, pass);
        showToast('Đăng nhập thành công');
    } catch (err) {
        loginError.style.display = 'block';
        loginError.textContent = err.message || err.code || 'Đăng nhập thất bại';
    } finally {
        loginBtn.disabled = false;
        loginBtn.textContent = 'Đăng nhập';
    }
});

logoutBtn.addEventListener('click', async () => {
    await signOut(auth);
    showLogin();
});

document.querySelectorAll('.admin-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.admin-nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        const tab = document.getElementById('tab-' + btn.dataset.tab);
        if (tab) tab.classList.add('active');
        if (btn.dataset.tab === 'analytics') renderSkillAnalytics();
    });
});

// ========== PROJECTS ==========
async function loadProjects() {
    const list = document.getElementById('projectsList');
    if (!uid()) return;
    list.innerHTML = '<p class="empty-state">Đang tải...</p>';
    try {
        const snap = await get(ref(db, userPath(uid(), 'projects')));
        projectsCache = snap.val() || {};
        renderProjectsList();
    } catch (err) {
        list.innerHTML = `<p class="empty-state">Lỗi: ${err.message}</p>`;
    }
}

function renderProjectsList() {
    const list = document.getElementById('projectsList');
    const entries = Object.entries(projectsCache);
    if (!entries.length) {
        list.innerHTML = '<p class="empty-state">Chưa có project. Bấm "+ Thêm project".</p>';
        return;
    }
    list.innerHTML = entries.map(([key, p]) => `
        <div class="admin-item">
            <div class="admin-item-body">
                <h3>${esc(p.title)} <span class="tag">${esc(p.tag || '')}</span></h3>
                <p>${esc(p.desc || '').slice(0, 120)}${(p.desc || '').length > 120 ? '…' : ''}</p>
                <div class="admin-item-meta">${esc(p.category)} · ${esc(p.year || '')} · ${(p.tech || []).join(', ')}</div>
            </div>
            <div class="admin-item-actions">
                <button class="btn btn-ghost" data-edit="${key}">Sửa</button>
                <button class="btn btn-danger" data-del="${key}">Xóa</button>
            </div>
        </div>
    `).join('');

    list.querySelectorAll('[data-edit]').forEach(btn => {
        btn.addEventListener('click', () => openProjectModal(btn.dataset.edit));
    });
    list.querySelectorAll('[data-del]').forEach(btn => {
        btn.addEventListener('click', () => deleteProject(btn.dataset.del));
    });
}

function openProjectModal(key) {
    const modal = document.getElementById('projectModal');
    const title = document.getElementById('projectModalTitle');
    document.getElementById('projKey').value = key || '';

    if (key && projectsCache[key]) {
        const p = projectsCache[key];
        title.textContent = 'Sửa project';
        document.getElementById('projId').value = p.id || key;
        document.getElementById('projTitle').value = p.title || '';
        document.getElementById('projTag').value = p.tag || '';
        document.getElementById('projCategory').value = p.category || 'tool';
        document.getElementById('projYear').value = p.year || '';
        document.getElementById('projDesc').value = p.desc || '';
        document.getElementById('projTech').value = Array.isArray(p.tech) ? p.tech.join(', ') : (p.tech || '');
        document.getElementById('projLink').value = p.link || '';
    } else {
        title.textContent = 'Thêm project';
        document.getElementById('projectForm').reset();
        document.getElementById('projKey').value = '';
    }
    modal.classList.add('open');
}

document.getElementById('addProjectBtn').addEventListener('click', () => openProjectModal(null));
document.getElementById('projectModalClose').addEventListener('click', () => {
    document.getElementById('projectModal').classList.remove('open');
});
document.getElementById('projectModal').addEventListener('click', e => {
    if (e.target.id === 'projectModal') e.target.classList.remove('open');
});

document.getElementById('projectForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!uid()) return;
    const key = document.getElementById('projKey').value;
    const id = document.getElementById('projId').value.trim();
    const data = {
        id,
        title: document.getElementById('projTitle').value.trim(),
        tag: document.getElementById('projTag').value.trim(),
        category: document.getElementById('projCategory').value,
        year: document.getElementById('projYear').value.trim(),
        desc: document.getElementById('projDesc').value.trim(),
        tech: document.getElementById('projTech').value.split(',').map(s => s.trim()).filter(Boolean),
        link: document.getElementById('projLink').value.trim() || '#'
    };

    try {
        const saveKey = key || id || push(ref(db, userPath(uid(), 'projects'))).key;
        await set(ref(db, userPath(uid(), 'projects', saveKey)), data);
        projectsCache[saveKey] = data;
        renderProjectsList();
        document.getElementById('projectModal').classList.remove('open');
        showToast('Đã lưu project');
    } catch (err) {
        showToast('Lỗi: ' + err.message);
    }
});

async function deleteProject(key) {
    if (!confirm('Xóa project này?') || !uid()) return;
    try {
        await remove(ref(db, userPath(uid(), 'projects', key)));
        delete projectsCache[key];
        renderProjectsList();
        showToast('Đã xóa');
    } catch (err) {
        showToast('Lỗi: ' + err.message);
    }
}

// ========== SKILLS ==========
async function loadSkills() {
    const list = document.getElementById('skillsList');
    if (!uid()) return;
    list.innerHTML = '<p class="empty-state">Đang tải...</p>';
    try {
        const snap = await get(ref(db, userPath(uid(), 'skills')));
        skillsCache = snap.val() || {};
        renderSkillsList();
    } catch (err) {
        list.innerHTML = `<p class="empty-state">Lỗi: ${err.message}</p>`;
    }
}

function renderSkillsList() {
    const list = document.getElementById('skillsList');
    const entries = Object.entries(skillsCache);
    if (!entries.length) {
        list.innerHTML = '<p class="empty-state">Chưa có skill. Bấm "+ Thêm skill".</p>';
        return;
    }
    list.innerHTML = entries.map(([name, pct]) => `
        <div class="skill-edit-row">
            <input type="text" class="skill-name-input" value="${esc(name)}" data-old="${esc(name)}">
            <input type="number" class="skill-pct-input" min="0" max="100" value="${pct}">
            <button type="button" class="btn btn-danger skill-del" title="Xóa">×</button>
        </div>
    `).join('');

    list.querySelectorAll('.skill-del').forEach(btn => {
        btn.addEventListener('click', () => btn.closest('.skill-edit-row').remove());
    });
}

document.getElementById('addSkillBtn').addEventListener('click', () => {
    const list = document.getElementById('skillsList');
    if (list.querySelector('.empty-state')) list.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'skill-edit-row';
    row.innerHTML = `
        <input type="text" class="skill-name-input" placeholder="Tên skill" value="">
        <input type="number" class="skill-pct-input" min="0" max="100" value="50">
        <button type="button" class="btn btn-danger skill-del" title="Xóa">×</button>
    `;
    row.querySelector('.skill-del').addEventListener('click', () => row.remove());
    list.appendChild(row);
});

document.getElementById('saveSkillsBtn').addEventListener('click', async () => {
    if (!uid()) return;
    const rows = document.querySelectorAll('#skillsList .skill-edit-row');
    const data = {};
    rows.forEach(row => {
        const name = row.querySelector('.skill-name-input').value.trim();
        const pct = parseInt(row.querySelector('.skill-pct-input').value, 10);
        if (name && !isNaN(pct)) data[name] = Math.min(100, Math.max(0, pct));
    });
    try {
        await set(ref(db, userPath(uid(), 'skills')), data);
        skillsCache = data;
        showToast('Đã lưu skills');
        renderSkillAnalytics();
    } catch (err) {
        showToast('Lỗi: ' + err.message);
    }
});

// ========== MESSAGES ==========
async function loadMessages() {
    const list = document.getElementById('messagesList');
    if (!uid()) return;
    list.innerHTML = '<p class="empty-state">Đang tải...</p>';
    try {
        const snap = await get(ref(db, userPath(uid(), 'messages')));
        const raw = snap.val() || {};
        const entries = Object.entries(raw).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
        const unread = entries.filter(([, m]) => !m.read).length;
        const badge = document.getElementById('msgBadge');
        if (unread > 0) {
            badge.style.display = 'inline-block';
            badge.textContent = unread;
        } else {
            badge.style.display = 'none';
        }

        if (!entries.length) {
            list.innerHTML = '<p class="empty-state">Chưa có tin nhắn.</p>';
            return;
        }

        list.innerHTML = entries.map(([key, m]) => {
            const date = m.createdAt ? new Date(m.createdAt).toLocaleString('vi-VN') : '';
            return `
                <div class="admin-item msg-item ${m.read ? '' : 'unread'}" data-key="${key}">
                    <div class="admin-item-body">
                        <h3>${esc(m.name)} &lt;${esc(m.email)}&gt;</h3>
                        <p>${esc(m.message)}</p>
                        <div class="msg-time">${date}</div>
                    </div>
                    <div class="admin-item-actions">
                        ${!m.read ? `<button class="btn btn-ghost" data-read="${key}">Đã đọc</button>` : ''}
                        <button class="btn btn-danger" data-msgdel="${key}">Xóa</button>
                    </div>
                </div>
            `;
        }).join('');

        list.querySelectorAll('[data-read]').forEach(btn => {
            btn.addEventListener('click', async () => {
                await update(ref(db, userPath(uid(), 'messages', btn.dataset.read)), { read: true });
                loadMessages();
            });
        });
        list.querySelectorAll('[data-msgdel]').forEach(btn => {
            btn.addEventListener('click', async () => {
                if (!confirm('Xóa tin nhắn?')) return;
                await remove(ref(db, userPath(uid(), 'messages', btn.dataset.msgdel)));
                loadMessages();
                showToast('Đã xóa tin nhắn');
            });
        });
    } catch (err) {
        list.innerHTML = `<p class="empty-state">Lỗi: ${err.message}</p>`;
    }
}

document.getElementById('refreshMsgBtn').addEventListener('click', loadMessages);

function esc(s) {
    const d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
}


// ========== SKILL ANALYTICS (Chart.js) ==========
let chartBars = null;
let chartDoughnut = null;
let chartRadar = null;

function skillLevel(pct) {
    if (pct >= 90) return { key: 'expert', label: 'Expert', cls: 'level-expert' };
    if (pct >= 70) return { key: 'advanced', label: 'Advanced', cls: 'level-advanced' };
    if (pct >= 50) return { key: 'intermediate', label: 'Intermediate', cls: 'level-intermediate' };
    return { key: 'beginner', label: 'Beginner', cls: 'level-beginner' };
}

function computeSkillStats(entries) {
    if (!entries.length) {
        return { count: 0, avg: 0, max: 0, min: 0, std: 0, median: 0, sorted: [] };
    }
    const vals = entries.map(([, v]) => Number(v)).filter(n => !isNaN(n));
    const count = vals.length;
    const sum = vals.reduce((a, b) => a + b, 0);
    const avg = sum / count;
    const max = Math.max(...vals);
    const min = Math.min(...vals);
    const variance = vals.reduce((a, b) => a + (b - avg) ** 2, 0) / count;
    const std = Math.sqrt(variance);
    const sortedVals = [...vals].sort((a, b) => a - b);
    const mid = Math.floor(count / 2);
    const median = count % 2 ? sortedVals[mid] : (sortedVals[mid - 1] + sortedVals[mid]) / 2;
    const sorted = entries
        .map(([name, pct]) => [name, Number(pct)])
        .filter(([, n]) => !isNaN(n))
        .sort((a, b) => b[1] - a[1]);
    return { count, avg, max, min, std, median, sorted };
}

function chartColors() {
    const dark = document.documentElement.getAttribute('data-theme') !== 'light';
    return {
        text: dark ? '#9b9baf' : '#5a5a70',
        grid: dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)',
        accent: '#8b6cff',
        accentSoft: 'rgba(139, 108, 255, 0.35)',
        tiers: {
            expert: '#34d399',
            advanced: '#a78bfa',
            intermediate: '#fbbf24',
            beginner: '#f87171'
        }
    };
}

function destroyCharts() {
    [chartBars, chartDoughnut, chartRadar].forEach(c => {
        if (c) try { c.destroy(); } catch (_) {}
    });
    chartBars = chartDoughnut = chartRadar = null;
}

function renderSkillAnalytics() {
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js chưa load');
        return;
    }
    const entries = Object.entries(skillsCache || {});
    const stats = computeSkillStats(entries);
    const colors = chartColors();

    const fmt = (n, d = 1) => stats.count ? n.toFixed(d) : '—';
    const el = id => document.getElementById(id);
    if (el('statCount')) el('statCount').textContent = stats.count || '—';
    if (el('statAvg')) el('statAvg').textContent = stats.count ? fmt(stats.avg) + '%' : '—';
    if (el('statMax')) el('statMax').textContent = stats.count ? Math.round(stats.max) + '%' : '—';
    if (el('statMin')) el('statMin').textContent = stats.count ? Math.round(stats.min) + '%' : '—';
    if (el('statStd')) el('statStd').textContent = stats.count ? fmt(stats.std) : '—';
    if (el('statMedian')) el('statMedian').textContent = stats.count ? fmt(stats.median) + '%' : '—';

    const tbody = document.getElementById('skillsRankBody');
    if (tbody) {
        if (!stats.sorted.length) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">Chưa có dữ liệu skill</td></tr>';
        } else {
            tbody.innerHTML = stats.sorted.map(([name, pct], i) => {
                const lv = skillLevel(pct);
                const diff = pct - stats.avg;
                const diffCls = diff > 0.5 ? 'diff-up' : diff < -0.5 ? 'diff-down' : 'diff-same';
                const diffTxt = (diff >= 0 ? '+' : '') + diff.toFixed(1) + '%';
                return `<tr>
                    <td>${i + 1}</td>
                    <td><strong>${esc(name)}</strong></td>
                    <td>${Math.round(pct)}%</td>
                    <td><span class="level-badge ${lv.cls}">${lv.label}</span></td>
                    <td class="${diffCls}">${diffTxt}</td>
                    <td><div class="mini-bar"><span style="width:${Math.min(100, pct)}%"></span></div></td>
                </tr>`;
            }).join('');
        }
    }

    if (!stats.sorted.length) {
        destroyCharts();
        return;
    }

    destroyCharts();

    const labels = stats.sorted.map(([n]) => n);
    const values = stats.sorted.map(([, v]) => v);
    const barColors = values.map(v => colors.tiers[skillLevel(v).key]);

    const ctxBars = document.getElementById('chartBars');
    if (ctxBars) {
        chartBars = new Chart(ctxBars, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Mức %',
                    data: values,
                    backgroundColor: barColors.map(c => c + 'cc'),
                    borderColor: barColors,
                    borderWidth: 1,
                    borderRadius: 6,
                    barThickness: Math.max(12, Math.min(28, 320 / Math.max(1, labels.length)))
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            afterLabel: (ctx) => {
                                const lv = skillLevel(ctx.raw);
                                return `Cấp: ${lv.label} · Δ TB: ${(ctx.raw - stats.avg >= 0 ? '+' : '')}${(ctx.raw - stats.avg).toFixed(1)}%`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        min: 0,
                        max: 100,
                        ticks: { color: colors.text, callback: v => v + '%' },
                        grid: { color: colors.grid }
                    },
                    y: {
                        ticks: { color: colors.text, font: { size: 11 } },
                        grid: { display: false }
                    }
                }
            }
        });
    }

    const tierCount = { expert: 0, advanced: 0, intermediate: 0, beginner: 0 };
    values.forEach(v => { tierCount[skillLevel(v).key]++; });
    const ctxDoughnut = document.getElementById('chartDoughnut');
    if (ctxDoughnut) {
        chartDoughnut = new Chart(ctxDoughnut, {
            type: 'doughnut',
            data: {
                labels: ['Expert (≥90)', 'Advanced (70–89)', 'Intermediate (50–69)', 'Beginner (<50)'],
                datasets: [{
                    data: [tierCount.expert, tierCount.advanced, tierCount.intermediate, tierCount.beginner],
                    backgroundColor: [
                        colors.tiers.expert + 'dd',
                        colors.tiers.advanced + 'dd',
                        colors.tiers.intermediate + 'dd',
                        colors.tiers.beginner + 'dd'
                    ],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: colors.text, boxWidth: 12, padding: 14, font: { size: 11 } }
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => {
                                const n = ctx.raw;
                                const pct = stats.count ? ((n / stats.count) * 100).toFixed(1) : 0;
                                return ` ${ctx.label}: ${n} skill (${pct}%)`;
                            }
                        }
                    }
                },
                cutout: '58%'
            }
        });
    }

    const top = stats.sorted.slice(0, 12);
    const ctxRadar = document.getElementById('chartRadar');
    if (ctxRadar) {
        chartRadar = new Chart(ctxRadar, {
            type: 'radar',
            data: {
                labels: top.map(([n]) => n.length > 14 ? n.slice(0, 12) + '…' : n),
                datasets: [{
                    label: 'Mức %',
                    data: top.map(([, v]) => v),
                    backgroundColor: colors.accentSoft,
                    borderColor: colors.accent,
                    borderWidth: 2,
                    pointBackgroundColor: colors.accent,
                    pointRadius: 3,
                    pointHoverRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    r: {
                        min: 0,
                        max: 100,
                        ticks: {
                            stepSize: 20,
                            color: colors.text,
                            backdropColor: 'transparent',
                            font: { size: 10 }
                        },
                        pointLabels: { color: colors.text, font: { size: 10 } },
                        grid: { color: colors.grid },
                        angleLines: { color: colors.grid }
                    }
                }
            }
        });
    }
}

const refreshAnalyticsBtn = document.getElementById('refreshAnalyticsBtn');
if (refreshAnalyticsBtn) {
    refreshAnalyticsBtn.addEventListener('click', () => {
        loadSkills().then(() => {
            renderSkillAnalytics();
            showToast('Đã làm mới biểu đồ');
        });
    });
}

