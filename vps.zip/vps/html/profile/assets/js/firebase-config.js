/**
 * Firebase configuration & helpers
 * Data path: users/{auth.uid}/projects|skills|messages
 * Rules: chỉ user đó đọc/ghi node của mình
 */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
    getAuth,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
    getDatabase,
    ref,
    get,
    set,
    push,
    remove,
    update,
    onValue
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js';

const firebaseConfig = {
    apiKey: 'AIzaSyB_fB6fPUZH4uJVpK9pzkjs7DP07kNW2MU',
    authDomain: 'vlbaovework.firebaseapp.com',
    databaseURL: 'https://vlbaovework-default-rtdb.firebaseio.com',
    projectId: 'vlbaovework',
    storageBucket: 'vlbaovework.firebasestorage.app',
    messagingSenderId: '478788881372',
    appId: '1:478788881372:web:f11973081d15590a0c9d19'
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

/** Tài khoản public (auto-login) — dữ liệu nằm tại users/{uid}/ */
const PROJECT_EMAIL = 'project@gmail.com';
const PROJECT_PASS = '123456';

/**
 * Admin login.
 * Với rules users/$user_id: để sửa cùng dữ liệu với trang public,
 * nên đăng nhập bằng project@gmail.com (cùng uid).
 * admin@localhost.com chỉ quản lý node của chính account đó.
 */
const ADMIN_EMAIL = 'admin@localhost.com';

/** Đường dẫn dữ liệu theo uid đang đăng nhập */
function userPath(uid, ...segments) {
    return ['users', uid, ...segments].join('/');
}

export {
    app,
    auth,
    db,
    ref,
    get,
    set,
    push,
    remove,
    update,
    onValue,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    PROJECT_EMAIL,
    PROJECT_PASS,
    ADMIN_EMAIL,
    userPath
};
