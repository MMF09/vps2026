<?php
/**
 * Admin panel — login admin@localhost.com
 * Quản lý Projects, Skills, xem Messages từ Firebase
 */
?>
<!DOCTYPE html>
<html lang="vi" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Portfolio</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body class="admin-body">
    <div id="loginScreen" class="login-screen">
        <div class="login-card">
            <h1>Admin Panel</h1>
            <p class="login-sub">Login project@gmail.com để sửa dữ liệu site public (theo rules users/$uid)</p>
            <form id="loginForm">
                <div class="form-group">
                    <label for="adminEmail">Email</label>
                    <input type="email" id="adminEmail" required placeholder="project@gmail.com hoặc admin@..." value="project@gmail.com">
                </div>
                <div class="form-group">
                    <label for="adminPass">Password</label>
                    <input type="password" id="adminPass" required placeholder="••••••••">
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center" id="loginBtn">
                    Đăng nhập
                </button>
                <p class="form-msg error" id="loginError" style="display:none"></p>
            </form>
            <p class="login-hint"><a href="index.php">← Về trang portfolio</a></p>
        </div>
    </div>

    <div id="adminApp" class="admin-app" style="display:none">
        <aside class="admin-sidebar">
            <div class="admin-brand">NDG <span>Admin</span></div>
            <nav class="admin-nav">
                <button class="admin-nav-btn active" data-tab="projects">Projects</button>
                <button class="admin-nav-btn" data-tab="skills">Skills</button>
                <button class="admin-nav-btn" data-tab="analytics">Phân tích Skills</button>
                <button class="admin-nav-btn" data-tab="messages">Messages <span id="msgBadge" class="badge" style="display:none">0</span></button>
            </nav>
            <div class="admin-sidebar-footer">
                <p id="adminUserEmail" class="admin-user"></p>
                <button class="btn btn-ghost" id="logoutBtn" style="width:100%;justify-content:center">Đăng xuất</button>
                <a href="index.php" class="btn btn-ghost" style="width:100%;justify-content:center;margin-top:0.5rem;text-decoration:none">Xem site</a>
            </div>
        </aside>

        <main class="admin-main">
            <!-- Projects tab -->
            <section id="tab-projects" class="admin-tab active">
                <div class="admin-header">
                    <h2>Quản lý Projects</h2>
                    <button class="btn btn-primary" id="addProjectBtn">+ Thêm project</button>
                </div>
                <div id="projectsList" class="admin-list"></div>
            </section>

            <!-- Skills tab -->
            <section id="tab-skills" class="admin-tab">
                <div class="admin-header">
                    <h2>Quản lý Skills</h2>
                    <button class="btn btn-primary" id="addSkillBtn">+ Thêm skill</button>
                </div>
                <div id="skillsList" class="admin-list"></div>
                <button class="btn btn-primary" id="saveSkillsBtn" style="margin-top:1rem">Lưu tất cả skills</button>
            </section>


            <!-- Analytics tab -->
            <section id="tab-analytics" class="admin-tab">
                <div class="admin-header">
                    <h2>Phân tích kỹ năng</h2>
                    <button class="btn btn-ghost" id="refreshAnalyticsBtn">Làm mới biểu đồ</button>
                </div>

                <div class="analytics-stats" id="skillStats">
                    <div class="stat-card"><div class="stat-label">Số kỹ năng</div><div class="stat-value" id="statCount">—</div></div>
                    <div class="stat-card"><div class="stat-label">Trung bình</div><div class="stat-value" id="statAvg">—</div></div>
                    <div class="stat-card"><div class="stat-label">Cao nhất</div><div class="stat-value" id="statMax">—</div></div>
                    <div class="stat-card"><div class="stat-label">Thấp nhất</div><div class="stat-value" id="statMin">—</div></div>
                    <div class="stat-card"><div class="stat-label">Độ lệch chuẩn</div><div class="stat-value" id="statStd">—</div></div>
                    <div class="stat-card"><div class="stat-label">Trung vị</div><div class="stat-value" id="statMedian">—</div></div>
                </div>

                <div class="analytics-grid">
                    <div class="chart-card chart-wide">
                        <h3>Mức thành thạo từng kỹ năng</h3>
                        <p class="chart-desc">Biểu đồ cột ngang — so sánh % giữa các skill</p>
                        <div class="chart-wrap chart-wrap-tall">
                            <canvas id="chartBars"></canvas>
                        </div>
                    </div>
                    <div class="chart-card">
                        <h3>Phân bố theo cấp độ</h3>
                        <p class="chart-desc">Expert ≥90 · Advanced 70–89 · Intermediate 50–69 · Beginner &lt;50</p>
                        <div class="chart-wrap">
                            <canvas id="chartDoughnut"></canvas>
                        </div>
                    </div>
                    <div class="chart-card">
                        <h3>Radar tổng quan</h3>
                        <p class="chart-desc">Nhìn tổng thể cân bằng kỹ năng (tối đa 12 skill mạnh nhất)</p>
                        <div class="chart-wrap">
                            <canvas id="chartRadar"></canvas>
                        </div>
                    </div>
                    <div class="chart-card chart-wide">
                        <h3>Bảng chi tiết &amp; xếp hạng</h3>
                        <div class="table-wrap">
                            <table class="analytics-table" id="skillsRankTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Kỹ năng</th>
                                        <th>Mức %</th>
                                        <th>Cấp độ</th>
                                        <th>So với TB</th>
                                        <th>Thanh</th>
                                    </tr>
                                </thead>
                                <tbody id="skillsRankBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Messages tab -->
            <section id="tab-messages" class="admin-tab">
                <div class="admin-header">
                    <h2>Tin nhắn liên hệ</h2>
                    <button class="btn btn-ghost" id="refreshMsgBtn">Làm mới</button>
                </div>
                <div id="messagesList" class="admin-list"></div>
            </section>
        </main>
    </div>

    <!-- Project edit modal -->
    <div class="modal-overlay" id="projectModal">
        <div class="modal" style="max-width:560px">
            <button class="modal-close" id="projectModalClose">&times;</button>
            <h2 id="projectModalTitle">Thêm project</h2>
            <form id="projectForm">
                <input type="hidden" id="projKey">
                <div class="form-group">
                    <label>ID (slug)</label>
                    <input type="text" id="projId" required placeholder="taskflow">
                </div>
                <div class="form-group">
                    <label>Tiêu đề</label>
                    <input type="text" id="projTitle" required placeholder="TaskFlow">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Tag</label>
                        <input type="text" id="projTag" required placeholder="SaaS">
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <select id="projCategory">
                            <option value="saas">saas</option>
                            <option value="opensource">opensource</option>
                            <option value="tool">tool</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Năm</label>
                        <input type="text" id="projYear" placeholder="2025">
                    </div>
                </div>
                <div class="form-group">
                    <label>Mô tả</label>
                    <textarea id="projDesc" required rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Tech (phân cách bằng dấu phẩy)</label>
                    <input type="text" id="projTech" placeholder="PHP, JavaScript, MySQL">
                </div>
                <div class="form-group">
                    <label>Link</label>
                    <input type="url" id="projLink" placeholder="https://...">
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Lưu project</button>
            </form>
        </div>
    </div>

    <div class="toast" id="toast">
        <span id="toastText"></span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script type="module" src="assets/js/admin.js"></script>
</body>
</html>
