<?php
/**
 * Nguyễn Đức Giang — Interactive Portfolio
 * Pure PHP + Vanilla HTML/CSS/JS + Firebase Realtime DB
 */
require_once __DIR__ . '/includes/data.php';
?>
<!DOCTYPE html>
<html lang="vi" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($profile['name']) ?> | Portfolio</title>
    <meta name="description" content="Portfolio của <?= htmlspecialchars($profile['name']) ?> - Full-stack Developer.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        #firebaseStatus {
            position: fixed; bottom: 1rem; left: 1rem; z-index: 90;
            font-size: 0.75rem; padding: 0.35rem 0.75rem; border-radius: 8px;
            background: var(--bg-card); border: 1px solid var(--border);
            color: var(--text-muted); opacity: 0.85;
        }
        #firebaseStatus.ok { color: var(--success); border-color: rgba(52,211,153,0.3); }
        #firebaseStatus.warn { color: #fbbf24; border-color: rgba(251,191,36,0.3); }
    </style>
</head>
<body>
    <div id="progress"></div>
    <div class="bg-grid"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    <div id="firebaseStatus">Đang kết nối server…</div>

    <div class="container">
        <nav>
            <div class="nav-inner">
                <a href="#" class="logo">ND<span>G</span></a>
                <ul class="nav-links" id="navLinks">
                    <li><a href="#qr" class="nav-link">QR Code</a></li>
                    <li><a href="#projects" class="nav-link">Projects</a></li>
                    <li><a href="#skills" class="nav-link">Skills</a></li>
                    <li><a href="#contact" class="nav-link">Contact</a></li>
                </ul>
                <div class="nav-actions">
                    <button class="theme-btn" id="themeBtn" aria-label="Toggle theme" title="Đổi giao diện">
                        <svg id="themeIcon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                        </svg>
                    </button>
                    <button class="menu-btn" id="menuBtn" aria-label="Menu">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
                        </svg>
                    </button>
                </div>
            </div>
        </nav>

        <header class="fade-up">
            <div class="avatar-wrap">
                <div class="avatar-ring"></div>
                <div class="avatar"><?= htmlspecialchars($profile['initial']) ?></div>
            </div>
            <h1><?= htmlspecialchars($profile['name']) ?></h1>
            <div class="title-wrap">
                <span class="title" id="typedTitle"></span><span class="cursor-blink"></span>
            </div>
            <p class="bio"><?= htmlspecialchars($profile['bio']) ?></p>
            <div class="status"><?= htmlspecialchars($profile['status']) ?></div>
        </header>

        <section class="qr-section fade-up" id="qr">
            <div class="qr-card">
                <div class="qr-label">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                        <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="3" height="3"/>
                        <path d="M18 14h3v3"/><path d="M14 18h3v3"/>
                    </svg>
                    Scan to explore projects
                </div>
                <div class="qr-wrapper" id="qrWrapper" title="Click để mô phỏng quét">
                    <div class="qr-scan-line"></div>
                    <?php
                    $qrPath = __DIR__ . '/qr.svg';
                    if (file_exists($qrPath)) {
                        echo file_get_contents($qrPath);
                    } else {
                        echo '<p style="color:#000;padding:2rem;">QR not found</p>';
                    }
                    ?>
                </div>
                <p class="qr-hint">
                    Quét mã QR hoặc click để xem <strong>danh sách dự án</strong>
                </p>
                <div class="qr-actions">
                    <button class="btn btn-primary" id="scanBtn">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/>
                            <path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/>
                            <rect x="7" y="7" width="10" height="10"/>
                        </svg>
                        Mô phỏng quét
                    </button>
                    <button class="btn btn-ghost" id="copyLinkBtn">Copy link</button>
                </div>
            </div>
        </section>

        <h2 class="section-title fade-up" id="projects">
            Featured Projects
            <span class="count"><?= count($projects) ?></span>
        </h2>
        <div class="filters fade-up">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="saas">SaaS</button>
            <button class="filter-btn" data-filter="opensource">Open Source</button>
            <button class="filter-btn" data-filter="tool">Tools</button>
        </div>
        <div class="projects" id="projectGrid">
            <?php foreach ($projects as $i => $p): ?>
            <article class="project-card" data-category="<?= htmlspecialchars($p['category']) ?>" data-id="<?= htmlspecialchars($p['id']) ?>" style="transition-delay: <?= $i * 0.08 ?>s">
                <span class="year"><?= htmlspecialchars($p['year']) ?></span>
                <h3>
                    <?= htmlspecialchars($p['title']) ?>
                    <span class="tag"><?= htmlspecialchars($p['tag']) ?></span>
                </h3>
                <p><?= htmlspecialchars($p['desc']) ?></p>
                <div class="tech-list">
                    <?php foreach ($p['tech'] as $t): ?>
                    <span class="tech"><?= htmlspecialchars($t) ?></span>
                    <?php endforeach; ?>
                </div>
            </article>
            <?php endforeach; ?>
        </div>

        <div class="grid-2" id="skills">
            <div class="info-card">
                <h3>Tech Stack</h3>
                <div class="skills-grid">
                    <?php foreach ($skills as $name => $pct): ?>
                    <div class="skill-row">
                        <span class="skill-name"><?= htmlspecialchars($name) ?></span>
                        <div class="skill-bar"><div class="skill-fill" data-width="<?= (int)$pct ?>"></div></div>
                        <span class="skill-pct"><?= (int)$pct ?>%</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="info-card" id="contact">
                <h3>Liên hệ nhanh</h3>
                <form id="contactForm" method="post" action="">
                    <div class="form-group">
                        <label for="name">Tên của bạn</label>
                        <input type="text" id="name" name="name" required placeholder="Nguyễn Văn A">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required placeholder="you@email.com">
                    </div>
                    <div class="form-group">
                        <label for="message">Tin nhắn</label>
                        <textarea id="message" name="message" required placeholder="Xin chào Giang, mình muốn..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">
                        Gửi tin nhắn
                    </button>
                    <div class="form-msg" id="formMsg"></div>
                </form>
                <ul class="contact-list" style="margin-top:1.5rem;border-top:1px solid var(--border);padding-top:1rem">
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <a href="mailto:<?= htmlspecialchars($profile['email']) ?>"><?= htmlspecialchars($profile['email']) ?></a>
                    </li>
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>
                        <a href="<?= htmlspecialchars($profile['github']) ?>" target="_blank" rel="noopener"><?= htmlspecialchars($profile['github_label']) ?></a>
                    </li>
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <?= htmlspecialchars($profile['location']) ?>
                    </li>
                </ul>
            </div>
        </div>

        <footer>
            <p>© <?= date('Y') ?> <?= htmlspecialchars($profile['name']) ?></p>
        </footer>
    </div>

    <div class="modal-overlay" id="modal">
        <div class="modal">
            <button class="modal-close" id="modalClose" aria-label="Đóng">&times;</button>
            <h2 id="modalTitle"></h2>
            <span class="tag" id="modalTag"></span>
            <p id="modalDesc"></p>
            <div class="tech-list" id="modalTech"></div>
            <a href="#" class="btn btn-primary" id="modalLink" target="_blank" rel="noopener">Xem dự án →</a>
        </div>
    </div>

    <div class="toast" id="toast">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        <span id="toastText">Đã copy link!</span>
    </div>

    <script>
        window.PORTFOLIO_DATA = {
            projects: <?= json_encode($projects, JSON_UNESCAPED_UNICODE) ?>,
            titles: <?= json_encode($profile['titles'], JSON_UNESCAPED_UNICODE) ?>
        };
    </script>
    <script src="assets/js/main.js"></script>
    <script type="module" src="assets/js/firebase-public.js"></script>
</body>
</html>
