# Firebase Setup — Portfolio NDG

## Database Rules (dùng đúng rules bạn cung cấp)

```json
{
  "rules": {
    "users": {
      "$user_id": {
        ".read": "$user_id === auth.uid",
        ".write": "$user_id === auth.uid"
      }
    }
  }
}
```

Mỗi user chỉ đọc/ghi được node `users/{uid}/` của chính mình.

## Cấu trúc dữ liệu

```
users/
  {uid-của-project@gmail.com}/
    projects/
      taskflow/
        id, title, tag, category, desc, tech[], link, year
      ...
    skills/
      PHP: 90
      JavaScript: 88
      ...
    messages/
      -Nabc123/
        name, email, message, createdAt, read
```

## Tài khoản Authentication

1. **project@gmail.com** / `123456`  
   - Auto-login trên trang public  
   - **Đăng nhập Admin bằng account này** để sửa projects/skills/messages hiển thị trên site

2. **admin@localhost.com** (optional)  
   - Có thể login Admin nhưng dữ liệu nằm ở uid riêng, **không** trùng với site public

## Luồng hoạt động

| Trang | Account | Hành động |
|-------|---------|-----------|
| `index.php` | auto `project@gmail.com` | Đọc projects/skills, ghi messages |
| `admin.php` | login `project@gmail.com` | CRUD cùng node → site cập nhật |

## Chạy

```bash
php -S localhost:8000
```

- Portfolio: http://localhost:8000/
- Admin: http://localhost:8000/admin.php
