// ========== FIREBASE CONFIG ==========
const firebaseConfig = {
  apiKey: "AIzaSyC3eiZy3Jxltpx-QXKFx-WNUlKdNLhBH2I",
  authDomain: "bigdata-c9bd2.firebaseapp.com",
  databaseURL: "https://bigdata-c9bd2-default-rtdb.firebaseio.com",
  projectId: "bigdata-c9bd2",
  storageBucket: "bigdata-c9bd2.firebasestorage.app",
  messagingSenderId: "168926822259",
  appId: "1:168926822259:web:b308949b6878d9a4958f06"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();
const storage = firebase.storage();

// ========== DOM ==========
const authSection = document.getElementById('auth-section');
const userInfo = document.getElementById('user-info');
const userAvatar = document.getElementById('user-avatar');
const userName = document.getElementById('user-name');
const btnLogout = document.getElementById('btn-logout');
const formSection = document.getElementById('form-section');
const listSection = document.getElementById('list-section');
const rentalForm = document.getElementById('rental-form');
const listingsContainer = document.getElementById('listings-container');
const btnAdd = document.getElementById('btn-add');
const btnAddEmpty = document.getElementById('btn-add-empty');
const btnCancel = document.getElementById('btn-cancel');
const btnBack = document.getElementById('btn-back');
const btnChangeAvatar = document.getElementById('btn-change-avatar');
const changeAvatarInput = document.getElementById('change-avatar-input');
const formTitle = document.getElementById('form-title');
const listingCount = document.getElementById('listing-count');

const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const regAvatarInput = document.getElementById('reg-avatar');
const regAvatarPreview = document.getElementById('reg-avatar-preview');
const authTitle = document.getElementById('auth-title');
const authDesc = document.getElementById('auth-desc');

let currentUser = null;
let editId = null;
let selectedAvatarFile = null;
let listingsListener = null;

const DEFAULT_AVATAR = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='70'>👤</text></svg>";

// ========== AUTH TABS ==========
tabLogin.addEventListener('click', () => {
  tabLogin.classList.add('active');
  tabRegister.classList.remove('active');
  loginForm.classList.remove('hidden');
  registerForm.classList.add('hidden');
  authTitle.textContent = 'Đăng nhập';
  authDesc.textContent = 'Quản lý toàn bộ phòng trọ của bạn ở một nơi';
});

tabRegister.addEventListener('click', () => {
  tabRegister.classList.add('active');
  tabLogin.classList.remove('active');
  registerForm.classList.remove('hidden');
  loginForm.classList.add('hidden');
  authTitle.textContent = 'Đăng ký';
  authDesc.textContent = 'Tạo tài khoản để bắt đầu quản lý phòng trọ';
});

// Preview avatar khi chọn file đăng ký
regAvatarInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    selectedAvatarFile = file;
    const reader = new FileReader();
    reader.onload = (ev) => {
      regAvatarPreview.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  }
});

// ========== ĐĂNG NHẬP ==========
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  errorEl.classList.add('hidden');

  try {
    await auth.signInWithEmailAndPassword(email, password);
  } catch (err) {
    errorEl.textContent = 'Lỗi: ' + err.message;
    errorEl.classList.remove('hidden');
  }
});

// ========== ĐĂNG KÝ ==========
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const errorEl = document.getElementById('register-error');
  errorEl.classList.add('hidden');

  try {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    const user = cred.user;

    let photoURL = null;

    if (selectedAvatarFile) {
      const storageRef = storage.ref(`avatars/${user.uid}`);
      await storageRef.put(selectedAvatarFile);
      photoURL = await storageRef.getDownloadURL();
    }

    await user.updateProfile({
      displayName: name,
      photoURL: photoURL
    });

    await db.ref(`users/${user.uid}/profile`).set({
      displayName: name,
      email: email,
      photoURL: photoURL,
      createdAt: Date.now()
    });

    await user.reload();
  } catch (err) {
    errorEl.textContent = 'Lỗi: ' + err.message;
    errorEl.classList.remove('hidden');
  }
});

// ========== ĐĂNG XUẤT ==========
btnLogout.addEventListener('click', () => {
  auth.signOut();
});

// ========== AUTH STATE ==========
auth.onAuthStateChanged(async (user) => {
  currentUser = user;
  if (user) {
    authSection.classList.add('hidden');
    userInfo.classList.remove('hidden');
    userAvatar.src = user.photoURL || DEFAULT_AVATAR;
    userName.textContent = user.displayName || user.email;
    listSection.classList.remove('hidden');
    formSection.classList.add('hidden');
    loadListings();
  } else {
    authSection.classList.remove('hidden');
    userInfo.classList.add('hidden');
    listSection.classList.add('hidden');
    formSection.classList.add('hidden');
    if (listingsListener) {
      listingsListener.off();
      listingsListener = null;
    }
    listingsContainer.innerHTML = '';
    selectedAvatarFile = null;
    regAvatarPreview.src = DEFAULT_AVATAR;
  }
});

// ========== ĐỔI AVATAR ==========
btnChangeAvatar.addEventListener('click', () => {
  changeAvatarInput.click();
});

changeAvatarInput.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file || !currentUser) return;

  try {
    const storageRef = storage.ref(`avatars/${currentUser.uid}`);
    await storageRef.put(file);
    const photoURL = await storageRef.getDownloadURL();

    await currentUser.updateProfile({ photoURL });
    await db.ref(`users/${currentUser.uid}/profile`).update({ photoURL });

    userAvatar.src = photoURL;
    alert('Đã cập nhật ảnh đại diện!');
  } catch (err) {
    alert('Lỗi tải ảnh: ' + err.message);
  }
  changeAvatarInput.value = '';
});

// ========== FORM PHÒNG TRỌ ==========
function openAddForm() {
  editId = null;
  rentalForm.reset();
  document.getElementById('listing-id').value = '';
  formTitle.textContent = 'Thêm phòng trọ';
  formSection.classList.remove('hidden');
  listSection.classList.add('hidden');
}

function closeForm() {
  formSection.classList.add('hidden');
  listSection.classList.remove('hidden');
}

btnAdd.addEventListener('click', openAddForm);
if (btnAddEmpty) btnAddEmpty.addEventListener('click', openAddForm);
btnCancel.addEventListener('click', closeForm);
btnBack.addEventListener('click', closeForm);

rentalForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!currentUser) return;

  const data = {
    title: document.getElementById('title').value.trim(),
    address: document.getElementById('address').value.trim(),
    rent: Number(document.getElementById('rent').value),
    deposit: Number(document.getElementById('deposit').value),
    contractDate: document.getElementById('contract-date').value,
    returnDate: document.getElementById('return-date').value,
    duration: document.getElementById('duration').value || null,
    status: document.getElementById('status').value,
    tamTru: document.getElementById('tam-tru').value,
    tamVang: document.getElementById('tam-vang').value,
    contractNote: document.getElementById('contract-note').value.trim(),
    updatedAt: Date.now()
  };

  const ref = db.ref(`users/${currentUser.uid}/listings`);
  try {
    if (editId) {
      await ref.child(editId).update(data);
      alert('Đã cập nhật thành công!');
    } else {
      data.createdAt = Date.now();
      await ref.push(data);
      alert('Đã thêm phòng trọ mới!');
    }
    closeForm();
  } catch (err) {
    alert('Lỗi lưu dữ liệu: ' + err.message);
  }
});

// ========== LOAD & RENDER ==========
function loadListings() {
  if (!currentUser) return;

  if (listingsListener) {
    listingsListener.off();
  }

  const ref = db.ref(`users/${currentUser.uid}/listings`);
  listingsListener = ref;

  ref.on('value', snapshot => {
    const data = snapshot.val();
    if (!data) {
      listingCount.textContent = '0 phòng';
      listingsContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🏠</div>
          <h3>Chưa có phòng nào</h3>
          <p>Thêm phòng đầu tiên để bắt đầu quản lý hợp đồng thuê.</p>
          <button id="btn-add-empty" class="btn btn-primary">+ Thêm phòng mới</button>
        </div>
      `;
      document.getElementById('btn-add-empty')?.addEventListener('click', openAddForm);
      return;
    }

    const items = Object.entries(data).map(([id, item]) => ({ id, ...item }));
    items.sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));

    listingCount.textContent = `${items.length} phòng`;

    listingsContainer.innerHTML = items.map(item => {
      const statusClass = item.status === 'active' ? 'status-active'
        : item.status === 'ended' ? 'status-ended' : 'status-pending';
      const statusLabel = item.status === 'active' ? 'Đang thuê'
        : item.status === 'ended' ? 'Đã trả nhà' : 'Chờ ký';
      const tamTruLabel = item.tamTru === 'yes' ? 'Đã làm' : item.tamTru === 'no' ? 'Chưa làm' : 'N/A';
      const tamVangLabel = item.tamVang === 'yes' ? 'Có' : 'Không';

      return `
        <article class="listing-card">
          <div class="listing-top">
            <h3 class="listing-title">${escapeHtml(item.title)}</h3>
            <span class="status-badge ${statusClass}">${statusLabel}</span>
          </div>
          <div class="listing-body">
            <div class="listing-row">
              <strong>Địa chỉ</strong>
              <span>${escapeHtml(item.address)}</span>
            </div>
            <div class="listing-meta">
              <span>💰 <strong>${formatMoney(item.rent)}</strong>/tháng</span>
              <span>🔒 Cọc: <strong>${formatMoney(item.deposit)}</strong></span>
            </div>
            <div class="listing-row">
              <strong>Hợp đồng</strong>
              <span>${item.contractDate || '—'} → ${item.returnDate || '—'}${item.duration ? ` (${item.duration} tháng)` : ''}</span>
            </div>
            <div class="listing-row">
              <strong>Hành chính</strong>
              <span>Tạm trú: ${tamTruLabel} · Tạm vắng: ${tamVangLabel}</span>
            </div>
            ${item.contractNote ? `
            <div class="listing-row">
              <strong>Ghi chú</strong>
              <span>${escapeHtml(item.contractNote)}</span>
            </div>` : ''}
          </div>
          <div class="listing-actions">
            <button class="btn btn-outline btn-sm" onclick="editListing('${item.id}')">Sửa</button>
            <button class="btn btn-danger btn-sm" onclick="deleteListing('${item.id}')">Xóa</button>
          </div>
        </article>
      `;
    }).join('');
  });
}

window.editListing = function (id) {
  const ref = db.ref(`users/${currentUser.uid}/listings/${id}`);
  ref.once('value').then(snap => {
    const item = snap.val();
    if (!item) return;
    editId = id;
    document.getElementById('listing-id').value = id;
    document.getElementById('title').value = item.title || '';
    document.getElementById('address').value = item.address || '';
    document.getElementById('rent').value = item.rent || '';
    document.getElementById('deposit').value = item.deposit || '';
    document.getElementById('contract-date').value = item.contractDate || '';
    document.getElementById('return-date').value = item.returnDate || '';
    document.getElementById('duration').value = item.duration || '';
    document.getElementById('status').value = item.status || 'active';
    document.getElementById('tam-tru').value = item.tamTru || 'no';
    document.getElementById('tam-vang').value = item.tamVang || 'no';
    document.getElementById('contract-note').value = item.contractNote || '';
    formTitle.textContent = 'Cập nhật phòng trọ';
    formSection.classList.remove('hidden');
    listSection.classList.add('hidden');
  });
};

window.deleteListing = function (id) {
  if (!confirm('Bạn chắc chắn muốn xóa phòng này?')) return;
  db.ref(`users/${currentUser.uid}/listings/${id}`).remove()
    .then(() => alert('Đã xóa!'))
    .catch(err => alert('Lỗi: ' + err.message));
};

function formatMoney(n) {
  return new Intl.NumberFormat('vi-VN').format(n || 0) + ' ₫';
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
