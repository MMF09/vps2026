# Tính Công Việc — Bản Web (đã sửa)

Chuyển thể từ ứng dụng Android **WorkerWorkload** sang HTML + CSS + JS.

## Tính năng

- Đăng nhập / Đăng ký (Firebase Authentication Email/Password)
- Nhập thông tin công việc → tính năng suất (khối lượng / giờ)
- Lưu lịch sử theo từng tài khoản trên Firebase Realtime Database
- Xem & xóa bản ghi lịch sử
- Giao diện tiếng Việt, responsive

## Firebase Rules (bắt buộc)

File `database.rules.json` — copy nội dung này vào Firebase Console → Realtime Database → Rules:

```json
{
  "rules": {
    "users": {
      "$user_id": {
        ".read": "$user_id === auth.uid",
        ".write": "$user_id === auth.uid"
      }
    }
  }
}
```

- Mỗi user **chỉ** đọc/ghi được dữ liệu dưới `users/{uid}/...` của chính mình.
- Path trong app: `users/${auth.uid}/works/{pushId}` — khớp 100% với rules.

## Cách chạy

```bash
cd web-app-fixed
python -m http.server 8080
```

Truy cập http://localhost:8080

(Không mở bằng `file://` — Firebase Auth/Database cần HTTP origin.)

## Các lỗi đã sửa so với bản gốc

1. **Listener cleanup** — Trước đây `stopHistory()` gọi `getWorksRef().off()` khi user đã logout → throw. Giờ dùng unsubscribe function, dừng listener **trước** `signOut`.
2. **Auth state** — Khi logout: clear form, ẩn kết quả, dừng listener sạch sẽ.
3. **Permission denied** — Toast rõ ràng khi rules từ chối (thay vì message Firebase khó hiểu).
4. **Password** — Không `.trim()` password (tránh mất khoảng trắng có chủ ý).
5. **XSS** — `data-id` cũng được escape; escapeHtml an toàn hơn với null.
6. **Disable button** khi đang lưu / đăng nhập / đăng ký để tránh double-submit.
7. **Message lỗi auth** — Dịch tiếng Việt theo `error.code` (email đã dùng, sai mật khẩu, …).

## Cấu trúc

```
web-app-fixed/
├── index.html
├── style.css
├── app.js
├── database.rules.json   ← rules Firebase
└── README.md
```
