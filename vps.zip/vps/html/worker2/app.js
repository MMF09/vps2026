/**
 * Tính Công Việc — Web version
 * Chuyển thể từ Android app WorkerWorkload
 * Fixed: auth state, listener cleanup, rules-safe paths, UI/logic bugs
 */

// ===== Firebase config (cùng project với app Android) =====
const firebaseConfig = {
  apiKey: "AIzaSyAdVQH5MK3xZv1B4BmmAOinSsTV_92PwJA",
  authDomain: "project-doidoi.firebaseapp.com",
  databaseURL: "https://project-doidoi-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "project-doidoi",
  storageBucket: "project-doidoi.firebasestorage.app",
  messagingSenderId: "849773176716",
  appId: "1:849773176716:web:workerworkload"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// ===== DOM refs =====
const loginScreen = document.getElementById("login-screen");
const registerScreen = document.getElementById("register-screen");
const mainScreen = document.getElementById("main-screen");

const loginEmail = document.getElementById("login-email");
const loginPassword = document.getElementById("login-password");
const btnLogin = document.getElementById("btn-login");
const loginError = document.getElementById("login-error");

const regEmail = document.getElementById("reg-email");
const regPassword = document.getElementById("reg-password");
const btnRegister = document.getElementById("btn-register");
const regError = document.getElementById("reg-error");

const workerName = document.getElementById("worker-name");
const workType = document.getElementById("work-type");
const quantity = document.getElementById("quantity");
const unit = document.getElementById("unit");
const hours = document.getElementById("hours");
const btnCalculate = document.getElementById("btn-calculate");
const resultCard = document.getElementById("result-card");
const resultText = document.getElementById("result-text");

const historyList = document.getElementById("history-list");
const historyLoading = document.getElementById("history-loading");
const historyEmpty = document.getElementById("history-empty");

const toastEl = document.getElementById("toast");

/** @type {(() => void) | null} */
let worksUnsubscribe = null;

// ===== Helpers =====
function showScreen(screen) {
  loginScreen.classList.add("hidden");
  registerScreen.classList.add("hidden");
  mainScreen.classList.add("hidden");
  screen.classList.remove("hidden");
}

function toast(msg, duration = 2500) {
  toastEl.textContent = msg;
  toastEl.classList.remove("hidden");
  clearTimeout(toastEl._timer);
  toastEl._timer = setTimeout(() => toastEl.classList.add("hidden"), duration);
}

function formatDate(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/**
 * Path: users/{uid}/works — khớp với rules:
 * users/$user_id .read/.write = $user_id === auth.uid
 */
function getWorksRef() {
  const user = auth.currentUser;
  if (!user) throw new Error("Chưa đăng nhập");
  return db.ref(`users/${user.uid}/works`);
}

function escapeHtml(str) {
  if (str == null) return "";
  const div = document.createElement("div");
  div.textContent = String(str);
  return div.innerHTML;
}

// ===== Auth state =====
auth.onAuthStateChanged((user) => {
  if (user) {
    showScreen(mainScreen);
    loadHistory();
  } else {
    stopHistory();
    resultCard.classList.add("hidden");
    resultText.textContent = "";
    clearForm();
    showScreen(loginScreen);
  }
});

// ===== Login =====
btnLogin.addEventListener("click", async () => {
  const email = loginEmail.value.trim();
  const password = loginPassword.value; // không trim password
  loginError.textContent = "";

  if (!email || !password) {
    loginError.textContent = "Vui lòng nhập đầy đủ thông tin";
    return;
  }

  btnLogin.disabled = true;
  btnLogin.textContent = "Đang đăng nhập...";

  try {
    await auth.signInWithEmailAndPassword(email, password);
    // onAuthStateChanged sẽ chuyển sang main
  } catch (e) {
    const code = e.code || "";
    if (code === "auth/user-not-found" || code === "auth/wrong-password" || code === "auth/invalid-credential") {
      loginError.textContent = "Email hoặc mật khẩu không đúng";
    } else if (code === "auth/invalid-email") {
      loginError.textContent = "Email không hợp lệ";
    } else if (code === "auth/too-many-requests") {
      loginError.textContent = "Quá nhiều lần thử. Vui lòng thử lại sau";
    } else {
      loginError.textContent = "Đăng nhập thất bại: " + (e.message || "Không xác định");
    }
  } finally {
    btnLogin.disabled = false;
    btnLogin.textContent = "ĐĂNG NHẬP";
  }
});

document.getElementById("go-register").addEventListener("click", (e) => {
  e.preventDefault();
  loginError.textContent = "";
  showScreen(registerScreen);
});

// ===== Register =====
btnRegister.addEventListener("click", async () => {
  const email = regEmail.value.trim();
  const password = regPassword.value;
  regError.textContent = "";

  if (!email || !password) {
    regError.textContent = "Vui lòng nhập đầy đủ";
    return;
  }
  if (password.length < 6) {
    regError.textContent = "Mật khẩu tối thiểu 6 ký tự";
    return;
  }

  btnRegister.disabled = true;
  btnRegister.textContent = "Đang đăng ký...";

  try {
    await auth.createUserWithEmailAndPassword(email, password);
    toast("Đăng ký thành công!");
    // onAuthStateChanged tự chuyển màn hình
  } catch (e) {
    const code = e.code || "";
    if (code === "auth/email-already-in-use") {
      regError.textContent = "Email đã được sử dụng";
    } else if (code === "auth/invalid-email") {
      regError.textContent = "Email không hợp lệ";
    } else if (code === "auth/weak-password") {
      regError.textContent = "Mật khẩu quá yếu (tối thiểu 6 ký tự)";
    } else {
      regError.textContent = "Lỗi: " + (e.message || "Không xác định");
    }
  } finally {
    btnRegister.disabled = false;
    btnRegister.textContent = "ĐĂNG KÝ";
  }
});

document.getElementById("go-login").addEventListener("click", (e) => {
  e.preventDefault();
  regError.textContent = "";
  showScreen(loginScreen);
});

// ===== Logout =====
document.getElementById("btn-logout").addEventListener("click", async () => {
  // Dừng listener TRƯỚC khi signOut để tránh gọi getWorksRef khi đã logout
  stopHistory();
  try {
    await auth.signOut();
  } catch (e) {
    toast("Lỗi đăng xuất: " + (e.message || ""));
  }
});

// ===== Calculate & Save =====
btnCalculate.addEventListener("click", async () => {
  if (!auth.currentUser) {
    toast("Bạn cần đăng nhập");
    return;
  }

  const name = workerName.value.trim();
  const type = workType.value.trim();
  const qtyStr = quantity.value.trim().replace(",", ".");
  const unitVal = unit.value.trim();
  const hoursStr = hours.value.trim().replace(",", ".");

  if (!name || !type || !qtyStr || !unitVal || !hoursStr) {
    toast("Vui lòng nhập đầy đủ thông tin");
    return;
  }

  const qty = parseFloat(qtyStr);
  const hrs = parseFloat(hoursStr);

  if (isNaN(qty) || isNaN(hrs)) {
    toast("Số liệu không hợp lệ");
    return;
  }
  if (qty < 0) {
    toast("Khối lượng không được âm");
    return;
  }
  if (hrs <= 0) {
    toast("Thời gian phải lớn hơn 0");
    return;
  }

  const productivity = qty / hrs;

  resultText.textContent =
    `Năng suất: ${productivity.toFixed(2)} ${unitVal} / giờ\n` +
    `Tổng khối lượng: ${qty.toFixed(2)} ${unitVal} trong ${hrs.toFixed(1)} giờ`;
  resultCard.classList.remove("hidden");

  const item = {
    workerName: name,
    workType: type,
    quantity: qty,
    unit: unitVal,
    hours: hrs,
    productivity: productivity,
    timestamp: Date.now()
  };

  btnCalculate.disabled = true;
  btnCalculate.textContent = "Đang lưu...";

  try {
    const ref = getWorksRef().push();
    await ref.set(item);
    clearForm();
    toast("Đã lưu thành công!");
  } catch (e) {
    if (e.code === "PERMISSION_DENIED") {
      toast("Không có quyền lưu. Kiểm tra đăng nhập / rules");
    } else {
      toast("Lỗi lưu: " + (e.message || "Không xác định"));
    }
  } finally {
    btnCalculate.disabled = false;
    btnCalculate.textContent = "TÍNH TOÁN & LƯU";
  }
});

function clearForm() {
  workerName.value = "";
  workType.value = "";
  quantity.value = "";
  unit.value = "";
  hours.value = "";
}

// ===== History =====
function loadHistory() {
  stopHistory();

  if (!auth.currentUser) return;

  historyLoading.classList.remove("hidden");
  historyEmpty.classList.add("hidden");
  historyList.innerHTML = "";

  try {
    const worksRef = getWorksRef();
    const query = worksRef.orderByChild("timestamp").limitToLast(100);

    const onValue = (snapshot) => {
      historyLoading.classList.add("hidden");
      const items = [];
      snapshot.forEach((child) => {
        const data = child.val();
        if (data) {
          data.id = child.key;
          items.push(data);
        }
      });
      // Mới nhất lên đầu
      items.reverse();
      renderHistory(items);
    };

    const onError = (err) => {
      historyLoading.classList.add("hidden");
      historyEmpty.classList.remove("hidden");
      if (err.code === "PERMISSION_DENIED") {
        toast("Không có quyền đọc dữ liệu. Kiểm tra rules Firebase");
      } else {
        toast("Lỗi tải dữ liệu: " + (err.message || ""));
      }
    };

    // Lưu callback để off chính xác; dùng query để khớp listener
    query.on("value", onValue, onError);
    worksUnsubscribe = () => {
      try {
        query.off("value", onValue);
      } catch (_) {
        /* ignore */
      }
    };
  } catch (e) {
    historyLoading.classList.add("hidden");
    historyEmpty.classList.remove("hidden");
    toast("Lỗi: " + (e.message || ""));
  }
}

function stopHistory() {
  if (worksUnsubscribe) {
    worksUnsubscribe();
    worksUnsubscribe = null;
  }
}

function renderHistory(items) {
  historyList.innerHTML = "";
  if (!items || items.length === 0) {
    historyEmpty.classList.remove("hidden");
    return;
  }
  historyEmpty.classList.add("hidden");

  items.forEach((item) => {
    const el = document.createElement("div");
    el.className = "work-item";
    el.innerHTML = `
      <button type="button" class="btn-delete" title="Xóa" data-id="${escapeHtml(item.id)}">Xóa</button>
      <div class="worker">${escapeHtml(item.workerName || "")}</div>
      <div class="type">${escapeHtml(item.workType || "")}</div>
      <div class="detail">Khối lượng: ${(Number(item.quantity) || 0).toFixed(2)} ${escapeHtml(item.unit || "")}  |  Thời gian: ${(Number(item.hours) || 0).toFixed(1)} giờ</div>
      <div class="productivity">Năng suất: ${(Number(item.productivity) || 0).toFixed(2)} ${escapeHtml(item.unit || "")}/giờ</div>
      <div class="date">${formatDate(item.timestamp)}</div>
    `;
    historyList.appendChild(el);
  });

  historyList.querySelectorAll(".btn-delete").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-id");
      if (id && confirm("Xóa bản ghi này?")) {
        deleteWork(id);
      }
    });
  });
}

async function deleteWork(id) {
  if (!id || !auth.currentUser) return;
  try {
    await getWorksRef().child(id).remove();
    toast("Đã xóa");
  } catch (e) {
    if (e.code === "PERMISSION_DENIED") {
      toast("Không có quyền xóa");
    } else {
      toast("Không xóa được: " + (e.message || ""));
    }
  }
}

// Enter key support
[loginEmail, loginPassword].forEach((el) => {
  el.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btnLogin.click();
  });
});
[regEmail, regPassword].forEach((el) => {
  el.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btnRegister.click();
  });
});
