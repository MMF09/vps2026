/**
 * Unified Work Hub — Clean Controller v2
 * - Single login for 3 Firebase projects (4 modules)
 * - No nested chrome
 * - Activate module data only when visible (optimal)
 * - Original DB queries / listeners untouched
 */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  updateProfile, signOut, onAuthStateChanged, setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const CONFIGS = {
  yduc: {
    apiKey: "AIzaSyC7HE94M-w9chHikRLxlAKMeYsR_71GBpc",
    authDomain: "fbamthucdouong.firebaseapp.com",
    databaseURL: "https://fbamthucdouong-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "fbamthucdouong",
    storageBucket: "fbamthucdouong.firebasestorage.app",
    messagingSenderId: "399700364963",
    appId: "1:399700364963:web:611971b25a87467fb7b916"
  },
  money: {
    apiKey: "AIzaSyBIIWxW_jTP1BpGOaIa9atr_sFhRlz3fJ0",
    authDomain: "tienbothi.firebaseapp.com",
    databaseURL: "https://tienbothi-default-rtdb.firebaseio.com",
    projectId: "tienbothi",
    storageBucket: "tienbothi.firebasestorage.app",
    messagingSenderId: "353470247741",
    appId: "1:353470247741:web:2cf921cc96ba0353e2cb54"
  },
  daydg: {
    apiKey: "AIzaSyA7lia7Q2SN79kZYlRCiR0swc8oZUoUenY",
    authDomain: "day-dg.firebaseapp.com",
    databaseURL: "https://day-dg-default-rtdb.firebaseio.com",
    projectId: "day-dg",
    storageBucket: "day-dg.appspot.com",
    messagingSenderId: "268157993796",
    appId: "1:268157993796:web:a0d74a8100749f7f6dcd11"
  }
};

const apps = {};
const auths = {};
let isRegisterMode = false;
let currentModule = "yduc";
let globalUser = null;
const activated = new Set();

const TITLES = {
  yduc: "Hồ sơ Y Đức",
  money: "Sổ Thu Chi",
  analysis: "Phân tích Data",
  health: "Theo dõi Sức khỏe"
};

function $(id) { return document.getElementById(id); }

function showToast(msg, isError = false) {
  const t = $("toast");
  if (!t) return;
  $("toast-message").textContent = msg;
  $("toast-icon").className = isError ? "fas fa-exclamation-circle" : "fas fa-check-circle";
  t.classList.add("show");
  clearTimeout(t._tid);
  t._tid = setTimeout(() => t.classList.remove("show"), 3000);
}

function initFirebaseApps() {
  for (const [key, cfg] of Object.entries(CONFIGS)) {
    try {
      apps[key] = initializeApp(cfg, key + "-hub");
      auths[key] = getAuth(apps[key]);
      setPersistence(auths[key], browserLocalPersistence).catch(() => {});
    } catch (e) {
      console.warn("[hub] init", key, e.message);
    }
  }
}

async function tryAuthAll(email, password, displayName) {
  const ok = [], fail = [];
  await Promise.all(Object.keys(auths).map(async (key) => {
    try {
      if (isRegisterMode) {
        const cred = await createUserWithEmailAndPassword(auths[key], email, password);
        if (displayName && (key === "yduc" || key === "daydg")) {
          try { await updateProfile(cred.user, { displayName }); } catch (_) {}
        }
      } else {
        await signInWithEmailAndPassword(auths[key], email, password);
      }
      ok.push(key);
    } catch (err) {
      fail.push({ key, code: err.code });
    }
  }));
  return { ok, fail };
}

function hideAuth() {
  const el = $("auth-overlay");
  if (!el) return;
  el.classList.add("hidden");
  setTimeout(() => { el.style.display = "none"; }, 280);
  $("app-shell").style.display = "flex";
}

function showAuth() {
  const el = $("auth-overlay");
  if (!el) return;
  el.style.display = "flex";
  requestAnimationFrame(() => el.classList.remove("hidden"));
  $("app-shell").style.display = "none";
}

function updateUserUI(user) {
  globalUser = user;
  const name = user?.displayName || user?.email?.split("@")[0] || "User";
  const email = user?.email || "";
  if ($("sidebar-user")) $("sidebar-user").textContent = email ? `${name} · ${email}` : name;
  if ($("mobile-user")) $("mobile-user").textContent = name;
}

/** Switch module — only activate data layer once */
window.switchModule = function (mod) {
  if (!TITLES[mod]) return;
  currentModule = mod;

  document.querySelectorAll(".module").forEach((el) => {
    el.classList.toggle("active", el.id === "mod-" + mod);
  });
  document.querySelectorAll(".nav-item, #bottom-nav button").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mod === mod);
  });
  if ($("mobile-title")) $("mobile-title").textContent = TITLES[mod];

  // One-time activation hooks (data already loaded by original onAuthStateChanged)
  if (!activated.has(mod)) {
    activated.add(mod);
    // Hide placeholders
    const ph = $(mod + "-placeholder");
    if (ph) ph.style.display = "none";

    // Ensure original dashboards are visible
    if (mod === "yduc") {
      const dash = $("yduc-dashboard");
      if (dash) dash.classList.remove("hidden");
      const auth = $("yduc-auth");
      if (auth) auth.style.display = "none";
    }
    if (mod === "money") {
      const main = $("money-main");
      if (main) main.classList.remove("hidden");
      const login = $("money-login");
      if (login) login.style.display = "none";
      // Kick money tab render if function exists
      if (typeof moneySwitchTab === "function") {
        try { moneySwitchTab(0); } catch (_) {}
      }
    }
    if (mod === "analysis" && typeof switchTab === "function") {
      try { switchTab("analysis"); } catch (_) {}
    }
    if (mod === "health" && typeof switchTab === "function") {
      try { switchTab("health"); } catch (_) {}
    }
  }
};

window.globalLogout = async function () {
  try {
    await Promise.all(Object.values(auths).map((a) => signOut(a).catch(() => {})));
  } catch (_) {}
  // Also sign out compat apps if present
  try {
    if (typeof firebase !== "undefined" && firebase.apps) {
      firebase.apps.forEach((a) => a.auth().signOut().catch(() => {}));
    }
  } catch (_) {}
  globalUser = null;
  activated.clear();
  updateUserUI(null);
  showAuth();
  showToast("Đã đăng xuất");
};

function startClock() {
  const el = $("realtime-clock");
  if (!el) return;
  const tick = () => {
    el.textContent = new Date().toLocaleString("vi-VN", { hour12: false });
  };
  tick();
  setInterval(tick, 1000);
}

document.addEventListener("DOMContentLoaded", () => {
  initFirebaseApps();
  startClock();

  // Auth UI
  const form = $("global-auth-form");
  const toggleBtn = $("btn-toggle-auth-mode");
  const nameWrap = $("display-name-wrap");

  toggleBtn?.addEventListener("click", () => {
    isRegisterMode = !isRegisterMode;
    $("auth-btn-text").textContent = isRegisterMode ? "Đăng ký" : "Đăng nhập";
    $("auth-toggle-text").textContent = isRegisterMode ? "Đã có tài khoản?" : "Chưa có tài khoản?";
    toggleBtn.textContent = isRegisterMode ? "Đăng nhập" : "Đăng ký ngay";
    nameWrap.style.display = isRegisterMode ? "block" : "none";
  });

  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = $("global-email").value.trim();
    const password = $("global-password").value;
    const displayName = $("global-display-name")?.value.trim() || null;
    const btn = $("btn-global-auth");
    const status = $("auth-status");
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý…';
    status.textContent = "Đồng bộ 3 project Firebase…";

    const { ok, fail } = await tryAuthAll(email, password, displayName);

    btn.disabled = false;
    btn.innerHTML = `<i class="fas fa-sign-in-alt"></i> <span id="auth-btn-text">${isRegisterMode ? "Đăng ký" : "Đăng nhập"}</span>`;

    if (ok.length) {
      const primary = auths.yduc || auths.daydg || Object.values(auths)[0];
      updateUserUI(primary.currentUser);
      hideAuth();
      const msg = fail.length
        ? `OK: ${ok.join(", ")} · Lỗi: ${fail.map((f) => f.key).join(", ")}`
        : `Đăng nhập thành công (${ok.join(", ")})`;
      showToast(msg, fail.length > 0);
      // Let original module scripts pick up auth state, then show first module
      requestAnimationFrame(() => switchModule("yduc"));
    } else {
      const code = fail[0]?.code || "";
      let msg = "Đăng nhập thất bại trên tất cả module.";
      if (code.includes("user-not-found") || code.includes("invalid-credential") || code.includes("wrong-password")) {
        msg = "Sai email hoặc mật khẩu. Hãy Đăng ký nếu chưa có tài khoản.";
      } else if (code.includes("email-already-in-use")) {
        msg = "Email đã tồn tại — chuyển sang Đăng nhập.";
      } else if (code.includes("weak-password")) {
        msg = "Mật khẩu tối thiểu 6 ký tự.";
      }
      status.textContent = msg;
      showToast(msg, true);
    }
  });

  // Restore session if any project still logged in
  let restored = false;
  Object.values(auths).forEach((a) => {
    onAuthStateChanged(a, (user) => {
      if (user && !restored) {
        restored = true;
        updateUserUI(user);
        hideAuth();
        switchModule(currentModule);
      }
    });
  });

  // Safety: permanently hide any auth boxes that original scripts might show
  const hideAuthBoxes = () => {
    ["yduc-auth", "money-login", "auth-section"].forEach((id) => {
      const el = $(id);
      if (el) el.style.display = "none";
    });
    ["yduc-dashboard", "money-main", "app-layout"].forEach((id) => {
      const el = $(id);
      if (el) {
        el.classList.remove("hidden");
        el.style.display = "";
      }
    });
  };
  // Run a few times as module scripts init
  setTimeout(hideAuthBoxes, 400);
  setTimeout(hideAuthBoxes, 1200);
  setTimeout(hideAuthBoxes, 2500);
});
