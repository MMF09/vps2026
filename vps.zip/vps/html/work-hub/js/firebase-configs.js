// Firebase configs for the 3 projects (4 modules: yduc, money, analysis, health)
export const configs = {
  yduc: {
    apiKey: "AIzaSyC7HE94M-w9chHikRLxlAKMeYsR_71GBpc",
    authDomain: "fbamthucdouong.firebaseapp.com",
    databaseURL: "https://fbamthucdouong-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "fbamthucdouong",
    storageBucket: "fbamthucdouong.firebasestorage.app",
    messagingSenderId: "399700364963",
    appId: "1:399700364963:web:611971b25a87467fb7b916"
  },
  money: {
    apiKey: "AIzaSyBIIWxW_jTP1BpGOaIa9atr_sFhRlz3fJ0",
    authDomain: "tienbothi.firebaseapp.com",
    databaseURL: "https://tienbothi-default-rtdb.firebaseio.com",
    projectId: "tienbothi",
    storageBucket: "tienbothi.firebasestorage.app",
    messagingSenderId: "353470247741",
    appId: "1:353470247741:web:2cf921cc96ba0353e2cb54"
  },
  daydg: {
    apiKey: "AIzaSyA7lia7Q2SN79kZYlRCiR0swc8oZUoUenY",
    authDomain: "day-dg.firebaseapp.com",
    databaseURL: "https://day-dg-default-rtdb.firebaseio.com",
    projectId: "day-dg",
    storageBucket: "day-dg.appspot.com",
    messagingSenderId: "268157993796",
    appId: "1:268157993796:web:a0d74a8100749f7f6dcd11",
    measurementId: "G-GCH6G4LJD3"
  }
};
