# Unified Work Hub — Clean UI/UX v2

Website tổng hợp 4 task với **giao diện làm sạch**, bỏ phần thừa, tối ưu tải dữ liệu.

## Thay đổi UI/UX (v2)
- **Một shell duy nhất**: sidebar + topbar + bottom nav — không còn sidebar/auth lồng nhau từ bản cũ.
- **Loại bỏ phần thừa**: form đăng nhập riêng của từng module, header logout trùng, chrome dư thừa.
- **Giao diện thống nhất**: typography, màu, spacing, card thống nhất.
- **Module panels sạch**: chỉ giữ nội dung chức năng (bảng dữ liệu, form thêm, modal, FAB).

## Tối ưu tải dữ liệu
- Auth multi-project chạy **song song** (Promise.all).
- Module chỉ **activate một lần** khi user mở lần đầu (`activated` set).
- Giữ nguyên cache / pagination / debounce search / realtime listener của code gốc → **truy vấn DB không đổi**.
- CSS `contain: layout style paint` giảm reflow.
- Fonts & Font Awesome load `media="print" onload` → không block first paint.
- Preconnect tới fonts / gstatic / cdnjs.

## Cấu trúc
```
index.html          # Shell sạch + nội dung module đã lược
css/unified.css     # Design system mới
js/main.js          # Controller login + switch tối ưu
yduc.js / money.js / js/qtpt-app.js   # Data layer gốc (không sửa logic DB)
style.css / css/qtpt.css              # Style component gốc còn cần
```

## Chạy
```bash
npx serve .
# hoặc python -m http.server 8080
```
Mở trình duyệt → đăng nhập (cùng email/pass trên 3 Firebase project) → dùng 4 module.
