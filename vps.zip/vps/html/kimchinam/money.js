// ====================== MONEY MODULE (compat Firebase) ======================
const moneyFirebaseConfig = {
  apiKey: "AIzaSyBIIWxW_jTP1BpGOaIa9atr_sFhRlz3fJ0",
  authDomain: "tienbothi.firebaseapp.com",
  databaseURL: "https://tienbothi-default-rtdb.firebaseio.com",
  projectId: "tienbothi",
  storageBucket: "tienbothi.firebasestorage.app",
  messagingSenderId: "353470247741",
  appId: "1:353470247741:web:2cf921cc96ba0353e2cb54"
};

let moneyApp, moneyAuth, moneyDb, moneyCurrentUser = null;
window.moneyCurrentUser = null;
const MONEY_ITEMS_PER_PAGE = 15;
let moneyCurrentTab = 0;
let allChi = {}, allThu = {};
let moneyCurrentEditKey = null;
let moneyAuthMode = 'login';

function moneySetCookie(name, value, days) {
  let expires = "";
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/; SameSite=Lax";
}

function moneyEraseCookie(name) {
  document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function moneyInitFirebase() {
  // Load compat scripts dynamically if needed
  if (typeof firebase === 'undefined') {
    console.error('Firebase compat not loaded');
    return;
  }
  moneyApp = firebase.initializeApp(moneyFirebaseConfig, "money-app");
  moneyAuth = moneyApp.auth();
  moneyDb = moneyApp.database();

  moneyAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);

  moneyAuth.onAuthStateChanged(async (user) => {
    moneyCurrentUser = user;
    window.moneyCurrentUser = user;
    if (user) {
      try {
        const token = await user.getIdToken();
        moneySetCookie('session_token', token, 7);
        await moneyEnsureUserProfile(user);

        document.getElementById('money-login').classList.add('hidden');
        document.getElementById('money-main').classList.remove('hidden');
        if (typeof updateUserDisplay === 'function') updateUserDisplay();
        moneyLoadAllData();
        moneySwitchTab(0);
      } catch (err) {
        console.error(err);
        alert('Không thể khởi tạo hồ sơ người dùng. Vui lòng thử lại.');
        moneyAuth.signOut();
      }
    } else {
      moneyEraseCookie('session_token');
      document.getElementById('money-login').classList.remove('hidden');
      document.getElementById('money-main').classList.add('hidden');
      allChi = {};
      allThu = {};
      if (typeof updateUserDisplay === 'function') updateUserDisplay();
    }
  });
}

async function moneyEnsureUserProfile(user) {
  const userRef = moneyDb.ref(`users/${user.uid}`);
  const snap = await userRef.once('value');
  if (!snap.exists()) {
    await userRef.set({
      displayName: (user.email || 'Anonymous').substring(0, 49),
      createdAt: Date.now()
    });
  }
}

function moneySetAuthMode(mode) {
  moneyAuthMode = mode;
}

function moneyHandleEmailPasswordAuth(e) {
  e.preventDefault();
  const email = document.getElementById('money-auth-email').value.trim();
  const password = document.getElementById('money-auth-password').value;
  const statusMsg = document.getElementById('money-email-status-msg');
  statusMsg.classList.add('hidden');

  if (moneyAuthMode === 'register') {
    moneyAuth.createUserWithEmailAndPassword(email, password)
      .then(() => {
        statusMsg.textContent = 'Đăng ký tài khoản thành công!';
        statusMsg.classList.remove('hidden');
      })
      .catch((err) => {
        alert('Đăng ký thất bại: ' + (err.message || 'Lỗi hệ thống'));
      });
  } else {
    moneyAuth.signInWithEmailAndPassword(email, password)
      .catch((err) => {
        alert('Đăng nhập thất bại: ' + (err.message || 'Email hoặc mật khẩu không chính xác'));
      });
  }
}

function moneyLogout() {
  if (confirm('Bạn có chắc muốn đăng xuất?')) {
    moneyEraseCookie('session_token');
    moneyAuth.signOut();
  }
}

function moneyGetUserRef(type) {
  if (!moneyCurrentUser) throw new Error('Chưa đăng nhập');
  if (type !== 'chi-tieu' && type !== 'thu-nhap') throw new Error('Loại dữ liệu không hợp lệ');
  return moneyDb.ref(`users/${moneyCurrentUser.uid}/${type}`);
}

function moneyLoadAllData() {
  if (!moneyCurrentUser) return;

  moneyGetUserRef('chi-tieu').on('value', snap => {
    allChi = snap.val() || {};
    moneyRenderAuditLog('chi-tieu', 1);
    moneyCalculateBalance();
  }, err => console.error(err));

  moneyGetUserRef('thu-nhap').on('value', snap => {
    allThu = snap.val() || {};
    moneyRenderAuditLog('thu-nhap', 1);
    moneyCalculateBalance();
  }, err => console.error(err));
}

function moneyCalculateBalance() {
  let totalThu = 0, totalChi = 0;
  Object.values(allThu).forEach(i => totalThu += Number(i.so_tien || 0));
  Object.values(allChi).forEach(i => totalChi += Number(i.so_tien || 0));

  document.getElementById('money-audit-total-thu').textContent = totalThu.toLocaleString('vi-VN') + ' đ';
  document.getElementById('money-audit-total-chi').textContent = totalChi.toLocaleString('vi-VN') + ' đ';
  document.getElementById('money-audit-balance').textContent = (totalThu - totalChi).toLocaleString('vi-VN') + ' đ';
}

function moneyRenderAuditLog(type, page) {
  const data = type === 'chi-tieu' ? allChi : allThu;
  const isChi = type === 'chi-tieu';
  
  const sortedKeys = Object.keys(data).sort((a, b) => {
    const da = new Date(data[a].ngay || 0).getTime() || data[a].thoi_gian || 0;
    const db = new Date(data[b].ngay || 0).getTime() || data[b].thoi_gian || 0;
    if (db !== da) return db - da;
    return (data[b].thoi_gian || 0) - (data[a].thoi_gian || 0);
  });
  
  const totalPages = Math.ceil(sortedKeys.length / MONEY_ITEMS_PER_PAGE) || 1;
  const start = (page - 1) * MONEY_ITEMS_PER_PAGE;
  const pageKeys = sortedKeys.slice(start, start + MONEY_ITEMS_PER_PAGE);

  const container = document.getElementById(isChi ? 'money-audit-log-chi' : 'money-audit-log-thu');
  container.innerHTML = '';

  if (pageKeys.length === 0) {
    container.innerHTML = `<div class="text-center py-16 text-slate-400 text-xs font-medium bg-white rounded-2xl border border-slate-200/60 shadow-sm">Chưa có chứng từ giao dịch nào được ghi nhận.</div>`;
    document.getElementById(isChi ? 'money-pagination-chi' : 'money-pagination-thu').innerHTML = '';
    return;
  }

  const groupedData = {};
  pageKeys.forEach(key => {
    const item = data[key];
    const dateStr = item.ngay || 'unknown';
    if (!groupedData[dateStr]) {
      groupedData[dateStr] = { items: [], dayTotal: 0 };
    }
    groupedData[dateStr].items.push({ key, ...item });
    groupedData[dateStr].dayTotal += Number(item.so_tien || 0);
  });

  Object.keys(groupedData).forEach(date => {
    const group = groupedData[date];
    let formatDayHeader = date;
    try {
      const d = new Date(date);
      if (!isNaN(d)) {
        formatDayHeader = d.toLocaleDateString('vi-VN', { 
          weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' 
        });
      }
    } catch(e) {}

    let groupHtml = `
      <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden mb-3">
        <div class="bg-slate-50/80 px-4 py-2.5 border-b border-slate-100 flex justify-between items-center">
          <span class="text-[11px] font-bold text-slate-600 uppercase tracking-tight">${moneyEscapeHtml(formatDayHeader)}</span>
          <span class="text-[11px] font-extrabold ${isChi ? 'text-rose-600' : 'text-emerald-600'} bg-white px-2.5 py-0.5 rounded-md border border-slate-200/60 shadow-2xs">
            Tổng ngày: ${isChi ? '-' : '+'}${group.dayTotal.toLocaleString('vi-VN')} đ
          </span>
        </div>
        <div class="divide-y divide-slate-100">`;

    group.items.forEach(item => {
      groupHtml += `
        <div class="px-4 py-3 flex justify-between items-center gap-3 hover:bg-slate-50/60 transition-colors">
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-2 mb-0.5">
              <span class="font-bold text-sm text-slate-800 truncate">${moneyEscapeHtml(item.danh_muc || '')}</span>
              ${item.ghi_chu ? `<span class="bg-indigo-50 text-indigo-600 font-semibold px-1.5 py-0.5 rounded text-[9px] uppercase tracking-wide truncate max-w-[90px] border border-indigo-100">${moneyEscapeHtml(item.ghi_chu)}</span>` : ''}
            </div>
            <div class="text-xs text-slate-500 truncate pl-0.5">${moneyEscapeHtml(item.mo_ta || '')}</div>
          </div>
          <div class="flex items-center gap-3 flex-shrink-0">
            <span class="font-extrabold text-sm ${isChi ? 'text-rose-600' : 'text-emerald-600'}">
              ${isChi ? '-' : '+'}${Number(item.so_tien || 0).toLocaleString('vi-VN')}
            </span>
            <div class="flex gap-1 border-l border-slate-200/60 pl-2">
              <button onclick="moneyEditItem('${type}', '${item.key}')" class="p-1.5 text-slate-400 hover:text-indigo-600 active:scale-90 transition-transform bg-slate-50 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
              </button>
              <button onclick="moneyDeleteItem('${type}', '${item.key}')" class="p-1.5 text-slate-400 hover:text-rose-600 active:scale-90 transition-transform bg-slate-50 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-4v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
              </button>
            </div>
          </div>
        </div>`;
    });

    groupHtml += `</div></div>`;
    container.innerHTML += groupHtml;
  });

  const pagContainer = document.getElementById(isChi ? 'money-pagination-chi' : 'money-pagination-thu');
  pagContainer.innerHTML = '';
  if (totalPages > 1) {
    for (let i = 1; i <= totalPages; i++) {
      const btn = document.createElement('button');
      btn.textContent = i;
      btn.className = `w-8 h-8 rounded-xl text-xs font-bold flex items-center justify-center transition-all shadow-2xs ${i === page ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`;
      btn.onclick = () => moneyRenderAuditLog(type, i);
      pagContainer.appendChild(btn);
    }
  }
}

function moneySwitchTab(tab) {
  moneyCurrentTab = tab;
  const btn0 = document.getElementById('money-tab-0');
  const btn1 = document.getElementById('money-tab-1');

  if (tab === 0) {
    btn0.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all bg-indigo-600 text-white shadow-md";
    btn1.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all text-indigo-300 hover:text-white bg-transparent";
    document.getElementById('money-content-0').classList.remove('hidden');
    document.getElementById('money-content-1').classList.add('hidden');
  } else {
    btn1.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all bg-indigo-600 text-white shadow-md";
    btn0.className = "flex-1 py-2 text-xs font-bold rounded-lg transition-all text-indigo-300 hover:text-white bg-transparent";
    document.getElementById('money-content-1').classList.remove('hidden');
    document.getElementById('money-content-0').classList.add('hidden');
  }
}

function moneyShowAddModal() {
  moneyCurrentEditKey = null;
  document.getElementById('money-modal-title').textContent = moneyCurrentTab === 0 ? 'Ghi nhận Khoản Chi Tiêu' : 'Ghi nhận Khoản Tiền Nhận Về';
  document.getElementById('money-node-type').value = moneyCurrentTab === 0 ? 'chi-tieu' : 'thu-nhap';
  document.getElementById('money-edit-form').reset();
  
  const now = new Date();
  document.getElementById('money-ngay').value = now.toISOString().split('T')[0];
  moneyShowSheet();
}

function moneyEditItem(type, key) {
  if (!moneyCurrentUser) return;
  moneyCurrentEditKey = key;
  document.getElementById('money-node-type').value = type;
  document.getElementById('money-modal-title').textContent = 'Điều chỉnh Chứng từ Giao Dịch';

  moneyGetUserRef(type).child(key).once('value', snap => {
    const d = snap.val();
    if (d) {
      document.getElementById('money-ngay').value = d.ngay || '';
      document.getElementById('money-danh_muc').value = d.danh_muc || '';
      document.getElementById('money-mo_ta').value = d.mo_ta || '';
      document.getElementById('money-so_tien').value = d.so_tien || '';
      document.getElementById('money-ghi_chu').value = d.ghi_chu || '';
      moneyShowSheet();
    }
  }).catch(err => {
    alert('Không thể tải dữ liệu chứng từ.');
  });
}

function moneyShowSheet() {
  const backdrop = document.getElementById('money-modal-backdrop');
  const sheet = document.getElementById('money-modal');
  backdrop.classList.remove('hidden');
  setTimeout(() => {
    backdrop.classList.add('opacity-100');
    sheet.classList.add('show');
  }, 10);
}

function moneyHideModal() {
  const backdrop = document.getElementById('money-modal-backdrop');
  const sheet = document.getElementById('money-modal');
  backdrop.classList.remove('opacity-100');
  sheet.classList.remove('show');
  setTimeout(() => { backdrop.classList.add('hidden'); }, 300);
}

function moneySanitizePayload() {
  const danh_muc = document.getElementById('money-danh_muc').value.trim().substring(0, 100);
  const mo_ta = document.getElementById('money-mo_ta').value.trim().substring(0, 300);
  const ngay = document.getElementById('money-ngay').value;
  const so_tien = parseInt(document.getElementById('money-so_tien').value, 10) || 0;
  const ghi_chu = document.getElementById('money-ghi_chu').value.trim().substring(0, 80) || null;

  if (!danh_muc || !mo_ta || !ngay) {
    throw new Error('Vui lòng điền đầy đủ thông tin bắt buộc');
  }
  if (so_tien < 0 || so_tien > 999999999999) {
    throw new Error('Số tiền không hợp lệ');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ngay)) {
    throw new Error('Ngày chứng từ không hợp lệ');
  }

  return {
    danh_muc,
    mo_ta,
    ngay,
    so_tien,
    ghi_chu,
    thoi_gian: Date.now()
  };
}

function moneyHandleSubmit(e) {
  e.preventDefault();
  if (!moneyCurrentUser) {
    alert('Bạn chưa đăng nhập');
    return;
  }

  try {
    const type = document.getElementById('money-node-type').value;
    const payload = moneySanitizePayload();
    const ref = moneyGetUserRef(type);

    const promise = moneyCurrentEditKey 
      ? ref.child(moneyCurrentEditKey).update(payload)
      : ref.push(payload);

    promise
      .then(() => moneyHideModal())
      .catch(err => {
        alert('Lỗi lưu dữ liệu: ' + (err.message || 'Lỗi kết nối'));
      });
  } catch (err) {
    alert(err.message);
  }
}

function moneyDeleteItem(type, key) {
  if (!moneyCurrentUser) return;
  if (!confirm('Xóa vĩnh viễn chứng từ giao dịch này?')) return;

  moneyGetUserRef(type).child(key).remove()
    .catch(err => {
      alert('Không thể xóa: ' + (err.message || 'Lỗi quyền truy cập'));
    });
}

function moneyEscapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Load Firebase compat scripts then init
(function loadMoneyFirebase() {
  const scripts = [
    'https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js',
    'https://www.gstatic.com/firebasejs/9.22.0/firebase-auth-compat.js',
    'https://www.gstatic.com/firebasejs/9.22.0/firebase-database-compat.js'
  ];
  let loaded = 0;
  scripts.forEach(src => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => {
      loaded++;
      if (loaded === scripts.length) moneyInitFirebase();
    };
    document.head.appendChild(s);
  });
})();
