// ===================== UNIFIED APP CONTROLLER =====================
let currentModule = 'yduc';

function switchModule(mod) {
  currentModule = mod;

  // Update panels
  document.getElementById('module-yduc').classList.toggle('active', mod === 'yduc');
  document.getElementById('module-money').classList.toggle('active', mod === 'money');

  // Sidebar nav
  document.getElementById('nav-yduc')?.classList.toggle('active', mod === 'yduc');
  document.getElementById('nav-money')?.classList.toggle('active', mod === 'money');

  // Bottom nav
  const bottomY = document.getElementById('bottom-nav-yduc');
  const bottomM = document.getElementById('bottom-nav-money');
  if (bottomY && bottomM) {
    if (mod === 'yduc') {
      bottomY.className = 'flex-1 flex flex-col items-center justify-center py-2.5 text-indigo-600 font-semibold text-[11px] gap-0.5';
      bottomM.className = 'flex-1 flex flex-col items-center justify-center py-2.5 text-slate-400 font-semibold text-[11px] gap-0.5';
    } else {
      bottomM.className = 'flex-1 flex flex-col items-center justify-center py-2.5 text-indigo-600 font-semibold text-[11px] gap-0.5';
      bottomY.className = 'flex-1 flex flex-col items-center justify-center py-2.5 text-slate-400 font-semibold text-[11px] gap-0.5';
    }
  }

  // Mobile title
  const titleEl = document.getElementById('mobile-title');
  if (titleEl) {
    titleEl.textContent = mod === 'yduc' ? 'Hồ sơ Y Đức' : 'Sổ Thu Chi';
  }

  // Update user display
  updateUserDisplay();
}

function updateUserDisplay() {
  const sidebarUser = document.getElementById('sidebar-user');
  const mobileUser = document.getElementById('mobile-user');

  if (currentModule === 'yduc' && window.yducCurrentUser) {
    const name = window.yducCurrentUser.displayName || window.yducCurrentUser.email?.split('@')[0] || 'User';
    if (sidebarUser) sidebarUser.textContent = name;
    if (mobileUser) mobileUser.textContent = name;
  } else if (currentModule === 'money' && window.moneyCurrentUser) {
    const email = window.moneyCurrentUser.email || 'User';
    if (sidebarUser) sidebarUser.textContent = email;
    if (mobileUser) mobileUser.textContent = email;
  } else {
    if (sidebarUser) sidebarUser.textContent = 'Chưa đăng nhập';
    if (mobileUser) mobileUser.textContent = '';
  }
}

function logoutCurrent() {
  if (currentModule === 'yduc') {
    if (typeof yducLogout === 'function') yducLogout();
  } else {
    if (typeof moneyLogout === 'function') moneyLogout();
  }
  updateUserDisplay();
}

// Realtime clock (shared)
function startRealtimeClock() {
  function updateClock() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateString = now.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const clockEl = document.getElementById('realtime-clock');
    if (clockEl) clockEl.textContent = `${timeString} - ${dateString}`;
  }
  updateClock();
  setInterval(updateClock, 1000);
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  switchModule('yduc');
  startRealtimeClock();
});
