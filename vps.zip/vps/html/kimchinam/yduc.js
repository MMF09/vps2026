import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  updateProfile, signOut, onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getDatabase, ref, set, remove, onValue } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyC7HE94M-w9chHikRLxlAKMeYsR_71GBpc",
  authDomain: "fbamthucdouong.firebaseapp.com",
  databaseURL: "https://fbamthucdouong-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "fbamthucdouong",
  storageBucket: "fbamthucdouong.firebasestorage.app",
  messagingSenderId: "399700364963",
  appId: "1:399700364963:web:611971b25a87467fb7b916"
};

const app = initializeApp(firebaseConfig, "yduc-app");
const auth = getAuth(app);
const db = getDatabase(app);

let currentUser = null;
window.yducCurrentUser = null;
let rawDataCache = null; 
let allDataArray = [];   
let filteredDataArray = [];
let currentPage = 1;
const ITEMS_PER_PAGE = 10;
let isRegisterMode = false;
let searchDebounceTimer = null;

const DEFAULT_AVATAR = "https://cdn-icons-png.flaticon.com/512/149/149071.png";

const getDeviceDetails = () => {
  const ua = navigator.userAgent;
  let deviceType = "Máy tính (Desktop)";
  if (/mobile/i.test(ua)) deviceType = "Điện thoại (Mobile)";
  if (/tablet|ipad/i.test(ua)) deviceType = "Máy tính bảng (Tablet)";

  let os = "Không xác định OS";
  if (ua.indexOf("Win") !== -1) os = "Windows";
  else if (ua.indexOf("Mac") !== -1) os = "MacOS";
  else if (ua.indexOf("Linux") !== -1) os = "Linux";
  else if (ua.indexOf("Android") !== -1) os = "Android";
  else if (ua.indexOf("like Mac") !== -1) os = "iOS";

  let browser = "Khác";
  if (ua.indexOf("Edg") !== -1) browser = "Edge";
  else if (ua.indexOf("Chrome") !== -1) browser = "Chrome";
  else if (ua.indexOf("Firefox") !== -1) browser = "Firefox";
  else if (ua.indexOf("Safari") !== -1) browser = "Safari";
  else if (ua.indexOf("OPR") !== -1 || ua.indexOf("Opera") !== -1) browser = "Opera";

  return {
    deviceType,
    os,
    browser,
    screenResolution: `${window.screen.width}x${window.screen.height}`,
    language: navigator.language || navigator.userLanguage,
    platform: navigator.platform
  };
};

const currentDevice = getDeviceDetails();

document.getElementById("yduc-devType").textContent = currentDevice.deviceType;
document.getElementById("yduc-devBrowser").textContent = currentDevice.browser;
document.getElementById("yduc-devOS").textContent = currentDevice.os;
document.getElementById("yduc-devScreen").textContent = currentDevice.screenResolution;

const getUserIP = async () => {
  try {
    const res = await fetch("https://api64.ipify.org?format=json");
    const d = await res.json();
    document.getElementById("yduc-devIP").textContent = d.ip;
    return d.ip;
  } catch { 
    document.getElementById("yduc-devIP").textContent = "Ẩn danh";
    return "Ẩn danh"; 
  }
};
getUserIP();

const getTime = (code) => {
  const zones = {
    VN: "Asia/Ho_Chi_Minh",
    KR: "Asia/Seoul",
    CN: "Asia/Shanghai",
    JP: "Asia/Tokyo"
  };
  const localeMap = {
    VN: "vi-VN",
    KR: "ko-KR",
    CN: "zh-CN",
    JP: "ja-JP"
  };
  return new Date().toLocaleString(
    localeMap[code] || "vi-VN",
    { timeZone: zones[code] || "Asia/Ho_Chi_Minh" }
  );
};

const highlightText = (text, search) =>
  search ? String(text).replace(new RegExp(`(${search})`, 'gi'), '<span class="search-highlight">$1</span>') : text;

const calculateSimilarityFast = (s1, s2, threshold = 0.68) => {
  s1 = s1.toLowerCase().trim();
  s2 = s2.toLowerCase().trim();
  if (s1 === s2) return 1.0;
  
  const len1 = s1.length, len2 = s2.length;
  if (len1 === 0 || len2 === 0) return 0.0;

  const maxLen = Math.max(len1, len2);
  const maxAllowedDiff = Math.floor(maxLen * (1 - threshold));
  if (Math.abs(len1 - len2) > maxAllowedDiff) return 0.0;

  let v0 = new Int32Array(len2 + 1);
  let v1 = new Int32Array(len2 + 1);

  for (let i = 0; i <= len2; i++) v0[i] = i;

  for (let i = 0; i < len1; i++) {
    v1[0] = i + 1;
    let minDistance = v1[0];

    for (let j = 0; j < len2; j++) {
      const cost = s1[i] === s2[j] ? 0 : 1;
      v1[j + 1] = Math.min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost);
      if (v1[j + 1] < minDistance) minDistance = v1[j + 1];
    }

    if (minDistance > maxAllowedDiff) return 0.0;

    for (let j = 0; j <= len2; j++) v0[j] = v1[j];
  }

  return (maxLen - v0[len2]) / maxLen;
};

onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    window.yducCurrentUser = user;
    document.getElementById("yduc-auth").style.display = "none";
    document.getElementById("yduc-dashboard").classList.remove("hidden");

    const displayName = user.displayName || user.email.split('@')[0];
    
    document.getElementById("yduc-userName").textContent = displayName;
    document.getElementById("yduc-userEmail").textContent = user.email;
    document.getElementById("yduc-userAvatar").src = user.photoURL || DEFAULT_AVATAR;

    if (typeof updateUserDisplay === 'function') updateUserDisplay();

    onValue(ref(db, `users/${user.uid}/data`), (snapshot) => {
      rawDataCache = snapshot.exists() ? snapshot.val() : null;
      allDataArray = rawDataCache ? Object.entries(rawDataCache).map(([key, val]) => ({ key, ...val })) : [];
      document.getElementById("yduc-dataCount").textContent = allDataArray.length;
      
      applyFilterAndRender();
    });
  } else {
    currentUser = null;
    window.yducCurrentUser = null;
    rawDataCache = null;
    allDataArray = [];
    document.getElementById("yduc-auth").style.display = "block";
    document.getElementById("yduc-dashboard").classList.add("hidden");
    if (typeof updateUserDisplay === 'function') updateUserDisplay();
  }
});

window.yducToggleEmailMode = () => {
  isRegisterMode = !isRegisterMode;
  document.getElementById("yduc-displayNameGroup").style.display = isRegisterMode ? "block" : "none";
  document.getElementById("yduc-btnEmailLogin").innerHTML = isRegisterMode ? 
    '<i class="fas fa-user-plus"></i> Đăng ký' : '<i class="fas fa-sign-in-alt"></i> Đăng nhập';
  document.getElementById("yduc-emailToggleText").textContent = isRegisterMode ? "Đã có tài khoản?" : "Chưa có tài khoản?";
  document.getElementById("yduc-emailToggleBtn").textContent = isRegisterMode ? " Đăng nhập" : " Đăng ký ngay";
};

window.yducHandleEmailAuth = async () => {
  const email = document.getElementById("yduc-emailInput").value.trim();
  const pwd = document.getElementById("yduc-passwordInput").value.trim();
  const displayName = document.getElementById("yduc-displayNameInput").value.trim();

  if (!email || !pwd) return alert("Vui lòng nhập Email và Mật khẩu!");

  try {
    if (isRegisterMode) {
      if (!displayName) return alert("Vui lòng nhập tên hiển thị!");
      const res = await createUserWithEmailAndPassword(auth, email, pwd);
      await updateProfile(res.user, { displayName });
      alert("Đăng ký tài khoản thành công!");
    } else {
      await signInWithEmailAndPassword(auth, email, pwd);
    }
  } catch (err) { alert("Lỗi: " + err.message); }
};

window.yducLogout = () => signOut(auth);

window.yducOnSearchInput = () => {
  clearTimeout(searchDebounceTimer);
  searchDebounceTimer = setTimeout(() => {
    currentPage = 1;
    applyFilterAndRender();
  }, 150);
};

const applyFilterAndRender = () => {
  const query = document.getElementById("yduc-searchInput").value.toLowerCase().trim();
  
  if (!query) {
    filteredDataArray = allDataArray;
  } else {
    filteredDataArray = allDataArray.filter(d => 
      (d.sha && d.sha.toLowerCase().includes(query)) ||
      (d.sha512 && d.sha512.toLowerCase().includes(query)) ||
      (d.hashedKey && d.hashedKey.toLowerCase().includes(query)) ||
      (d.deviceInfo && (
        d.deviceInfo.os.toLowerCase().includes(query) ||
        d.deviceInfo.browser.toLowerCase().includes(query) ||
        d.deviceInfo.deviceType.toLowerCase().includes(query)
      ))
    );
  }
  
  renderPage();
};

const renderPage = () => {
  const tbody = document.getElementById("yduc-dataTable");
  const paginationBar = document.getElementById("yduc-paginationBar");
  const searchWord = document.getElementById("yduc-searchInput").value.toLowerCase().trim();

  const totalItems = filteredDataArray.length;
  if (totalItems === 0) {
    tbody.innerHTML = `<tr><td colspan="3" class="empty-state">
      <i class="fas fa-search"></i><p>Chưa có dữ liệu nào trong kho cá nhân</p>
    </td></tr>`;
    paginationBar.style.display = "none";
    return;
  }

  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE) || 1;
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;

  const start = (currentPage - 1) * ITEMS_PER_PAGE;
  const end = Math.min(start + ITEMS_PER_PAGE, totalItems);
  const pageData = filteredDataArray.slice(start, end);

  const fragment = document.createDocumentFragment();
  pageData.forEach(d => {
    const tr = document.createElement("tr");
    
    const devInfo = d.deviceInfo || {};
    const devBadge = devInfo.deviceType ? 
      `<span class="device-badge"><i class="fas fa-desktop"></i> ${devInfo.deviceType} | ${devInfo.os} | ${devInfo.browser} (${devInfo.screenResolution})</span>` : '';

    tr.innerHTML = `
      <td class="hash-cell">
        <div><strong>SHA-256:</strong> ${highlightText(d.sha || "N/A", searchWord)}</div>
        <div style="margin-top:2px;"><strong>SHA-512:</strong> ${highlightText(d.sha512 || "N/A", searchWord)}</div>
        <div class="meta-info">
          <span><i class="far fa-clock"></i> VN: ${d.timeVN || "—"}</span>
          <span><i class="far fa-clock"></i> KR: ${d.timeKR || "—"}</span>
          <span><i class="far fa-clock"></i> JP: ${d.timeJP || "—"}</span>
        </div>
      </td>
      <td class="hash-cell">
        ${highlightText(d.hashedKey || "N/A", searchWord)}
        <div class="meta-info" style="margin-top: 6px;">
          <span><i class="fas fa-globe"></i> IP: ${d.ip || "Unknown"}</span>
        </div>
        <div class="meta-info" style="margin-top: 4px;">
          ${devBadge}
        </div>
      </td>
      <td>
        <button class="danger" onclick="yducDeleteData('${d.key}')">
          <i class="fas fa-trash-alt"></i> Xóa
        </button>
      </td>
    `;
    fragment.appendChild(tr);
  });

  tbody.innerHTML = "";
  tbody.appendChild(fragment);

  document.getElementById("yduc-pageFrom").textContent = start + 1;
  document.getElementById("yduc-pageTo").textContent = end;
  document.getElementById("yduc-pageTotal").textContent = totalItems;
  document.getElementById("yduc-currentPageDisplay").textContent = currentPage;

  document.getElementById("yduc-btnPrev").disabled = currentPage <= 1;
  document.getElementById("yduc-btnNext").disabled = currentPage >= totalPages;

  const pageNumbers = document.getElementById("yduc-pageNumbers");
  pageNumbers.innerHTML = "";
  
  const maxVisible = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
  let endPage = Math.min(totalPages, startPage + maxVisible - 1);
  if (endPage - startPage + 1 < maxVisible) startPage = Math.max(1, endPage - maxVisible + 1);

  for (let i = startPage; i <= endPage; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.className = (i === currentPage) ? "active" : "";
    btn.onclick = () => { currentPage = i; renderPage(); };
    pageNumbers.appendChild(btn);
  }

  paginationBar.style.display = "flex";
};

window.yducChangePage = (delta) => {
  currentPage += delta;
  renderPage();
};

window.yducAddData = async () => {
  if (!currentUser) return;
  const input = document.getElementById("yduc-dataInput");
  const data = input.value.trim();
  if (!data) return alert("Vui lòng nhập thông tin!"), input.focus();

  if (rawDataCache) {
    const values = Object.values(rawDataCache);
    for (let i = 0; i < values.length; i++) {
      if (values[i].original) {
        const sim = calculateSimilarityFast(data, values[i].original, 0.68);
        if (sim > 0.68) {
          alert(`Nội dung tương đồng ${(sim * 100).toFixed(1)}% với hồ sơ đã có!\nHệ thống từ chối ghi nhận trùng lặp.`);
          return;
        }
      }
    }
  }

  const md5Key = CryptoJS.MD5(data).toString();
  const recordRef = ref(db, `users/${currentUser.uid}/data/${md5Key}`);

  try {
    await set(recordRef, {
      sha: CryptoJS.SHA256(data).toString(),
      sha512: CryptoJS.SHA512(data).toString(),
      original: data,
      hashedKey: md5Key,
      ip: await getUserIP(),
      deviceInfo: currentDevice,
      timeVN: getTime("VN"),
      timeKR: getTime("KR"),
      timeCN: getTime("CN"),
      timeJP: getTime("JP")
    });

    input.value = "";
    input.focus();
  } catch (err) {
    alert("Lỗi phân quyền hoặc ghi dữ liệu: " + err.message);
  }
};

window.yducDeleteData = (key) => {
  if (!currentUser) return;
  if (confirm("Xác nhận xóa bản ghi này khỏi cơ sở dữ liệu?")) {
    remove(ref(db, `users/${currentUser.uid}/data/${key}`));
  }
};

window.yducShowModal = id => document.getElementById(id).style.display = "block";
window.yducHideModal = id => {
  document.getElementById(id).style.display = "none";
  document.getElementById(id === "yduc-backupModal" ? "yduc-backupPassword" : "yduc-importPassword").value = "";
};

window.yducUpdateFileLabel = (input) => {
  const label = document.getElementById("yduc-fileLabel");
  if (input.files && input.files[0]) {
    label.innerHTML = `<i class="fas fa-file-code"></i> ${input.files[0].name}`;
  } else {
    label.innerHTML = `<i class="fas fa-cloud-upload-alt"></i> Chọn file JSON backup`;
  }
};

window.yducPerformBackup = () => {
  const pwd = document.getElementById("yduc-backupPassword").value;
  if (!pwd) return alert("Vui lòng nhập mật khẩu mã hóa!");
  if (!rawDataCache) {
    yducHideModal("yduc-backupModal");
    return alert("Chưa có bản ghi nào để xuất backup!");
  }

  try {
    const encrypted = {};
    Object.keys(rawDataCache).forEach(key => {
      const item = rawDataCache[key];
      encrypted[key] = {
        ...item,
        original: CryptoJS.AES.encrypt(String(item.original || ""), pwd).toString()
      };
    });

    const blob = new Blob([JSON.stringify(encrypted, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `YDucDB-Backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    yducHideModal("yduc-backupModal");
  } catch (err) { alert("Lỗi khi tạo tập tin mã hóa: " + err.message); }
};

window.yducPerformImport = () => {
  const pwd = document.getElementById("yduc-importPassword").value;
  const file = document.getElementById("yduc-fileInput").files[0];
  if (!pwd || !file) return alert("Vui lòng chọn file và nhập mật khẩu giải mã!");

  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      let success = 0, skipped = 0;
      const currentOriginals = rawDataCache ? Object.values(rawDataCache).map(v => v.original).filter(Boolean) : [];

      for (const key of Object.keys(imported)) {
        const item = imported[key];
        const decrypted = CryptoJS.AES.decrypt(item.original, pwd).toString(CryptoJS.enc.Utf8);
        if (!decrypted) continue;

        let isDup = false;
        for (let i = 0; i < currentOriginals.length; i++) {
          if (calculateSimilarityFast(decrypted, currentOriginals[i], 0.68) > 0.68) {
            isDup = true;
            break;
          }
        }

        if (!isDup) {
          const md5Key = item.hashedKey || CryptoJS.MD5(decrypted).toString();
          await set(ref(db, `users/${currentUser.uid}/data/${md5Key}`), {
            ...item,
            sha512: item.sha512 || CryptoJS.SHA512(decrypted).toString(),
            original: decrypted,
            deviceInfo: item.deviceInfo || currentDevice,
            timeVN: item.timeVN || getTime("VN"),
            timeKR: item.timeKR || getTime("KR"),
            timeCN: item.timeCN || getTime("CN"),
            timeJP: item.timeJP || getTime("JP")
          });
          currentOriginals.push(decrypted);
          success++;
        } else {
          skipped++;
        }
      }

      alert(`Khôi phục thành công ${success} bản ghi.` + (skipped ? ` (Bỏ qua ${skipped} dữ liệu trùng lắp >68%)` : ""));
      yducHideModal("yduc-importModal");
      document.getElementById("yduc-fileInput").value = "";
      document.getElementById("yduc-fileLabel").innerHTML = `<i class="fas fa-cloud-upload-alt"></i> Chọn file JSON backup`;
    } catch {
      alert("Lỗi giải mã: Mật khẩu không chính xác hoặc định dạng tệp không khớp!");
    }
  };
  reader.readAsText(file);
};

document.getElementById("yduc-dataInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") yducAddData();
});

window.onclick = e => {
  if (e.target.className === "modal") yducHideModal(e.target.id);
};
