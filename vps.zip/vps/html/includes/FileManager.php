<?php
/**
 * FileManager
 * -----------
 * Quản lý file/thư mục bên trong BASE_DIR một cách an toàn:
 * - Chống path traversal (../, đường dẫn ra ngoài thư mục gốc)
 * - Kiểm tra định dạng, kích thước khi upload
 * - Làm sạch tên file để tránh ký tự nguy hiểm
 */
class FileManager
{
    private $baseDir;

    public function __construct($baseDir)
    {
        $this->baseDir = rtrim($baseDir, '/');
        if (!is_dir($this->baseDir)) {
            mkdir($this->baseDir, 0755, true);
        }
    }

    public function listFiles($subdir = '')
    {
        $dir = $this->resolveDir($subdir);
        $items = [];

        foreach (scandir($dir) as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $full = $dir . '/' . $entry;
            $items[] = [
                'name'      => $entry,
                'is_dir'    => is_dir($full),
                'size'      => is_file($full) ? filesize($full) : 0,
                'modified'  => date('d/m/Y H:i', filemtime($full)),
                'extension' => is_file($full) ? strtolower(pathinfo($entry, PATHINFO_EXTENSION)) : null,
            ];
        }

        usort($items, function ($a, $b) {
            if ($a['is_dir'] !== $b['is_dir']) {
                return $b['is_dir'] <=> $a['is_dir'];
            }
            return strcasecmp($a['name'], $b['name']);
        });

        return $items;
    }

    public function upload(array $file, $subdir = '')
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException($this->uploadErrorMessage($file['error']));
        }
        if ($file['size'] > MAX_FILE_SIZE) {
            throw new InvalidArgumentException('File vượt quá kích thước cho phép (' . $this->humanSize(MAX_FILE_SIZE) . ')');
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ALLOWED_EXTENSIONS, true)) {
            throw new InvalidArgumentException("Định dạng .$ext không được hỗ trợ");
        }

        $dir = $this->resolveDir($subdir);
        $safeName = $this->sanitizeName($file['name']);
        $target = $this->avoidCollision($dir . '/' . $safeName);

        if (!is_uploaded_file($file['tmp_name']) || !move_uploaded_file($file['tmp_name'], $target)) {
            throw new RuntimeException('Không thể lưu file lên máy chủ');
        }

        return basename($target);
    }

    public function delete($subdir, $name)
    {
        $dir = $this->resolveDir($subdir);
        $target = $dir . '/' . $this->sanitizeName($name);

        if (!file_exists($target)) {
            throw new InvalidArgumentException("File hoặc thư mục không tồn tại: $name");
        }

        if (is_dir($target)) {
            $this->deleteRecursive($target);
        } else {
            unlink($target);
        }
        return true;
    }

    public function rename($subdir, $oldName, $newName)
    {
        $dir = $this->resolveDir($subdir);
        $old = $dir . '/' . $this->sanitizeName($oldName);
        $new = $dir . '/' . $this->sanitizeName($newName);

        if (!file_exists($old)) {
            throw new InvalidArgumentException('Mục nguồn không tồn tại');
        }
        if (file_exists($new)) {
            throw new InvalidArgumentException('Tên đích đã tồn tại');
        }
        rename($old, $new);
        return true;
    }

    public function makeDir($subdir, $name)
    {
        $dir = $this->resolveDir($subdir);
        $target = $dir . '/' . $this->sanitizeName($name);

        if (file_exists($target)) {
            throw new InvalidArgumentException('Thư mục đã tồn tại');
        }
        mkdir($target, 0755);
        return true;
    }

    private function deleteRecursive($dir)
    {
        foreach (scandir($dir) as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $full = $dir . '/' . $entry;
            is_dir($full) ? $this->deleteRecursive($full) : unlink($full);
        }
        rmdir($dir);
    }

    private function avoidCollision($path)
    {
        if (!file_exists($path)) {
            return $path;
        }
        $info = pathinfo($path);
        $i = 1;
        do {
            $candidate = $info['dirname'] . '/' . $info['filename'] . '_' . $i .
                (isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : '');
            $i++;
        } while (file_exists($candidate));
        return $candidate;
    }

    private function sanitizeName($name)
    {
        $name = basename((string) $name);
        $name = preg_replace('/[^A-Za-z0-9\.\-\_ ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠ-ỹ]/u', '_', $name);
        $name = trim($name);
        return $name === '' ? 'file' : $name;
    }

    private function resolveDir($subdir)
    {
        $subdir = str_replace(['..', '\\'], '', (string) $subdir);
        $dir = $this->baseDir . '/' . trim($subdir, '/');

        if (!is_dir($dir)) {
            throw new InvalidArgumentException("Thư mục không tồn tại: /$subdir");
        }

        $real = realpath($dir);
        $realBase = realpath($this->baseDir);
        if ($real === false || strpos($real, $realBase) !== 0) {
            throw new RuntimeException('Đường dẫn không hợp lệ (phát hiện path traversal)');
        }
        return $real;
    }

    private function uploadErrorMessage($code)
    {
        switch ($code) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'File vượt quá kích thước cho phép';
            case UPLOAD_ERR_PARTIAL:
                return 'File chỉ được tải lên một phần';
            case UPLOAD_ERR_NO_FILE:
                return 'Không có file nào được chọn';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Thiếu thư mục tạm trên máy chủ';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Không thể ghi file lên đĩa';
            default:
                return "Lỗi tải file không xác định (mã $code)";
        }
    }

    private function humanSize($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < 3) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 1) . ' ' . $units[$i];
    }
}
