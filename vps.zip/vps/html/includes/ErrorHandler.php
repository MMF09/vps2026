<?php
/**
 * ErrorHandler
 * ------------
 * Bắt toàn bộ lỗi PHP (notice/warning/error) + exception + fatal error (qua shutdown function),
 * ghi log tập trung và PHÂN LUỒNG thông báo theo mức độ nghiêm trọng:
 *
 *   INFO      -> chỉ ghi log (không làm phiền người dùng)
 *   WARNING   -> ghi log + đẩy thông báo dạng "toast" cho giao diện
 *   ERROR     -> ghi log + đẩy thông báo dạng "toast" (nổi bật hơn)
 *   CRITICAL  -> ghi log + đẩy thông báo + bắn cảnh báo ra kênh ngoài (webhook/email...)
 *
 * Giao diện (JS) lấy thông báo qua api/notifications.php và tự route hiển thị
 * (console.log / toast / alert) tương ứng với từng mức.
 */
class ErrorHandler
{
    const LEVEL_INFO = 'info';
    const LEVEL_WARNING = 'warning';
    const LEVEL_ERROR = 'error';
    const LEVEL_CRITICAL = 'critical';

    private static $logFile;

    public static function init($logDir)
    {
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        self::$logFile = rtrim($logDir, '/') . '/app.log';

        set_error_handler([self::class, 'onError']);
        set_exception_handler([self::class, 'onException']);
        register_shutdown_function([self::class, 'onShutdown']);
    }

    /** Bắt lỗi PHP thông thường (notice, warning, deprecated...) */
    public static function onError($errno, $errstr, $errfile, $errline)
    {
        if (!(error_reporting() & $errno)) {
            return false; // lỗi bị @-suppressed
        }
        $level = self::mapErrno($errno);
        self::route($level, $errstr, ['file' => $errfile, 'line' => $errline]);
        return true; // ngăn PHP in lỗi thô ra output
    }

    /** Bắt exception không được try/catch bắt lại */
    public static function onException($e)
    {
        self::route(self::LEVEL_CRITICAL, $e->getMessage(), [
            'file'  => $e->getFile(),
            'line'  => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);
    }

    /** Bắt fatal error khi script kết thúc bất thường */
    public static function onShutdown()
    {
        $err = error_get_last();
        if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            self::route(self::LEVEL_CRITICAL, $err['message'], $err);
        }
    }

    private static function mapErrno($errno)
    {
        switch ($errno) {
            case E_NOTICE:
            case E_USER_NOTICE:
            case E_DEPRECATED:
            case E_USER_DEPRECATED:
                return self::LEVEL_INFO;
            case E_WARNING:
            case E_USER_WARNING:
                return self::LEVEL_WARNING;
            default:
                return self::LEVEL_ERROR;
        }
    }

    /**
     * Điểm phân luồng trung tâm: mọi lỗi trong hệ thống đều nên đi qua đây.
     */
    public static function route($level, $message, array $context = [])
    {
        self::writeLog($level, $message, $context);

        switch ($level) {
            case self::LEVEL_INFO:
                // chỉ log, không làm phiền người dùng
                break;

            case self::LEVEL_WARNING:
            case self::LEVEL_ERROR:
                self::pushNotification($level, $message);
                break;

            case self::LEVEL_CRITICAL:
                self::pushNotification($level, $message);
                self::alertExternalChannel($level, $message, $context);
                break;
        }
    }

    private static function writeLog($level, $message, array $context)
    {
        $line = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            strtoupper($level),
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_UNICODE) : ''
        );
        @file_put_contents(self::$logFile, $line, FILE_APPEND | LOCK_EX);
    }

    private static function pushNotification($level, $message)
    {
        self::ensureSession();
        $_SESSION['notifications'][] = [
            'level'   => $level,
            'message' => $message,
            'time'    => date('H:i:s'),
        ];
        // giới hạn hàng đợi, tránh phình session
        if (count($_SESSION['notifications']) > 50) {
            array_shift($_SESSION['notifications']);
        }
    }

    /** Kênh cảnh báo ngoài cho lỗi CRITICAL (webhook, email...) - có thể mở rộng */
    private static function alertExternalChannel($level, $message, array $context)
    {
        $hook = getenv('ERROR_WEBHOOK_URL');
        if ($hook) {
            $ctx = stream_context_create(['http' => ['timeout' => 1]]);
            @file_get_contents($hook . '?level=' . urlencode($level) . '&msg=' . urlencode($message), false, $ctx);
        }
        // Có thể bổ sung: gửi mail(), ghi vào bảng cảnh báo riêng, gọi Slack API, v.v.
    }

    /** Helper dùng trong các endpoint API: log + trả JSON lỗi + dừng script */
    public static function jsonError($level, $message, $httpCode = 400)
    {
        self::route($level, $message);
        if (!headers_sent()) {
            http_response_code($httpCode);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(['success' => false, 'level' => $level, 'message' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /** Lấy hàng đợi thông báo hiện tại (mặc định sẽ xoá sau khi lấy) */
    public static function getNotifications($clear = true)
    {
        self::ensureSession();
        $list = $_SESSION['notifications'] ?? [];
        if ($clear) {
            $_SESSION['notifications'] = [];
        }
        return $list;
    }

    private static function ensureSession()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_start();
        }
    }
}
