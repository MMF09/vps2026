<?php
/**
 * Cấu hình chung của ứng dụng
 */

// Thư mục lưu trữ file người dùng quản lý (upload)
define('BASE_DIR', __DIR__ . '/../uploads');

/**
 * Thư mục QUÉT trên server để phân tích dữ liệu & biểu đồ.
 * Mặc định: toàn bộ thư mục dự án (file-manager/) — có dữ liệu thật, không phụ thuộc upload.
 * Có thể đổi thành đường dẫn tuyệt đối khác trên server, ví dụ: '/var/www/html'
 */
define('SCAN_DIR', realpath(__DIR__ . '/..') ?: (__DIR__ . '/..'));

// Thư mục ghi log lỗi
define('LOG_DIR', __DIR__ . '/../logs');

// Danh sách phần mở rộng được phép tải lên
define('ALLOWED_EXTENSIONS', [
    'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp',
    'pdf', 'txt', 'md', 'csv',
    'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    'zip', 'rar', '7z',
    'mp3', 'mp4', 'wav',
    'php', 'js', 'css', 'html', 'json', 'xml',
]);

// Kích thước file tối đa (byte) - 20MB
define('MAX_FILE_SIZE', 20 * 1024 * 1024);

// (Tuỳ chọn) Webhook nhận cảnh báo mức CRITICAL
if (!getenv('ERROR_WEBHOOK_URL')) {
    putenv('ERROR_WEBHOOK_URL=');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
