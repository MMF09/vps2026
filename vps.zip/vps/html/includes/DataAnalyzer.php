<?php
/**
 * DataAnalyzer
 * ------------
 * Quét TOÀN BỘ thư mục trên server (đệ quy) và tính toán thống kê
 * phục vụ biểu đồ: phân bố theo định dạng, kích thước, tháng, file lớn nhất.
 *
 * Không phụ thuộc upload — quét file có sẵn trên máy chủ.
 */
class DataAnalyzer
{
    private $baseDir;

    /** Thư mục / tên file bỏ qua khi quét */
    private $skipNames = ['.', '..', '.git', '.svn', 'node_modules', 'vendor', '.idea', '.vscode'];

    public function __construct($baseDir)
    {
        $this->baseDir = rtrim($baseDir, '/\\');
    }

    public function analyze()
    {
        $files = $this->scanRecursive($this->baseDir);

        $totalSize = 0;
        $byExt = [];
        $bySizeRange = ['<100KB' => 0, '100KB-1MB' => 0, '1MB-10MB' => 0, '>10MB' => 0];
        $byMonth = [];

        foreach ($files as $f) {
            $totalSize += $f['size'];

            $ext = $f['extension'] !== '' ? $f['extension'] : '(không rõ)';
            $byExt[$ext] = ($byExt[$ext] ?? 0) + 1;

            $sizeKB = $f['size'] / 1024;
            if ($sizeKB < 100) {
                $bySizeRange['<100KB']++;
            } elseif ($sizeKB < 1024) {
                $bySizeRange['100KB-1MB']++;
            } elseif ($sizeKB < 10240) {
                $bySizeRange['1MB-10MB']++;
            } else {
                $bySizeRange['>10MB']++;
            }

            $month = date('Y-m', $f['modified']);
            $byMonth[$month] = ($byMonth[$month] ?? 0) + 1;
        }

        ksort($byMonth);
        arsort($byExt);

        $largest = $files;
        usort($largest, function ($a, $b) {
            return $b['size'] <=> $a['size'];
        });
        $largest = array_slice($largest, 0, 10);

        return [
            'scan_dir'         => $this->baseDir,
            'total_files'      => count($files),
            'total_size'       => $totalSize,
            'total_size_human' => $this->humanSize($totalSize),
            'by_extension'     => $byExt,
            'by_size_range'    => $bySizeRange,
            'by_month'         => $byMonth,
            'largest_files'    => array_map(function ($f) {
                return [
                    'name'       => $f['relative'],
                    'size'       => $f['size'],
                    'size_human' => $this->humanSize($f['size']),
                    'modified'   => date('d/m/Y H:i', $f['modified']),
                    'extension'  => $f['extension'],
                ];
            }, $largest),
            'all_files'        => array_map(function ($f) {
                return [
                    'name'       => $f['relative'],
                    'size'       => $f['size'],
                    'size_human' => $this->humanSize($f['size']),
                    'modified'   => date('d/m/Y H:i', $f['modified']),
                    'extension'  => $f['extension'],
                    'is_dir'     => false,
                ];
            }, $files),
        ];
    }

    /**
     * Quét đệ quy toàn bộ file trong thư mục (bỏ qua thư mục hệ thống)
     */
    private function scanRecursive($dir, $relativePrefix = '')
    {
        $result = [];
        if (!is_dir($dir) || !is_readable($dir)) {
            return $result;
        }

        $entries = @scandir($dir);
        if ($entries === false) {
            return $result;
        }

        foreach ($entries as $entry) {
            if (in_array($entry, $this->skipNames, true)) {
                continue;
            }
            // Bỏ qua file ẩn kiểu .htaccess, .gitkeep nếu muốn — vẫn giữ để có dữ liệu
            $full = $dir . DIRECTORY_SEPARATOR . $entry;
            $rel = $relativePrefix === '' ? $entry : $relativePrefix . '/' . $entry;

            if (is_dir($full)) {
                $result = array_merge($result, $this->scanRecursive($full, $rel));
            } elseif (is_file($full) && is_readable($full)) {
                $size = @filesize($full);
                $mtime = @filemtime($full);
                if ($size === false) {
                    continue;
                }
                $result[] = [
                    'relative'  => $rel,
                    'size'      => (int) $size,
                    'modified'  => $mtime !== false ? (int) $mtime : time(),
                    'extension' => strtolower(pathinfo($entry, PATHINFO_EXTENSION)),
                ];
            }
        }
        return $result;
    }

    private function humanSize($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        $bytes = (float) $bytes;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
}
