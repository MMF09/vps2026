<?php
/**
 * =====================================================================
 *  TRANG GIỚI THIỆU BẢN THÂN + PORTFOLIO — LẬP TRÌNH VIÊN
 * =====================================================================
 *  Toàn bộ nội dung nằm trong các mảng bên dưới. Bạn chỉ cần sửa
 *  giá trị trong các mảng $profile, $skills, $projects, $experience,
 *  $contact — không cần đụng vào phần HTML/CSS phía dưới.
 * =====================================================================
 */

$profile = [
    'name'     => 'CHU CHỈ NHƯỢC',
    'role'     => 'Lập trình viên Full-stack',
    'location' => 'Hà Nội, Việt Nam',
    'status'   => 'Sẵn sàng nhận dự án mới',
    'tagline'  => 'Xây dựng sản phẩm web từ ý tưởng đến khi chạy thật ngoài đời.',
    'bio'      => 'Mình là lập trình viên full-stack với hơn 3 năm kinh nghiệm làm việc với PHP, JavaScript và các hệ thống backend. Mình thích biến những yêu cầu còn mơ hồ thành sản phẩm chạy ổn định và dễ bảo trì. Ngoài giờ code, mình đọc về kiến trúc hệ thống và thỉnh thoảng đóng góp cho vài dự án mã nguồn mở nhỏ.',
];

$skills = [
    'frontend' => ['JavaScript', 'React', 'TailwindCSS', 'HTML/CSS'],
    'backend'  => ['PHP', 'Laravel', 'Node.js', 'MySQL'],
    'devops'   => ['Git', 'Docker', 'Linux', 'Nginx'],
];

$projects = [
    [
        'name' => 'quan-ly-ban-hang/',
        'desc' => 'Hệ thống quản lý bán hàng cho cửa hàng nhỏ: quản lý kho, hóa đơn, báo cáo doanh thu theo thời gian thực.',
        'tech' => ['PHP', 'MySQL', 'JavaScript'],
        'link' => '#',
    ],
    [
        'name' => 'api-thoi-tiet/',
        'desc' => 'RESTful API tổng hợp dữ liệu thời tiết từ nhiều nguồn, có cơ chế cache để giảm tải cho server gốc.',
        'tech' => ['Node.js', 'Redis', 'Express'],
        'link' => '#',
    ],
    [
        'name' => 'blog-ca-nhan/',
        'desc' => 'Nền tảng blog cá nhân hỗ trợ Markdown, tìm kiếm full-text và giao diện tối giản.',
        'tech' => ['PHP', 'SQLite'],
        'link' => '#',
    ],
];

// Mỗi mốc kinh nghiệm được viết như một bản changelog phần mềm.
// type 'add' = việc đã làm được / type 'change' = cải tiến, tối ưu.
$experience = [
    [
        'version' => 'v3.0.0',
        'date'    => '2023 — hiện tại',
        'role'    => 'Lập trình viên Backend',
        'company' => 'Công ty TNHH Công nghệ',
        'changes' => [
            ['type' => 'add',    'text' => 'Xây dựng hệ thống thanh toán xử lý hơn 10.000 giao dịch/ngày.'],
            ['type' => 'add',    'text' => 'Thiết kế API cho ứng dụng di động, phục vụ 50.000 người dùng.'],
            ['type' => 'change', 'text' => 'Tối ưu truy vấn database, giảm 40% thời gian phản hồi.'],
        ],
    ],
    [
        'version' => 'v2.0.0',
        'date'    => '2021 — 2023',
        'role'    => 'Lập trình viên Full-stack',
        'company' => 'Startup ',
        'changes' => [
            ['type' => 'add', 'text' => 'Tham gia xây dựng sản phẩm MVP từ giai đoạn đầu.'],
            ['type' => 'add', 'text' => 'Phát triển giao diện quản trị nội bộ bằng React.'],
        ],
    ],
    [
        'version' => 'v1.0.0',
        'date'    => '2020',
        'role'    => 'Tốt nghiệp Công nghệ Thông tin',
        'company' => 'Đại học Bách Khoa Hà Nội',
        'changes' => [
            ['type' => 'add', 'text' => 'Bắt đầu hành trình với lập trình web.'],
        ],
    ],
];

$contact = [
    'email'    => 'ccc@example.com',
    'github'   => 'https://github.com/ccc',
    'linkedin' => 'https://linkedin.com/in/ccc',
    'phone'    => '090 000 0000',
];

/**
 * =====================================================================
 *  XỬ LÝ FORM LIÊN HỆ
 *  Dùng hàm mail() có sẵn của PHP. Hàm này CẦN server đã cấu hình SMTP
 *  (mục sendmail_path trong php.ini) mới gửi được thư thật. Nếu bạn
 *  host trên hosting/localhost chưa cấu hình mail, form vẫn hoạt động
 *  bình thường nhưng email sẽ không thực sự được gửi đi — khi đó nên
 *  thay thế đoạn mail() bên dưới bằng thư viện PHPMailer + SMTP.
 * =====================================================================
 */
$form_message = '';
$form_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    $sender_name  = trim($_POST['name'] ?? '');
    $sender_email = trim($_POST['email'] ?? '');
    $sender_msg   = trim($_POST['message'] ?? '');

    if ($sender_name === '' || $sender_email === '' || $sender_msg === '') {
        $form_message = 'Vui lòng điền đầy đủ các trường bên dưới.';
    } elseif (!filter_var($sender_email, FILTER_VALIDATE_EMAIL)) {
        $form_message = 'Địa chỉ email không hợp lệ.';
    } else {
        $to      = $contact['email'];
        $subject = 'Liên hệ từ portfolio — ' . $sender_name;
        $body    = "Tên: {$sender_name}\nEmail: {$sender_email}\n\nNội dung:\n{$sender_msg}";
        $headers = 'From: ' . $sender_email . "\r\n" . 'Reply-To: ' . $sender_email;

        // @ để tránh warning hiển thị ra trang khi mail() chưa được cấu hình.
        $sent = @mail($to, $subject, $body, $headers);

        if ($sent) {
            $form_success = true;
            $form_message = 'Cảm ơn ' . $sender_name . '! Tin nhắn đã được gửi.';
        } else {
            $form_message = 'Server chưa cấu hình gửi mail. Bạn có thể liên hệ trực tiếp qua email bên dưới.';
        }
    }
}

/** Hàm rút gọn để escape output an toàn. */
function h($str) {
    return htmlspecialchars((string) $str, ENT_QUOTES, 'UTF-8');
}

/** Lấy chữ cái đầu của tên để làm avatar dạng chữ. */
function initials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $last  = end($parts);
    $first = $parts[0];
    $chars = mb_substr($first, 0, 1) . mb_substr($last, 0, 1);
    return mb_strtoupper($chars, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($profile['name']) ?> — <?= h($profile['role']) ?></title>
<meta name="description" content="<?= h($profile['tagline']) ?>">
<style>
  :root {
    --bg: #0f1115;
    --panel: #161920;
    --panel-2: #1c2028;
    --border: #262b33;
    --text: #e6e8eb;
    --text-muted: #8a919c;
    --text-faint: #565d68;
    --accent: #5fb3b3;
    --accent-soft: rgba(95, 179, 179, 0.12);
    --diff-add: #6fb56f;
    --diff-add-bg: rgba(78, 154, 81, 0.08);
    --diff-change: #d1935f;
    --diff-change-bg: rgba(201, 122, 74, 0.08);
    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    --font-mono: ui-monospace, "SFMono-Regular", "JetBrains Mono", "Fira Code", Consolas, "Liberation Mono", monospace;
  }

  * { box-sizing: border-box; }

  html { -webkit-text-size-adjust: 100%; }

  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: var(--font-sans);
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }

  a { color: var(--accent); }
  a:focus-visible, button:focus-visible, input:focus-visible, textarea:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  .wrap {
    max-width: 720px;
    margin: 0 auto;
    padding: 4rem 1.5rem 6rem;
  }

  .file-label {
    font-family: var(--font-mono);
    font-size: 0.8rem;
    color: var(--text-faint);
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin: 0 0 0.9rem;
  }
  .file-label::before {
    content: "";
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--accent);
    flex-shrink: 0;
  }

  section { margin-top: 3.5rem; }
  section:first-of-type { margin-top: 0; }

  /* ---------- Hero ---------- */
  .hero-top {
    display: flex;
    align-items: center;
    gap: 1.1rem;
  }
  .avatar {
    width: 56px;
    height: 56px;
    border-radius: 10px;
    background: var(--accent-soft);
    border: 1px solid var(--border);
    color: var(--accent);
    font-family: var(--font-mono);
    font-weight: 600;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }
  h1 {
    font-size: clamp(1.9rem, 4.5vw, 2.5rem);
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0 0 0.2rem;
  }
  .meta-row {
    color: var(--text-muted);
    font-size: 0.95rem;
  }
  .tagline {
    margin-top: 1.4rem;
    font-size: 1.2rem;
    color: var(--text);
    max-width: 34ch;
    line-height: 1.45;
  }
  .cursor {
    display: inline-block;
    width: 0.55ch;
    background: var(--accent);
    margin-left: 2px;
    animation: blink 1.1s steps(1) infinite;
  }
  @keyframes blink { 50% { opacity: 0; } }
  @media (prefers-reduced-motion: reduce) {
    .cursor { animation: none; }
  }

  .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    border: 1px solid var(--border);
    background: var(--panel);
    color: var(--text-muted);
    font-size: 0.82rem;
    padding: 0.3rem 0.7rem;
    border-radius: 999px;
    margin-top: 1.2rem;
  }
  .status-pill::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--diff-add);
  }

  /* ---------- README / bio ---------- */
  .bio {
    color: var(--text-muted);
    max-width: 62ch;
    font-size: 1rem;
  }

  /* ---------- skills.json ---------- */
  .json-block {
    font-family: var(--font-mono);
    font-size: 0.88rem;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.2rem 1.4rem;
    overflow-x: auto;
    line-height: 1.75;
    white-space: pre;
  }
  .jkey { color: var(--accent); }
  .jstr { color: #c9d1a8; }
  .jpunc { color: var(--text-faint); }

  /* ---------- projects ---------- */
  .project {
    padding: 1.3rem 0;
    border-top: 1px solid var(--border);
  }
  .project:last-child { padding-bottom: 0; }
  .project-name {
    font-family: var(--font-mono);
    font-size: 1rem;
    color: var(--text);
    margin: 0 0 0.4rem;
  }
  .project-desc {
    color: var(--text-muted);
    font-size: 0.95rem;
    margin: 0 0 0.8rem;
    max-width: 58ch;
  }
  .tech-row {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 0.7rem;
  }
  .tech-tag {
    font-family: var(--font-mono);
    font-size: 0.76rem;
    color: var(--text-muted);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 0.15rem 0.5rem;
  }
  .project-link {
    font-size: 0.9rem;
    text-decoration: none;
    border-bottom: 1px solid transparent;
  }
  .project-link:hover { border-bottom-color: var(--accent); }

  /* ---------- changelog / experience ---------- */
  .entry { margin-bottom: 2rem; }
  .entry:last-child { margin-bottom: 0; }
  .entry-head {
    font-family: var(--font-mono);
    font-size: 0.95rem;
    color: var(--text);
    margin: 0 0 0.15rem;
  }
  .entry-head .ver { color: var(--accent); }
  .entry-sub {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin: 0 0 0.8rem;
  }
  .diff-line {
    font-family: var(--font-mono);
    font-size: 0.88rem;
    padding: 0.4rem 0.7rem;
    border-radius: 4px;
    margin-bottom: 0.4rem;
    display: flex;
    gap: 0.6rem;
  }
  .diff-line.add { background: var(--diff-add-bg); color: #cfe8cf; }
  .diff-line.add .sign { color: var(--diff-add); }
  .diff-line.change { background: var(--diff-change-bg); color: #ecd6c3; }
  .diff-line.change .sign { color: var(--diff-change); }
  .sign { flex-shrink: 0; }

  /* ---------- contact ---------- */
  .contact-lines {
    font-family: var(--font-mono);
    font-size: 0.9rem;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.1rem 1.3rem;
    margin-bottom: 1.6rem;
  }
  .contact-lines div { margin-bottom: 0.4rem; }
  .contact-lines div:last-child { margin-bottom: 0; }
  .contact-lines .k { color: var(--text-faint); }
  .contact-lines .v { color: var(--text); }
  .contact-lines a { text-decoration: none; }
  .contact-lines a:hover { text-decoration: underline; }

  form { display: grid; gap: 0.9rem; max-width: 480px; }
  label {
    font-size: 0.85rem;
    color: var(--text-muted);
    display: block;
    margin-bottom: 0.35rem;
  }
  input, textarea {
    width: 100%;
    background: var(--panel-2);
    border: 1px solid var(--border);
    border-radius: 6px;
    color: var(--text);
    font-family: var(--font-sans);
    font-size: 0.95rem;
    padding: 0.6rem 0.7rem;
  }
  textarea { resize: vertical; min-height: 100px; }
  button[type="submit"] {
    justify-self: start;
    background: var(--accent);
    color: #0f1115;
    border: none;
    font-weight: 600;
    font-size: 0.9rem;
    padding: 0.65rem 1.3rem;
    border-radius: 6px;
    cursor: pointer;
  }
  button[type="submit"]:hover { opacity: 0.9; }

  .form-msg {
    font-size: 0.88rem;
    padding: 0.6rem 0.8rem;
    border-radius: 6px;
    margin-bottom: 1rem;
    border: 1px solid var(--border);
  }
  .form-msg.ok { color: #cfe8cf; border-color: var(--diff-add); }
  .form-msg.err { color: #ecd6c3; border-color: var(--diff-change); }

  footer {
    margin-top: 5rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--border);
    color: var(--text-faint);
    font-size: 0.82rem;
    font-family: var(--font-mono);
  }

  @media (max-width: 480px) {
    .wrap { padding: 2.6rem 1.1rem 4rem; }
    .hero-top { align-items: flex-start; }
  }
</style>
</head>
<body>
<div class="wrap">

  <!-- ============ HERO ============ -->
  <section>
    <p class="file-label">$ whoami</p>
    <div class="hero-top">
      <div class="avatar"><?= h(initials($profile['name'])) ?></div>
      <div>
        <h1><?= h($profile['name']) ?></h1>
        <p class="meta-row"><?= h($profile['role']) ?> · <?= h($profile['location']) ?></p>
      </div>
    </div>
    <p class="tagline"><?= h($profile['tagline']) ?><span class="cursor">&nbsp;</span></p>
    <span class="status-pill"><?= h($profile['status']) ?></span>
  </section>

  <!-- ============ README ============ -->
  <section>
    <p class="file-label">README.md</p>
    <p class="bio"><?= h($profile['bio']) ?></p>
  </section>

  <!-- ============ SKILLS ============ -->
  <section>
    <p class="file-label">skills.json</p>
    <div class="json-block"><span class="jpunc">{</span>
<?php
$catKeys = array_keys($skills);
$catCount = count($catKeys);
foreach ($catKeys as $i => $cat):
    $items = $skills[$cat];
    $itemCount = count($items);
?>  <span class="jkey">"<?= h($cat) ?>"</span><span class="jpunc">: [</span><?php foreach ($items as $j => $item): ?><span class="jstr">"<?= h($item) ?>"</span><?= $j < $itemCount - 1 ? '<span class="jpunc">, </span>' : '' ?><?php endforeach; ?><span class="jpunc">]</span><?= $i < $catCount - 1 ? '<span class="jpunc">,</span>' : '' ?>

<?php endforeach; ?><span class="jpunc">}</span></div>
  </section>

  <!-- ============ PROJECTS ============ -->
  <section>
    <p class="file-label">projects/</p>
    <?php foreach ($projects as $project): ?>
    <div class="project">
      <p class="project-name"><?= h($project['name']) ?></p>
      <p class="project-desc"><?= h($project['desc']) ?></p>
      <div class="tech-row">
        <?php foreach ($project['tech'] as $tech): ?>
        <span class="tech-tag"><?= h($tech) ?></span>
        <?php endforeach; ?>
      </div>
      <a class="project-link" href="<?= h($project['link']) ?>">Xem chi tiết dự án</a>
    </div>
    <?php endforeach; ?>
  </section>

  <!-- ============ CHANGELOG / KINH NGHIỆM ============ -->
  <section>
    <p class="file-label">CHANGELOG.md</p>
    <?php foreach ($experience as $entry): ?>
    <div class="entry">
      <p class="entry-head"><span class="ver">## <?= h($entry['version']) ?></span> — <?= h($entry['date']) ?></p>
      <p class="entry-sub"><?= h($entry['role']) ?> @ <?= h($entry['company']) ?></p>
      <?php foreach ($entry['changes'] as $change): ?>
        <?php if ($change['type'] === 'add'): ?>
        <div class="diff-line add"><span class="sign">+</span><span>Added: <?= h($change['text']) ?></span></div>
        <?php else: ?>
        <div class="diff-line change"><span class="sign">~</span><span>Changed: <?= h($change['text']) ?></span></div>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </section>

  <!-- ============ LIÊN HỆ ============ -->
  <section>
    <p class="file-label">contact.sh</p>

    <div class="contact-lines">
      <div><span class="k">email</span>&nbsp;&nbsp;&nbsp;<a class="v" href="mailto:<?= h($contact['email']) ?>"><?= h($contact['email']) ?></a></div>
      <div><span class="k">github</span>&nbsp;&nbsp;<a class="v" href="<?= h($contact['github']) ?>" target="_blank" rel="noopener"><?= h($contact['github']) ?></a></div>
      <div><span class="k">linkedin</span><a class="v" href="<?= h($contact['linkedin']) ?>" target="_blank" rel="noopener"> <?= h($contact['linkedin']) ?></a></div>
      <div><span class="k">phone</span>&nbsp;&nbsp;&nbsp;<span class="v"><?= h($contact['phone']) ?></span></div>
    </div>

    <?php if ($form_message): ?>
    <p class="form-msg <?= $form_success ? 'ok' : 'err' ?>"><?= h($form_message) ?></p>
    <?php endif; ?>

    <form method="POST" action="">
      <div>
        <label for="name">Tên của bạn</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
      </div>
      <div>
        <label for="message">Nội dung</label>
        <textarea id="message" name="message" required></textarea>
      </div>
      <button type="submit" name="contact_submit">Gửi tin nhắn</button>
    </form>
  </section>

  <footer>
    Cập nhật lần cuối: <?= date('d/m/Y') ?>
  </footer>

</div>
</body>
</html>