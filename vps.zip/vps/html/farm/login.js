import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCR_2mrPthGL8gOzkbjThM5mlI7fKEG7Vg",
  authDomain: "sound-19c50.firebaseapp.com",
  databaseURL: "https://sound-19c50-default-rtdb.firebaseio.com",
  projectId: "sound-19c50",
  storageBucket: "sound-19c50.firebasestorage.app",
  messagingSenderId: "150852760500",
  appId: "1:150852760500:web:00f2e788b9b6e94b7bf8e1"
};

const ALLOWED_EMAIL = "ducgiang385@gmail.com";

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);

const $form = document.getElementById("loginForm");
const $msg  = document.getElementById("loginMsg");
const $btn  = document.getElementById("loginBtn");

// Nếu đã đăng nhập với đúng email → qua trang chính
onAuthStateChanged(auth, (user) => {
  if (user && user.email === ALLOWED_EMAIL) {
    window.location.href = "index.html";
  } else if (user) {
    // Đăng nhập sai email → đăng xuất ngay
    signOut(auth);
    $msg.textContent = `❌ Tài khoản ${user.email} không được phép truy cập.`;
    $msg.className = "login-msg error";
  }
});

$form.addEventListener("submit", async (e) => {
  e.preventDefault();
  $msg.textContent = "";
  $msg.className = "login-msg";
  $btn.disabled = true;
  $btn.textContent = "Đang đăng nhập...";

  const email    = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  // Chặn sớm nếu không phải email cho phép
  if (email !== ALLOWED_EMAIL) {
    $msg.textContent = "❌ Email này không có quyền truy cập.";
    $msg.className = "login-msg error";
    $btn.disabled = false;
    $btn.textContent = "Đăng nhập";
    return;
  }

  try {
    await signInWithEmailAndPassword(auth, email, password);
    $msg.textContent = "✅ Đăng nhập thành công!";
    $msg.className = "login-msg success";
    // onAuthStateChanged sẽ redirect
  } catch (err) {
    const map = {
      "auth/wrong-password":      "Sai mật khẩu.",
      "auth/user-not-found":      "Không tìm thấy tài khoản.",
      "auth/invalid-email":       "Email không hợp lệ.",
      "auth/too-many-requests":   "Quá nhiều lần thử. Vui lòng đợi.",
      "auth/invalid-credential":  "Thông tin đăng nhập không đúng."
    };
    $msg.textContent = "❌ " + (map[err.code] || err.message);
    $msg.className = "login-msg error";
  } finally {
    $btn.disabled = false;
    $btn.textContent = "Đăng nhập";
  }
});