import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signOut, setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getDatabase, ref, get, set, push, remove, onValue, update
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

/* ============================================================
   CONFIG
============================================================ */
const firebaseConfig = {
  apiKey: "AIzaSyCR_2mrPthGL8gOzkbjThM5mlI7fKEG7Vg",
  authDomain: "sound-19c50.firebaseapp.com",
  databaseURL: "https://sound-19c50-default-rtdb.firebaseio.com",
  projectId: "sound-19c50",
  storageBucket: "sound-19c50.firebasestorage.app",
  messagingSenderId: "150852760500",
  appId: "1:150852760500:web:00f2e788b9b6e94b7bf8e1"
};
const ALLOWED_EMAIL = "ducgiang385@gmail.com";
const LS_CACHE_KEY  = "farm_catalog_cache_v1";

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getDatabase(app);

// Ghi nhớ đăng nhập
setPersistence(auth, browserLocalPersistence).catch(() => {});

/* ============================================================
   SEED DATA
============================================================ */
const SEED_DATA = [
  { name: 'Lúa nước',     emoji: '🌾', type: 'Cây trồng', difficulty: 'Dễ',         desc: 'Cây lương thực chính, trồng ở ruộng ngập nước, vụ 3-4 tháng.' },
  { name: 'Cà chua',      emoji: '🍅', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Ưa nắng, cần giàn, thu hoạch sau 70-90 ngày.' },
  { name: 'Cải xanh',     emoji: '🥬', type: 'Cây trồng', difficulty: 'Dễ',         desc: 'Rau ngắn ngày, trồng quanh năm, thu 25-30 ngày.' },
  { name: 'Cà rốt',       emoji: '🥕', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Đất tơi xốp, sâu, thu hoạch 90-120 ngày.' },
  { name: 'Ớt cay',       emoji: '🌶️', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Ưa nóng, cần nhiều nắng, sai quả quanh năm.' },
  { name: 'Dưa hấu',      emoji: '🍉', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Leo đất, cần nắng gắt, 70-90 ngày cho quả.' },
  { name: 'Nấm rơm',      emoji: '🍄', type: 'Cây trồng', difficulty: 'Khó',         desc: 'Trồng trong nhà, cần độ ẩm cao, tránh nắng.' },
  { name: 'Hoa hồng',     emoji: '🌹', type: 'Cây trồng', difficulty: 'Khó',         desc: 'Cần chăm kỹ, cắt tỉa thường xuyên, kỵ nước đọng.' },
  { name: 'Gà thả vườn',  emoji: '🐔', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Dễ nuôi, tận dụng vườn, lấy trứng & thịt.' },
  { name: 'Vịt',          emoji: '🦆', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Ưa nước, ăn tạp, lớn nhanh, thịt thơm.' },
  { name: 'Heo rừng',     emoji: '🐗', type: 'Vật nuôi',  difficulty: 'Trung bình', desc: 'Chuồng rộng, ăn rau củ, thịt chắc, giá cao.' },
  { name: 'Bò sữa',       emoji: '🐄', type: 'Vật nuôi',  difficulty: 'Khó',         desc: 'Cần đồng cỏ lớn, vắt sữa 2 lần/ngày.' },
  { name: 'Dê',           emoji: '🐐', type: 'Vật nuôi',  difficulty: 'Trung bình', desc: 'Leo trèo giỏi, ăn cỏ & lá, lấy sữa & thịt.' },
  { name: 'Thỏ',          emoji: '🐰', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Sinh sản nhanh, chuồng khô ráo, ăn cỏ voi.' },
  { name: 'Ong mật',      emoji: '🐝', type: 'Vật nuôi',  difficulty: 'Khó',         desc: 'Nuôi thùng, gần vườn hoa, thu mật & sáp.' },
  { name: 'Cá rô phi',    emoji: '🐟', type: 'Thủy sản',  difficulty: 'Dễ',         desc: 'Ao nước ngọt, ăn tạp, lớn nhanh, dễ bán.' },
  { name: 'Cá chép',      emoji: '🐠', type: 'Thủy sản',  difficulty: 'Dễ',         desc: 'Ao nước tĩnh, ăn thực vật, truyền thống VN.' },
  { name: 'Tôm thẻ',      emoji: '🦐', type: 'Thủy sản',  difficulty: 'Khó',         desc: 'Ao nước lợ, cần độ mặn ổn định, giá trị cao.' },
  { name: 'Cua đồng',     emoji: '🦀', type: 'Thủy sản',  difficulty: 'Trung bình', desc: 'Ruộng nước ngọt, ăn tạp, đặc sản đồng quê.' },
  { name: 'Ếch',          emoji: '🐸', type: 'Thủy sản',  difficulty: 'Trung bình', desc: 'Ao nước sạch, ăn côn trùng, thịt ngon.' }
];

/* ============================================================
   STATE
============================================================ */
let catalog       = [];
let currentUser   = null;
let catalogRef    = null;
let unsubscribeDB = null;
let isSynced      = false;   // đã nhận data từ Firebase chưa
let seedPromise   = null;    // tránh seed trùng

/* DOM cache */
const $ = (id) => document.getElementById(id);

const $catalog     = $('catalog');
const $stats       = $('stats');
const $emptyMsg    = $('emptyMsg');
const $search      = $('searchInput');
const $typeFilter  = $('typeFilter');
const $diffFilter  = $('difficultyFilter');
const $modal       = $('modal');
const $userEmail   = $('userEmail');
const $syncBar     = $('syncBar');
const $syncText    = $('syncText');

/* ============================================================
   UTILS
============================================================ */
// Chuẩn hóa bỏ dấu tiếng Việt — cache để nhanh
const normCache = new Map();
const normalize = (s) => {
  if (!s) return '';
  if (normCache.has(s)) return normCache.get(s);
  const v = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  normCache.set(s, v);
  return v;
};

// Debounce cho search
function debounce(fn, ms = 250) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

// Escape HTML chống XSS
function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// Hiện thanh sync
function setSync(text, active = true) {
  if (!active) {
    $syncBar.hidden = true;
    return;
  }
  $syncBar.hidden = false;
  $syncText.textContent = text;
}

/* ============================================================
   LOCALSTORAGE CACHE
============================================================ */
function saveCache() {
  try {
    const payload = {
      uid: currentUser?.uid,
      items: catalog,
      savedAt: Date.now()
    };
    localStorage.setItem(LS_CACHE_KEY, JSON.stringify(payload));
  } catch (e) {
    // localStorage có thể đầy — bỏ qua
  }
}

function loadCache(uid) {
  try {
    const raw = localStorage.getItem(LS_CACHE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (data.uid !== uid) return null;
    // Cache hết hạn sau 7 ngày
    if (Date.now() - data.savedAt > 7 * 24 * 60 * 60 * 1000) return null;
    return data.items || [];
  } catch {
    return null;
  }
}

/* ============================================================
   RENDER
============================================================ */
function renderStats() {
  let crop = 0, live = 0, aqua = 0;
  for (const it of catalog) {
    if (it.type === 'Cây trồng') crop++;
    else if (it.type === 'Vật nuôi') live++;
    else if (it.type === 'Thủy sản') aqua++;
  }

  $stats.innerHTML = `
    <div class="stat-box"><div class="num">${catalog.length}</div><div class="lbl">Tổng cộng</div></div>
    <div class="stat-box"><div class="num">${crop}</div><div class="lbl">🌱 Cây trồng</div></div>
    <div class="stat-box"><div class="num">${live}</div><div class="lbl">🐄 Vật nuôi</div></div>
    <div class="stat-box"><div class="num">${aqua}</div><div class="lbl">🐟 Thủy sản</div></div>
  `;
}

// FIX BUG: dùng cached filter values
function getFiltered() {
  const kw   = normalize($search.value.trim());
  const type = $typeFilter.value;
  const diff = $diffFilter.value;

  if (!kw && type === 'all' && diff === 'all') return catalog;

  return catalog.filter(it => {
    if (type !== 'all' && it.type !== type) return false;
    if (diff !== 'all' && it.difficulty !== diff) return false;
    if (kw) {
      const name = normalize(it.name);
      if (name.includes(kw)) return true;
      const desc = normalize(it.desc || '');
      if (desc.includes(kw)) return true;
      return false;
    }
    return true;
  });
}

function renderCatalog() {
  const items = getFiltered();

  if (items.length === 0) {
    $catalog.innerHTML = '';
    $emptyMsg.classList.add('show');
    $emptyMsg.textContent = catalog.length === 0
      ? 'Chưa có dữ liệu. Bấm "🔄 Nạp lại seed" để tạo.'
      : 'Không tìm thấy kết quả phù hợp 😢';
    return;
  }
  $emptyMsg.classList.remove('show');

  // Build bằng string một lần (nhanh hơn createElement)
  let html = '';
  for (const it of items) {
    const diffClass = esc(it.difficulty.replace(/\s+/g, ''));
    html += `
      <div class="item">
        <button class="delete" data-id="${esc(it.id)}" title="Xóa" aria-label="Xóa">✕</button>
        <span class="emoji">${esc(it.emoji)}</span>
        <div class="name">${esc(it.name)}</div>
        <div class="type">${esc(it.type)}</div>
        <div class="desc">${esc(it.desc || '')}</div>
        <div class="badges">
          <span class="badge ${diffClass}">${esc(it.difficulty)}</span>
          <span class="badge type-badge">${esc(it.type)}</span>
        </div>
      </div>
    `;
  }
  $catalog.innerHTML = html;
}

function renderAll() {
  renderStats();
  renderCatalog();
}

/* ============================================================
   SEED (tránh chạy trùng)
============================================================ */
function ensureSeedData(uid) {
  if (seedPromise) return seedPromise;

  seedPromise = (async () => {
    const r = ref(db, `users/${uid}/catalog`);
    const snap = await get(r);

    if (snap.exists()) return;

    console.log('🌱 Nạp seed data lần đầu cho user', uid);
    const now = Date.now();
    const updates = {};
    for (const item of SEED_DATA) {
      const key = push(r).key;
      updates[key] = { ...item, createdAt: now, updatedAt: now };
    }
    await set(r, updates);
    console.log('✅ Đã nạp', SEED_DATA.length, 'mục');
  })();

  return seedPromise;
}

/* ============================================================
   LISTEN REALTIME
============================================================ */
function listenCatalog() {
  if (unsubscribeDB) unsubscribeDB();
  setSync('Đang đồng bộ...', true);

  unsubscribeDB = onValue(catalogRef, (snap) => {
    const data = snap.val() || {};
    catalog = Object.entries(data).map(([id, v]) => ({ id, ...v }));
    isSynced = true;

    saveCache();
    renderAll();
    setSync('', false);
  }, (err) => {
    console.error('❌ Lỗi DB:', err);
    setSync('⚠️ Mất kết nối Firebase. Đang dùng cache.', true);
  });
}

/* ============================================================
   AUTH GUARD
============================================================ */
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.replace('login.html');
    return;
  }

  if (user.email !== ALLOWED_EMAIL) {
    await signOut(auth);
    window.location.replace('login.html');
    return;
  }

  currentUser = user;
  $userEmail.textContent = '👤 ' + user.email;

  // BƯỚC TỐI ƯU: hiển thị cache NGAY, không chờ Firebase
  const cached = loadCache(user.uid);
  if (cached && cached.length) {
    catalog = cached;
    renderAll();
    setSync('🔄 Đang cập nhật từ Firebase...', true);
  } else {
    setSync('⏳ Đang tải dữ liệu...', true);
  }

  // Trỏ tới nhánh riêng
  catalogRef = ref(db, `users/${user.uid}/catalog`);

  // Chạy song song: seed (nếu cần) → rồi listen
  try {
    await ensureSeedData(user.uid);
    listenCatalog();
  } catch (err) {
    console.error('Lỗi seed:', err);
    setSync('⚠️ Không kết nối được Firebase.', true);
  }
});

/* ============================================================
   EVENTS
============================================================ */
// Search debounce 250ms — tránh render liên tục
$search.addEventListener('input', debounce(renderCatalog, 250));

// Select filter — render ngay (rẻ)
$typeFilter.addEventListener('change', renderCatalog);
$diffFilter.addEventListener('change', renderCatalog);

/* XÓA */
$catalog.addEventListener('click', async (e) => {
  const btn = e.target.closest('.delete');
  if (!btn) return;

  const id = btn.dataset.id;
  if (!confirm('Xóa mục này?')) return;

  // Optimistic UI — xóa ngay khỏi local
  const backup = [...catalog];
  catalog = catalog.filter(i => i.id !== id);
  renderAll();

  try {
    await remove(ref(db, `users/${currentUser.uid}/catalog/${id}`));
  } catch (err) {
    console.error(err);
    catalog = backup;
    renderAll();
    alert('❌ Xóa thất bại. Đã khôi phục.');
  }
});

/* MODAL */
$('addBtn').onclick = () => {
  $modal.classList.add('open');
  setTimeout(() => $('newName').focus(), 100);
};
$('cancelBtn').onclick = () => $modal.classList.remove('open');

$modal.addEventListener('click', (e) => {
  if (e.target === $modal) $modal.classList.remove('open');
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $modal.classList.contains('open')) {
    $modal.classList.remove('open');
  }
});

/* THÊM MỚI — FIX BUG: reset filter + update ngay */
$('saveBtn').onclick = async () => {
  const name       = $('newName').value.trim();
  const emoji      = $('newEmoji').value.trim() || '🌱';
  const type       = $('newType').value;
  const difficulty = $('newDifficulty').value;
  const desc       = $('newDesc').value.trim() || 'Chưa có mô tả.';

  if (!name) {
    alert('Vui lòng nhập tên!');
    $('newName').focus();
    return;
  }

  const btn = $('saveBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Đang lưu...';

  const now = Date.now();
  const newItem = { name, emoji, type, difficulty, desc, createdAt: now, updatedAt: now };

  try {
    const newRef = push(ref(db, `users/${currentUser.uid}/catalog`));
    await set(newRef, newItem);

    // FIX BUG: reset filter để mục mới hiển thị ngay
    $search.value = '';
    $typeFilter.value = 'all';
    $diffFilter.value = 'all';

    // Optimistic UI — thêm ngay để không phải chờ onValue
    if (!isSynced) {
      catalog.unshift({ id: newRef.key, ...newItem });
      renderAll();
    }

    // Đóng modal + reset form
    $modal.classList.remove('open');
    ['newName', 'newEmoji', 'newDesc'].forEach(id => $(id).value = '');
    $('newType').value = 'Cây trồng';
    $('newDifficulty').value = 'Dễ';
  } catch (err) {
    console.error(err);
    alert('❌ Không lưu được. Kiểm tra kết nối.');
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 Lưu';
  }
};

/* RESET SEED */
$('resetBtn').onclick = async () => {
  if (!confirm('Xóa hết và nạp lại dữ liệu gốc?')) return;

  const btn = $('resetBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Đang nạp...';

  try {
    const r = ref(db, `users/${currentUser.uid}/catalog`);
    const now = Date.now();
    const updates = {};
    for (const item of SEED_DATA) {
      const key = push(r).key;
      updates[key] = { ...item, createdAt: now, updatedAt: now };
    }
    await set(r, updates);
  } catch (err) {
    console.error(err);
    alert('❌ Nạp lại thất bại.');
  } finally {
    btn.disabled = false;
    btn.textContent = '🔄 Nạp lại seed';
  }
};

/* LOGOUT */
$('logoutBtn').onclick = async () => {
  if (unsubscribeDB) unsubscribeDB();
  localStorage.removeItem(LS_CACHE_KEY);
  await signOut(auth);
  window.location.replace('login.html');
};