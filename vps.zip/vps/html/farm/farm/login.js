import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut,
  setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCR_2mrPthGL8gOzkbjThM5mlI7fKEG7Vg",
  authDomain: "sound-19c50.firebaseapp.com",
  databaseURL: "https://sound-19c50-default-rtdb.firebaseio.com",
  projectId: "sound-19c50",
  storageBucket: "sound-19c50.firebasestorage.app",
  messagingSenderId: "150852760500",
  appId: "1:150852760500:web:00f2e788b9b6e94b7bf8e1"
};
const ALLOWED_EMAIL = "ducgiang385@gmail.com";

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Ghi nhớ đăng nhập
setPersistence(auth, browserLocalPersistence).catch(() => {});

const $form = document.getElementById("loginForm");
const $msg  = document.getElementById("loginMsg");
const $btn  = document.getElementById("loginBtn");
const $email= document.getElementById("email");
const $pass = document.getElementById("password");

// Auto-redirect nếu đã đăng nhập đúng
onAuthStateChanged(auth, (user) => {
  if (user && user.email === ALLOWED_EMAIL) {
    window.location.replace("index.html");
  } else if (user && user.email !== ALLOWED_EMAIL) {
    signOut(auth);
    showMsg("❌ Tài khoản không được phép truy cập.", "error");
  }
});

function showMsg(text, type = "") {
  $msg.textContent = text;
  $msg.className = "login-msg " + type;
}

$form.addEventListener("submit", async (e) => {
  e.preventDefault();
  showMsg("");

  const email    = $email.value.trim();
  const password = $pass.value;

  // Validate nhanh
  if (!email || !password) {
    showMsg("❌ Vui lòng nhập đầy đủ email và mật khẩu.", "error");
    return;
  }

  // Chặn sớm email không hợp lệ
  if (email !== ALLOWED_EMAIL) {
    showMsg("❌ Email này không có quyền truy cập.", "error");
    return;
  }

  $btn.disabled = true;
  $btn.textContent = "Đang đăng nhập...";

  try {
    await signInWithEmailAndPassword(auth, email, password);
    showMsg("✅ Đăng nhập thành công!", "success");
    // onAuthStateChanged sẽ redirect
  } catch (err) {
    const map = {
      "auth/wrong-password":      "Sai mật khẩu.",
      "auth/user-not-found":      "Không tìm thấy tài khoản.",
      "auth/invalid-email":       "Email không hợp lệ.",
      "auth/too-many-requests":   "Quá nhiều lần thử. Vui lòng đợi.",
      "auth/invalid-credential":  "Thông tin đăng nhập không đúng.",
      "auth/network-request-failed": "Lỗi mạng. Kiểm tra kết nối."
    };
    showMsg("❌ " + (map[err.code] || err.message), "error");
    $btn.disabled = false;
    $btn.textContent = "Đăng nhập";
  }
});