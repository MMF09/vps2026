import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getDatabase, ref, get, set, push, remove, onValue
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

/* ========= CONFIG ========= */
const firebaseConfig = {
  apiKey: "AIzaSyCR_2mrPthGL8gOzkbjThM5mlI7fKEG7Vg",
  authDomain: "sound-19c50.firebaseapp.com",
  databaseURL: "https://sound-19c50-default-rtdb.firebaseio.com",
  projectId: "sound-19c50",
  storageBucket: "sound-19c50.firebasestorage.app",
  messagingSenderId: "150852760500",
  appId: "1:150852760500:web:00f2e788b9b6e94b7bf8e1"
};

const ALLOWED_EMAIL = "ducgiang385@gmail.com";

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getDatabase(app);

/* ========= SEED DATA ========= */
const seedData = [
  { name: 'Lúa nước',     emoji: '🌾', type: 'Cây trồng', difficulty: 'Dễ',         desc: 'Cây lương thực chính, trồng ở ruộng ngập nước, vụ 3-4 tháng.' },
  { name: 'Cà chua',      emoji: '🍅', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Ưa nắng, cần giàn, thu hoạch sau 70-90 ngày.' },
  { name: 'Cải xanh',     emoji: '🥬', type: 'Cây trồng', difficulty: 'Dễ',         desc: 'Rau ngắn ngày, trồng quanh năm, thu 25-30 ngày.' },
  { name: 'Cà rốt',       emoji: '🥕', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Đất tơi xốp, sâu, thu hoạch 90-120 ngày.' },
  { name: 'Ớt cay',       emoji: '🌶️', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Ưa nóng, cần nhiều nắng, sai quả quanh năm.' },
  { name: 'Dưa hấu',      emoji: '🍉', type: 'Cây trồng', difficulty: 'Trung bình', desc: 'Leo đất, cần nắng gắt, 70-90 ngày cho quả.' },
  { name: 'Nấm rơm',      emoji: '🍄', type: 'Cây trồng', difficulty: 'Khó',         desc: 'Trồng trong nhà, cần độ ẩm cao, tránh nắng.' },
  { name: 'Hoa hồng',     emoji: '🌹', type: 'Cây trồng', difficulty: 'Khó',         desc: 'Cần chăm kỹ, cắt tỉa thường xuyên, kỵ nước đọng.' },
  { name: 'Gà thả vườn',  emoji: '🐔', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Dễ nuôi, tận dụng vườn, lấy trứng & thịt.' },
  { name: 'Vịt',          emoji: '🦆', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Ưa nước, ăn tạp, lớn nhanh, thịt thơm.' },
  { name: 'Heo rừng',     emoji: '🐗', type: 'Vật nuôi',  difficulty: 'Trung bình', desc: 'Chuồng rộng, ăn rau củ, thịt chắc, giá cao.' },
  { name: 'Bò sữa',       emoji: '🐄', type: 'Vật nuôi',  difficulty: 'Khó',         desc: 'Cần đồng cỏ lớn, vắt sữa 2 lần/ngày.' },
  { name: 'Dê',           emoji: '🐐', type: 'Vật nuôi',  difficulty: 'Trung bình', desc: 'Leo trèo giỏi, ăn cỏ & lá, lấy sữa & thịt.' },
  { name: 'Thỏ',          emoji: '🐰', type: 'Vật nuôi',  difficulty: 'Dễ',         desc: 'Sinh sản nhanh, chuồng khô ráo, ăn cỏ voi.' },
  { name: 'Ong mật',      emoji: '🐝', type: 'Vật nuôi',  difficulty: 'Khó',         desc: 'Nuôi thùng, gần vườn hoa, thu mật & sáp.' },
  { name: 'Cá rô phi',    emoji: '🐟', type: 'Thủy sản',  difficulty: 'Dễ',         desc: 'Ao nước ngọt, ăn tạp, lớn nhanh, dễ bán.' },
  { name: 'Cá chép',      emoji: '🐠', type: 'Thủy sản',  difficulty: 'Dễ',         desc: 'Ao nước tĩnh, ăn thực vật, truyền thống VN.' },
  { name: 'Tôm thẻ',      emoji: '🦐', type: 'Thủy sản',  difficulty: 'Khó',         desc: 'Ao nước lợ, cần độ mặn ổn định, giá trị cao.' },
  { name: 'Cua đồng',     emoji: '🦀', type: 'Thủy sản',  difficulty: 'Trung bình', desc: 'Ruộng nước ngọt, ăn tạp, đặc sản đồng quê.' },
  { name: 'Ếch',          emoji: '🐸', type: 'Thủy sản',  difficulty: 'Trung bình', desc: 'Ao nước sạch, ăn côn trùng, thịt ngon.' }
];

/* ========= STATE ========= */
let catalog       = [];
let currentUser   = null;
let catalogRef    = null;   // ref tới users/<uid>/catalog
let unsubscribeDB = null;   // hàm hủy listener

/* ========= DOM ========= */
const $loading    = document.getElementById('loading');
const $appContent = document.getElementById('appContent');
const $catalog    = document.getElementById('catalog');
const $stats      = document.getElementById('stats');
const $emptyMsg   = document.getElementById('emptyMsg');
const $search     = document.getElementById('searchInput');
const $typeFilter = document.getElementById('typeFilter');
const $diffFilter = document.getElementById('difficultyFilter');
const $modal      = document.getElementById('modal');
const $userEmail  = document.getElementById('userEmail');

const normalize = (s) =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

/* ============================================
   AUTH GUARD
============================================ */
onAuthStateChanged(auth, async (user) => {
  // 1. Chưa đăng nhập → về login
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  // 2. Đăng nhập nhưng sai email → đá ra
  if (user.email !== ALLOWED_EMAIL) {
    await signOut(auth);
    window.location.href = 'login.html';
    return;
  }

  // 3. Hợp lệ
  currentUser = user;
  $userEmail.textContent = '👤 ' + user.email;

  // Trỏ tới nhánh riêng của user: users/<uid>/catalog
  catalogRef = ref(db, `users/${user.uid}/catalog`);

  // Đảm bảo seed data có (lần đầu)
  await ensureSeedData(user.uid);

  // Lắng nghe thay đổi realtime
  listenCatalog();

  $loading.style.display    = 'none';
  $appContent.style.display = 'block';
});

/* ============================================
   SEED LẦN ĐẦU (theo uid)
============================================ */
async function ensureSeedData(uid) {
  const userCatalogRef = ref(db, `users/${uid}/catalog`);
  const snap = await get(userCatalogRef);

  if (snap.exists()) {
    console.log('📦 User đã có data trên Firebase.');
    return;
  }

  console.log('🌱 Nạp seed data cho user', uid);
  const updates = {};
  for (const item of seedData) {
    const key = push(userCatalogRef).key;
    updates[key] = item;
  }
  await set(userCatalogRef, updates);
  console.log('✅ Đã nạp', seedData.length, 'mục vào users/' + uid + '/catalog');
}

/* ============================================
   ĐỌC REALTIME (users/<uid>/catalog)
============================================ */
function listenCatalog() {
  // Hủy listener cũ nếu có
  if (unsubscribeDB) unsubscribeDB();

  unsubscribeDB = onValue(catalogRef, (snap) => {
    const data = snap.val() || {};
    catalog = Object.entries(data).map(([id, v]) => ({ id, ...v }));
    renderAll();
  }, (err) => {
    console.error('❌ Lỗi đọc DB:', err);
    alert('Không đọc được dữ liệu. Kiểm tra Rules hoặc đăng nhập lại.');
  });
}

/* ============================================
   RENDER
============================================ */
function renderStats() {
  const counts = {
    total:       catalog.length,
    'Cây trồng': catalog.filter(i => i.type === 'Cây trồng').length,
    'Vật nuôi':  catalog.filter(i => i.type === 'Vật nuôi').length,
    'Thủy sản':  catalog.filter(i => i.type === 'Thủy sản').length
  };

  $stats.innerHTML = `
    <div class="stat-box"><div class="num">${counts.total}</div><div class="lbl">Tổng cộng</div></div>
    <div class="stat-box"><div class="num">${counts['Cây trồng']}</div><div class="lbl">🌱 Cây trồng</div></div>
    <div class="stat-box"><div class="num">${counts['Vật nuôi']}</div><div class="lbl">🐄 Vật nuôi</div></div>
    <div class="stat-box"><div class="num">${counts['Thủy sản']}</div><div class="lbl">🐟 Thủy sản</div></div>
  `;
}

function getFiltered() {
  const kw   = normalize($search.value.trim());
  const type = $typeFilter.value;
  const diff = $diffFilter.value;

  return catalog.filter(item => {
    const matchKw   = !kw || normalize(item.name).includes(kw) || normalize(item.desc || '').includes(kw);
    const matchType = type === 'all' || item.type === type;
    const matchDiff = diff === 'all' || item.difficulty === diff;
    return matchKw && matchType && matchDiff;
  });
}

function renderCatalog() {
  const items = getFiltered();

  if (items.length === 0) {
    $catalog.innerHTML = '';
    $emptyMsg.classList.add('show');
    return;
  }
  $emptyMsg.classList.remove('show');

  $catalog.innerHTML = items.map(item => `
    <div class="item">
      <button class="delete" data-id="${item.id}" title="Xóa">✕</button>
      <span class="emoji">${item.emoji}</span>
      <div class="name">${item.name}</div>
      <div class="type">${item.type}</div>
      <div class="desc">${item.desc || ''}</div>
      <div class="badges">
        <span class="badge ${item.difficulty.replace(' ', '')}">${item.difficulty}</span>
        <span class="badge type-badge">${item.type}</span>
      </div>
    </div>
  `).join('');
}

function renderAll() {
  renderStats();
  renderCatalog();
}

/* ============================================
   EVENTS
============================================ */
$search.addEventListener('input', renderCatalog);
$typeFilter.addEventListener('change', renderCatalog);
$diffFilter.addEventListener('change', renderCatalog);

// XÓA: users/<uid>/catalog/<id>
$catalog.addEventListener('click', async (e) => {
  if (!e.target.classList.contains('delete')) return;
  const id = e.target.dataset.id;
  if (!confirm('Xóa mục này?')) return;
  await remove(ref(db, `users/${currentUser.uid}/catalog/${id}`));
});

// MODAL
document.getElementById('addBtn').onclick    = () => $modal.classList.add('open');
document.getElementById('cancelBtn').onclick = () => $modal.classList.remove('open');

$modal.addEventListener('click', (e) => {
  if (e.target === $modal) $modal.classList.remove('open');
});

// THÊM MỚI: users/<uid>/catalog/<newKey>
document.getElementById('saveBtn').onclick = async () => {
  const name       = document.getElementById('newName').value.trim();
  const emoji      = document.getElementById('newEmoji').value.trim() || '🌱';
  const type       = document.getElementById('newType').value;
  const difficulty = document.getElementById('newDifficulty').value;
  const desc       = document.getElementById('newDesc').value.trim() || 'Chưa có mô tả.';

  if (!name) { alert('Vui lòng nhập tên!'); return; }

  const newRef = push(ref(db, `users/${currentUser.uid}/catalog`));
  await set(newRef, { name, emoji, type, difficulty, desc });

  $modal.classList.remove('open');
  ['newName', 'newEmoji', 'newDesc'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('newType').value = 'Cây trồng';
  document.getElementById('newDifficulty').value = 'Dễ';
};

// RESET: ghi lại toàn bộ seed vào nhánh của user
document.getElementById('resetBtn').onclick = async () => {
  if (!confirm('Xóa hết và nạp lại dữ liệu gốc?')) return;

  const userCatalogRef = ref(db, `users/${currentUser.uid}/catalog`);
  const updates = {};
  for (const item of seedData) {
    const key = push(userCatalogRef).key;
    updates[key] = item;
  }
  await set(userCatalogRef, updates);
};

// LOGOUT
document.getElementById('logoutBtn').onclick = async () => {
  if (unsubscribeDB) unsubscribeDB();
  await signOut(auth);
  window.location.href = 'login.html';
};