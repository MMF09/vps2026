<?php
/**
 * dashboard.php
 * -------------
 * Yêu cầu bài toán:
 * - Quét TOÀN BỘ file có sẵn trên SERVER (không phụ thuộc upload)
 * - Phân tích dữ liệu + hiển thị biểu đồ
 *
 * SCAN_DIR (config.php) = thư mục dự án / thư mục cần quét trên máy chủ
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/ErrorHandler.php';
require_once __DIR__ . '/includes/DataAnalyzer.php';

ErrorHandler::init(LOG_DIR);

// ========== QUÉT TOÀN BỘ FILE TRÊN SERVER ==========
$analysis = [
    'scan_dir'         => SCAN_DIR,
    'total_files'      => 0,
    'total_size'       => 0,
    'total_size_human' => '0 B',
    'by_extension'     => [],
    'by_size_range'    => ['<100KB' => 0, '100KB-1MB' => 0, '1MB-10MB' => 0, '>10MB' => 0],
    'by_month'         => [],
    'largest_files'    => [],
    'all_files'        => [],
];

try {
    $analyzer = new DataAnalyzer(SCAN_DIR);
    $analysis = $analyzer->analyze();
} catch (Throwable $e) {
    ErrorHandler::route(ErrorHandler::LEVEL_ERROR, 'Lỗi quét thư mục server: ' . $e->getMessage());
}

$analysisJson = json_encode($analysis, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$scanDirDisplay = htmlspecialchars($analysis['scan_dir'] ?? SCAN_DIR);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Quét file Server &amp; Phân tích dữ liệu</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div id="toast-container"></div>

<div class="app">
  <header class="app-header">
    <h1>📊 Dashboard — Quét file trên Server &amp; Phân tích dữ liệu</h1>
  </header>

  <!-- ===== DANH SÁCH FILE ĐÃ QUÉT TỪ SERVER ===== -->
  <section class="panel">
    <div class="panel-head">
      <h2>📁 Tất cả file đã quét trên server</h2>
      <span class="muted-text">Thư mục: <code><?= $scanDirDisplay ?></code></span>
    </div>

    <div class="toolbar">
      <button id="btn-refresh" class="btn">🔄 Quét lại thư mục</button>
      <span id="file-count-label" class="muted-text">
        <?= (int) $analysis['total_files'] ?> file · <?= htmlspecialchars($analysis['total_size_human']) ?>
      </span>
    </div>

    <table id="file-table" class="file-table">
      <thead>
        <tr>
          <th></th>
          <th>Tên (đường dẫn tương đối)</th>
          <th>Định dạng</th>
          <th>Kích thước</th>
          <th>Sửa đổi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($analysis['all_files'])): ?>
          <tr><td colspan="5" class="empty">Không tìm thấy file nào trong thư mục quét</td></tr>
        <?php else: ?>
          <?php foreach ($analysis['all_files'] as $f): ?>
            <tr>
              <td>📄</td>
              <td><?= htmlspecialchars($f['name']) ?></td>
              <td><?= htmlspecialchars($f['extension'] !== '' ? $f['extension'] : '—') ?></td>
              <td><?= htmlspecialchars($f['size_human']) ?></td>
              <td><?= htmlspecialchars($f['modified']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </section>

  <!-- ===== PHÂN TÍCH DỮ LIỆU + BIỂU ĐỒ ===== -->
  <section class="panel">
    <div class="panel-head">
      <h2>📈 Phân tích dữ liệu</h2>
      <div class="toolbar-inline">
        <button id="btn-refresh-dash" class="btn btn-accent">🔄 Làm mới phân tích</button>
        <span id="last-updated" class="muted-text">
          Đã quét lúc <?= date('H:i:s d/m/Y') ?>
        </span>
      </div>
    </div>

    <div class="stats-grid" id="stats-grid">
      <div class="stat-card">
        <div class="stat-value"><?= (int) $analysis['total_files'] ?></div>
        <div class="stat-label">Tổng số file</div>
      </div>
      <div class="stat-card">
        <div class="stat-value"><?= htmlspecialchars($analysis['total_size_human']) ?></div>
        <div class="stat-label">Tổng dung lượng</div>
      </div>
      <div class="stat-card">
        <div class="stat-value"><?= count($analysis['by_extension']) ?></div>
        <div class="stat-label">Loại định dạng</div>
      </div>
    </div>

    <div class="charts-grid">
      <div class="chart-box"><canvas id="chart-ext"></canvas></div>
      <div class="chart-box"><canvas id="chart-size"></canvas></div>
      <div class="chart-box chart-wide"><canvas id="chart-month"></canvas></div>
    </div>

    <h3>10 file lớn nhất</h3>
    <table class="file-table" id="largest-table">
      <thead><tr><th>Tên file</th><th>Kích thước</th><th>Sửa đổi</th></tr></thead>
      <tbody>
        <?php if (empty($analysis['largest_files'])): ?>
          <tr><td colspan="3" class="empty">Không có dữ liệu</td></tr>
        <?php else: ?>
          <?php foreach ($analysis['largest_files'] as $f): ?>
            <tr>
              <td><?= htmlspecialchars($f['name']) ?></td>
              <td><?= htmlspecialchars($f['size_human']) ?></td>
              <td><?= htmlspecialchars($f['modified'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </section>

  <!-- ===== NHẬT KÝ HOẠT ĐỘNG ===== -->
  <section class="panel">
    <div class="panel-head">
      <h2>🛎️ Nhật ký hoạt động &amp; phân luồng lỗi</h2>
    </div>
    <p class="muted-text">Sự kiện ghi qua <code>ErrorHandler::route()</code>, phân theo mức độ.</p>
    <div class="stats-grid" id="activity-counts"></div>
    <div id="activity-feed" class="activity-feed">
      <div class="empty">Đang tải nhật ký...</div>
    </div>
  </section>

  <footer class="app-footer">
    <span>
      Quét thư mục server: <code><?= $scanDirDisplay ?></code>
      &middot; Log: logs/app.log
      &middot; Tự làm mới nhật ký mỗi 10 giây
    </span>
  </footer>
</div>

<script>
  window.INITIAL_ANALYSIS = <?= $analysisJson ?>;
</script>
<script src="assets/js/dashboard.js"></script>
</body>
</html>
