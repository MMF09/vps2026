<?php
/**
 * index.php - Entry point bảo vệ + chuyển hướng
 * Giúp hệ thống chạy ổn định trên hosting PHP thông thường
 */

// Bảo mật cơ bản
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Nếu truy cập trực tiếp file PHP này → chuyển về trang login HTML
if (basename($_SERVER['SCRIPT_NAME']) === 'index.php') {
    // Kiểm tra xem có file index.html không
    if (file_exists(__DIR__ . '/index.html')) {
        // Redirect sạch
        header('Location: index.html', true, 302);
        exit;
    }
}

// Nếu muốn serve static files qua PHP (phòng trường hợp server không hỗ trợ tốt)
$request = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$file = __DIR__ . $request;

// Chỉ cho phép các file an toàn
$allowed = ['html', 'css', 'js', 'svg', 'ico', 'png', 'jpg', 'jpeg', 'gif', 'woff', 'woff2'];
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

if ($request !== '/' && $request !== '/index.php' && file_exists($file) && in_array($ext, $allowed)) {
    // Set content-type đúng
    $mimes = [
        'html' => 'text/html; charset=utf-8',
        'css'  => 'text/css; charset=utf-8',
        'js'   => 'application/javascript; charset=utf-8',
        'svg'  => 'image/svg+xml',
        'ico'  => 'image/x-icon',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif'  => 'image/gif',
    ];
    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
    }
    readfile($file);
    exit;
}

// Mặc định chuyển về login
header('Location: index.html', true, 302);
exit;
