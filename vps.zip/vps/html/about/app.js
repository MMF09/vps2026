import { auth, db } from './firebase-config.js';
import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.14.0/firebase-auth.js";
import {
  ref,
  push,
  set,
  onValue,
  remove
} from "https://www.gstatic.com/firebasejs/10.14.0/firebase-database.js";

let currentAccounts = [];

onAuthStateChanged(auth, (user) => {
  if (!user) {
    window.location.href = "index.html";
    return;
  }
  document.getElementById("userEmail").textContent = user.email || user.displayName || user.uid;
  loadAccounts(user.uid);
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  try {
    await signOut(auth);
    window.location.href = "index.html";
  } catch (err) {
    alert("Lỗi đăng xuất: " + err.message);
  }
});

const addForm = document.getElementById("addForm");
const addBtn = document.getElementById("addBtn");

addForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const user = auth.currentUser;
  if (!user) {
    alert("Phiên đăng nhập hệ thống đã hết. Vui lòng đăng nhập lại.");
    window.location.href = "index.html";
    return;
  }

  const email = document.getElementById("fbEmail").value.trim();
  const password = document.getElementById("fbPassword").value;
  const cookie = document.getElementById("fbCookie").value.trim();
  const note = document.getElementById("fbNote").value.trim();
  const status = document.getElementById("fbStatus").value;

  if (!email || !password) {
    showToast("Vui lòng nhập đầy đủ Email/UID và Mật khẩu");
    return;
  }

  addBtn.disabled = true;
  addBtn.textContent = "Đang lưu...";

  const data = {
    email,
    password,
    cookie,
    note,
    status,
    createdAt: Date.now()
  };

  try {
    const newRef = push(ref(db, `users/${user.uid}/accounts`));
    await set(newRef, data);
    addForm.reset();
    showToast("✅ Đã lưu tài khoản Facebook thành công!");
  } catch (err) {
    console.error(err);
    alert("Lỗi khi lưu: " + (err.message || "Không xác định"));
  } finally {
    addBtn.disabled = false;
    addBtn.textContent = "Lưu tài khoản Facebook";
  }
});

// EXPORT
document.getElementById("exportJsonBtn").addEventListener("click", () => {
  if (currentAccounts.length === 0) {
    showToast("Chưa có tài khoản nào để xuất");
    return;
  }
  const dataStr = JSON.stringify(currentAccounts, null, 2);
  downloadFile(dataStr, `fb-accounts-${formatDate()}.json`, "application/json");
  showToast("Đã xuất file JSON");
});

document.getElementById("exportCsvBtn").addEventListener("click", () => {
  if (currentAccounts.length === 0) {
    showToast("Chưa có tài khoản nào để xuất");
    return;
  }
  const csv = convertToCSV(currentAccounts);
  downloadFile(csv, `fb-accounts-${formatDate()}.csv`, "text/csv;charset=utf-8;");
  showToast("Đã xuất file CSV (mở bằng Excel)");
});

function convertToCSV(accounts) {
  const headers = ["email", "password", "cookie", "note", "status", "createdAt"];
  const rows = accounts.map(acc => [
    escapeCsv(acc.email || ""),
    escapeCsv(acc.password || ""),
    escapeCsv(acc.cookie || ""),
    escapeCsv(acc.note || ""),
    escapeCsv(acc.status || ""),
    acc.createdAt ? new Date(acc.createdAt).toISOString() : ""
  ]);
  return "\uFEFF" + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
}

function escapeCsv(value) {
  if (value == null) return "";
  const str = String(value);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function downloadFile(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function formatDate() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,"0")}${String(d.getDate()).padStart(2,"0")}-${String(d.getHours()).padStart(2,"0")}${String(d.getMinutes()).padStart(2,"0")}`;
}

// IMPORT
document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const statusEl = document.getElementById("importStatus");
  statusEl.textContent = "Đang đọc file...";

  const user = auth.currentUser;
  if (!user) {
    alert("Phiên đăng nhập đã hết.");
    return;
  }

  try {
    const text = await file.text();
    let accounts = [];

    if (file.name.toLowerCase().endsWith(".json")) {
      accounts = JSON.parse(text);
      if (!Array.isArray(accounts)) {
        if (accounts.accounts && Array.isArray(accounts.accounts)) {
          accounts = accounts.accounts;
        } else {
          throw new Error("File JSON không đúng định dạng mảng tài khoản");
        }
      }
    } else if (file.name.toLowerCase().endsWith(".csv")) {
      accounts = parseCSV(text);
    } else {
      throw new Error("Chỉ hỗ trợ file .json hoặc .csv");
    }

    if (accounts.length === 0) {
      statusEl.textContent = "File không có dữ liệu";
      return;
    }

    if (!confirm(`Bạn sắp nhập ${accounts.length} tài khoản. Tiếp tục?`)) {
      statusEl.textContent = "";
      e.target.value = "";
      return;
    }

    statusEl.textContent = `Đang nhập ${accounts.length} tài khoản...`;

    let success = 0;
    for (const acc of accounts) {
      const data = {
        email: acc.email || acc.Email || "",
        password: acc.password || acc.Password || "",
        cookie: acc.cookie || acc.Cookie || "",
        note: acc.note || acc.Note || "",
        status: acc.status || acc.Status || "active",
        createdAt: acc.createdAt ? (typeof acc.createdAt === "number" ? acc.createdAt : new Date(acc.createdAt).getTime()) : Date.now()
      };
      if (!data.email) continue;
      const newRef = push(ref(db, `users/${user.uid}/accounts`));
      await set(newRef, data);
      success++;
    }

    statusEl.textContent = `✅ Đã nhập thành công ${success} tài khoản`;
    showToast(`Đã nhập ${success} tài khoản`);
    e.target.value = "";
  } catch (err) {
    console.error(err);
    statusEl.textContent = "Lỗi: " + (err.message || "Không đọc được file");
    alert("Lỗi nhập file: " + err.message);
  }
});

function parseCSV(text) {
  text = text.replace(/^\uFEFF/, "");
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase().trim());
  const result = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length === 0) continue;
    const obj = {};
    headers.forEach((h, idx) => {
      obj[h] = values[idx] || "";
    });
    result.push(obj);
  }
  return result;
}

function parseCSVLine(line) {
  const result = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (inQuotes) {
      if (char === '"' && line[i+1] === '"') {
        current += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        result.push(current);
        current = "";
      } else {
        current += char;
      }
    }
  }
  result.push(current);
  return result;
}

function loadAccounts(uid) {
  const listRef = ref(db, `users/${uid}/accounts`);
  
  onValue(listRef, (snapshot) => {
    const tbody = document.getElementById("accountList");
    const countEl = document.getElementById("accountCount");
    if (!tbody) return;
    
    tbody.innerHTML = "";
    currentAccounts = [];

    if (!snapshot.exists()) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="empty-state">
            Chưa có tài khoản Facebook nào.<br>
            Hãy thêm tài khoản đầu tiên ở form phía trên.
          </td>
        </tr>`;
      if (countEl) countEl.textContent = "0";
      return;
    }

    const accounts = [];
    snapshot.forEach((child) => {
      accounts.push({ id: child.key, ...child.val() });
    });

    accounts.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    currentAccounts = accounts.map(({ id, ...rest }) => rest);

    if (countEl) countEl.textContent = accounts.length;

    accounts.forEach((acc) => {
      const date = acc.createdAt 
        ? new Date(acc.createdAt).toLocaleString("vi-VN") 
        : "—";
      const hasCookie = acc.cookie && acc.cookie.length > 10;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>
          <div class="email-cell">${escapeHtml(acc.email || "")}</div>
        </td>
        <td>
          <span class="password-mask">••••••••</span>
        </td>
        <td>
          ${hasCookie 
            ? `<span class="badge cookie">Có cookie</span>` 
            : `<span class="badge no-cookie">Không có</span>`}
        </td>
        <td>${escapeHtml(acc.note || "—")}</td>
        <td>
          <span class="status status-${acc.status || "active"}">${getStatusText(acc.status)}</span>
        </td>
        <td class="date-cell">${date}</td>
        <td>
          <button class="btn-sm btn-danger" data-id="${acc.id}">
            Xóa
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll(".btn-danger").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id");
        deleteAccount(id);
      });
    });
  }, (error) => {
    console.error("Lỗi load accounts:", error);
    const tbody = document.getElementById("accountList");
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="7" class="empty-state">Lỗi tải dữ liệu. Kiểm tra Rules Realtime Database.</td></tr>`;
    }
  });
}

async function deleteAccount(id) {
  if (!confirm("Bạn chắc chắn muốn xóa tài khoản Facebook này?")) return;
  
  const user = auth.currentUser;
  if (!user) {
    alert("Phiên đăng nhập đã hết.");
    window.location.href = "index.html";
    return;
  }

  try {
    await remove(ref(db, `users/${user.uid}/accounts/${id}`));
    showToast("Đã xóa tài khoản");
  } catch (err) {
    console.error(err);
    alert("Lỗi khi xóa: " + (err.message || "Không xác định"));
  }
}

function getStatusText(status) {
  const map = {
    active: "Đang hoạt động",
    checkpoint: "Checkpoint",
    banned: "Bị khóa",
    die: "Die"
  };
  return map[status] || status || "—";
}

function escapeHtml(text) {
  if (!text) return "";
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function showToast(message) {
  document.querySelectorAll(".toast").forEach(t => t.remove());
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}
