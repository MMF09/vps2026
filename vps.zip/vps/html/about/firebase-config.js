// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyASfKSM4k9PVqGSu2ycd5Uv1ax0vbScg0I",
  authDomain: "soloskill.firebaseapp.com",
  databaseURL: "https://soloskill-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "soloskill",
  storageBucket: "soloskill.firebasestorage.app",
  messagingSenderId: "959816905162",
  appId: "1:959816905162:web:346a3049f3173f2e71df33",
  measurementId: "G-HS2V70ME5Z"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
