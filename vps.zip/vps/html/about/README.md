# FB Multi-Account Manager (Firebase)

Hệ thống quản lý nhiều tài khoản Meta/Facebook với đăng nhập hệ thống bằng **Email** hoặc **Google**.

## Phân biệt rõ ràng

| Loại | Mô tả |
|------|------|
| **Đăng nhập hệ thống** | Email + mật khẩu Firebase **hoặc** Google Sign-In |
| **Quản lý tài khoản Meta** | Lưu email/UID + mật khẩu + cookie Facebook |

## Tính năng

- Đăng nhập bằng **Email** (không có form đăng ký)
- Đăng nhập bằng **Google** (riêng biệt)
- Thêm / xóa tài khoản Facebook
- Lưu cookie Facebook (tùy chọn)
- **Xuất** danh sách ra **JSON** hoặc **CSV** (mở bằng Excel)
- **Nhập** tài khoản từ file JSON / CSV
- Đếm số lượng tài khoản
- Phân loại trạng thái: active / checkpoint / banned / die
- UI/UX sạch, mobile-friendly

## Cài đặt Firebase (bắt buộc)

1. **Authentication → Sign-in method**
   - Bật **Email/Password**
   - Bật **Google** → thêm Support email → Save
2. Tạo sẵn user email (nếu dùng email) trong tab **Users**
3. **Realtime Database → Rules**:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    }
  }
}
```

4. Thêm domain của bạn vào **Authentication → Settings → Authorized domains**

## Cách chạy

```bash
php -S localhost:8000
```

Hoặc upload lên hosting và mở `index.html` / `index.php`.

## Định dạng file Import / Export

### JSON
```json
[
  {
    "email": "user@gmail.com",
    "password": "matkhau",
    "cookie": "c_user=...; xs=...",
    "note": "Acc chính",
    "status": "active",
    "createdAt": 1727430000000
  }
]
```

### CSV (Excel)
```
email,password,cookie,note,status,createdAt
user@gmail.com,matkhau,"c_user=...","Acc chính",active,2024-09-27T12:00:00.000Z
```

## Lưu ý

- Không hỗ trợ tự động đăng nhập Facebook.
- Việc nuôi nhiều tài khoản có thể vi phạm điều khoản Meta.
