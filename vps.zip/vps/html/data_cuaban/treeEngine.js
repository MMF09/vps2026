/**
 * treeEngine.js
 * =============
 * Thuật toán lõi để hiển thị cây JSON (object/array lồng nhau, có thể rất lớn)
 * NHANH NHẤT có thể trên HTML/JS thuần (không framework).
 *
 * Gồm 2 phần:
 *
 * 1) flattenTree(data, options)
 *    "Làm phẳng" cây lồng nhau thành một mảng 1 chiều các "rows" — chỉ những
 *    dòng đang thực sự cần hiển thị (có tính tới trạng thái thu gọn, phân trang
 *    của từng mảng, và bộ lọc/tìm kiếm hiện tại). Node bị thu gọn thì KHÔNG
 *    duyệt tiếp vào con của nó -> chi phí tỉ lệ với số dòng đang hiện, không
 *    phải tổng số node trong toàn bộ JSON.
 *
 * 2) VirtualList
 *    Trình render "ảo hoá" (virtual scrolling): dù "rows" có hàng chục nghìn
 *    phần tử, tại một thời điểm chỉ vài chục DOM node (đang nằm trong khung nhìn
 *    + một ít đệm) được tạo ra thật sự. Đây chính là kỹ thuật mà các bảng dữ
 *    liệu lớn (VSCode, DevTools, Google Sheets...) dùng để cuộn mượt với dữ
 *    liệu khổng lồ.
 */
(function (global) {
  const ROW_HEIGHT = 34; // px — chiều cao cố định mỗi dòng, giúp tính vị trí scroll O(1)

  // ---------------- 1. Làm phẳng cây ----------------
  function flattenTree(
    data,
    { collapsedPaths = new Set(), arrayPages = {}, pageSize = 50, visiblePaths = null } = {}
  ) {
    const rows = [];

    function walk(path, key, value, level) {
      // Đang lọc/tìm kiếm: bỏ hẳn những nhánh không dẫn tới kết quả nào.
      if (visiblePaths && !visiblePaths.has(path)) return;

      const isArray = Array.isArray(value);
      const isObject = value !== null && typeof value === "object";

      if (!isObject) {
        rows.push({ type: "leaf", path, key, value, level });
        return;
      }

      // Khi đang lọc, luôn mở node ra để thấy được kết quả nằm sâu bên trong.
      const isCollapsed = !visiblePaths && collapsedPaths.has(path);
      const entries = isArray ? value.map((v, i) => [i, v]) : Object.entries(value);

      rows.push({
        type: "node",
        path,
        key,
        level,
        isArray,
        count: entries.length,
        collapsed: isCollapsed,
      });

      if (isCollapsed) return; // dừng lại, không tốn chi phí duyệt con

      let list = entries;
      let paginated = false;
      let pageIndex = 0;
      let totalPages = 1;

      // Chỉ phân trang khi KHÔNG lọc (khi lọc cần thấy toàn bộ kết quả khớp).
      if (isArray && !visiblePaths && entries.length > pageSize) {
        paginated = true;
        totalPages = Math.ceil(entries.length / pageSize);
        pageIndex = Math.min(Math.max(arrayPages[path] || 0, 0), totalPages - 1);
        const start = pageIndex * pageSize;
        list = entries.slice(start, start + pageSize);
      }

      for (const [childKey, childValue] of list) {
        walk(`${path}.${childKey}`, childKey, childValue, level + 1);
      }

      if (paginated) {
        rows.push({
          type: "pagination",
          path,
          level: level + 1,
          pageIndex,
          totalPages,
          total: entries.length,
          pageSize,
        });
      }
    }

    walk("root", "root", data, 0);
    return rows;
  }

  // ---------------- 2. Virtual scrolling ----------------
  class VirtualList {
    /**
     * @param {HTMLElement} viewport - phần tử có overflow-y:auto và chiều cao cố định (CSS)
     * @param {(row: Object) => HTMLElement} renderRow - tạo 1 phần tử DOM cho 1 dòng dữ liệu
     */
    constructor(viewport, renderRow) {
      this.viewport = viewport;
      this.renderRow = renderRow;
      this.rows = [];

      // spacer tạo đúng chiều cao scroll ảo (bằng tổng số dòng * chiều cao 1 dòng)
      this.spacer = document.createElement("div");
      this.spacer.style.position = "relative";
      this.spacer.style.width = "100%";

      // content chứa các dòng ĐANG thực sự được vẽ, dịch chuyển bằng transform
      this.content = document.createElement("div");
      this.content.style.position = "absolute";
      this.content.style.left = "0";
      this.content.style.right = "0";
      this.content.style.top = "0";

      this.spacer.appendChild(this.content);
      this.viewport.innerHTML = "";
      this.viewport.appendChild(this.spacer);

      this._ticking = false;
      this._onScroll = () => this._scheduleRender();
      this.viewport.addEventListener("scroll", this._onScroll, { passive: true });

      if (typeof ResizeObserver !== "undefined") {
        this._resizeObserver = new ResizeObserver(() => this._scheduleRender());
        this._resizeObserver.observe(this.viewport);
      }
    }

    setRows(rows) {
      this.rows = rows;
      this.spacer.style.height = rows.length * ROW_HEIGHT + "px";

      // Nếu danh sách ngắn lại (vd sau khi lọc), kéo scrollTop cũ về vị trí hợp lệ.
      const maxScroll = Math.max(0, rows.length * ROW_HEIGHT - this.viewport.clientHeight);
      if (this.viewport.scrollTop > maxScroll) this.viewport.scrollTop = maxScroll;

      this._render();
    }

    _scheduleRender() {
      if (this._ticking) return;
      this._ticking = true;
      requestAnimationFrame(() => {
        this._render();
        this._ticking = false;
      });
    }

    // Chỉ tạo DOM cho các dòng nằm trong khung nhìn (+ buffer) -> O(số dòng hiện),
    // không phải O(tổng số dòng).
    _render() {
      const viewportHeight = this.viewport.clientHeight || 400;
      const scrollTop = this.viewport.scrollTop;
      const buffer = 8; // số dòng đệm trên/dưới để cuộn không bị giật trắng

      let start = Math.floor(scrollTop / ROW_HEIGHT) - buffer;
      let end = Math.ceil((scrollTop + viewportHeight) / ROW_HEIGHT) + buffer;
      start = Math.max(0, start);
      end = Math.min(this.rows.length, end);

      this.content.style.transform = `translateY(${start * ROW_HEIGHT}px)`;

      const frag = document.createDocumentFragment();
      for (let i = start; i < end; i++) {
        frag.appendChild(this.renderRow(this.rows[i], i));
      }
      this.content.innerHTML = "";
      this.content.appendChild(frag);
    }

    destroy() {
      this.viewport.removeEventListener("scroll", this._onScroll);
      if (this._resizeObserver) this._resizeObserver.disconnect();
    }
  }

  global.TreeEngine = { flattenTree, VirtualList, ROW_HEIGHT };
})(window);
