/**
 * Bank Van Hung Bian - Vanilla HTML/CSS/JS version
 * Firebase Auth + Realtime Database + JSON deep-merge + Tree view (virtual scroll
 * + tìm kiếm/bộ lọc nâng cao + phân trang), dùng treeEngine.js và searchEngine.js.
 */

// ===================== Firebase Config =====================
const firebaseConfig = {
  apiKey: "AIzaSyA02bvnhfmcoMJV8wz40O2YBISgSPvMhCE",
  authDomain: "bankvanhungbian.firebaseapp.com",
  databaseURL: "https://bankvanhungbian-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "bankvanhungbian",
  storageBucket: "bankvanhungbian.firebasestorage.app",
  messagingSenderId: "54989417529",
  appId: "1:54989417529:web:767b5ff40d379a339671e8"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// ===================== DOM refs =====================
const loadingEl = document.getElementById("loading");
const loginScreen = document.getElementById("login-screen");
const homeScreen = document.getElementById("home-screen");

const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const authBtn = document.getElementById("auth-btn");
const authBtnText = document.getElementById("auth-btn-text");
const authSpinner = document.getElementById("auth-spinner");
const switchModeBtn = document.getElementById("switch-mode");
const loginSubtitle = document.getElementById("login-subtitle");

const logoutBtn = document.getElementById("logout-btn");
const uploadBtn = document.getElementById("upload-btn");
const uploadText = document.getElementById("upload-text");
const uploadSpinner = document.getElementById("upload-spinner");
const fileInput = document.getElementById("file-input");

const skeletonEl = document.getElementById("skeleton");
const emptyMsg = document.getElementById("empty-msg");
const treeViewportEl = document.getElementById("tree-viewport");
const hintEl = document.getElementById("hint");
const matchInfoEl = document.getElementById("match-info");
const dataStatsEl = document.getElementById("data-stats");

const searchInput = document.getElementById("search-input");
const searchSpinner = document.getElementById("search-spinner");
const searchClearBtn = document.getElementById("search-clear");
const filterToggleBtn = document.getElementById("filter-toggle");
const filterPanel = document.getElementById("filter-panel");
const filterTargetSelect = document.getElementById("filter-target");
const filterModeSelect = document.getElementById("filter-mode");
const filterCaseCheckbox = document.getElementById("filter-case");
const filterTypeCheckboxes = Array.from(document.querySelectorAll(".filter-type"));
const pageSizeSelect = document.getElementById("page-size");
const filterResetBtn = document.getElementById("filter-reset");

// ===================== State =====================
let isRegister = false;
let dataListener = null;
let lastData = null;

const collapsedPaths = new Set(); // node nào đang bị thu gọn
let arrayPages = {}; // { [path]: trang hiện tại } cho từng mảng dài
let pageSize = 50;

const filterState = {
  query: "",
  target: "both", // "key" | "value" | "both"
  mode: "contains", // "contains" | "exact" | "regex"
  caseSensitive: false,
  types: new Set(), // rỗng = không lọc theo kiểu dữ liệu
};

let currentVisiblePaths = null; // null = không lọc, hiển thị bình thường
let searchDebounceTimer = null;
const SEARCH_DEBOUNCE_MS = 250;

// ===================== Helpers =====================
function showAlert(title, message) {
  window.alert(`${title}\n\n${message}`);
}

function setAuthLoading(on) {
  authBtn.disabled = on;
  authSpinner.classList.toggle("hidden", !on);
  authBtnText.classList.toggle("hidden", on);
}

function setUploadLoading(on) {
  uploadBtn.disabled = on;
  uploadSpinner.classList.toggle("hidden", !on);
  uploadText.classList.toggle("hidden", on);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Tô sáng phần text khớp với từ khóa đang tìm (an toàn XSS: escape trước, chèn <mark> sau).
function highlightMatches(rawStr) {
  const str = String(rawStr);
  if (!filterState.query) return escapeHtml(str);

  let re;
  try {
    const src = filterState.mode === "regex" ? filterState.query : SearchEngine.escapeRegExp(filterState.query);
    re = new RegExp(src, filterState.caseSensitive ? "g" : "gi");
  } catch (e) {
    return escapeHtml(str);
  }

  let result = "";
  let lastIndex = 0;
  let m;
  re.lastIndex = 0;
  while ((m = re.exec(str)) !== null) {
    result += escapeHtml(str.slice(lastIndex, m.index));
    result += `<mark>${escapeHtml(m[0])}</mark>`;
    lastIndex = m.index + m[0].length;
    if (m[0].length === 0) {
      re.lastIndex++; // tránh vòng lặp vô hạn khi regex khớp chuỗi rỗng
      if (re.lastIndex > str.length) break;
    }
  }
  result += escapeHtml(str.slice(lastIndex));
  return result;
}

// ===================== Deep Merge (hỗ trợ gộp theo "original" + đếm số lượng) =====================
function deepMerge(target, source) {
  if (source === null || source === undefined) return target;
  if (target === null || target === undefined) return source;

  if (Array.isArray(target) && Array.isArray(source)) {
    // Ưu tiên gộp theo trường "original" (nếu có)
    const hasOriginal = source.some(
      (item) => item && typeof item === "object" && "original" in item
    ) || target.some(
      (item) => item && typeof item === "object" && "original" in item
    );

    if (hasOriginal) {
      const map = new Map();
      const getCount = (item) => {
        if (!item || typeof item !== "object") return 1;
        if (typeof item.quantity === "number") return item.quantity;
        if (typeof item._count === "number") return item._count;
        if (typeof item.count === "number") return item.count;
        return 1;
      };

      [...target, ...source].forEach((item) => {
        if (item && typeof item === "object" && "original" in item) {
          const key = String(item.original);
          const existing = map.get(key);
          if (existing) {
            // Gộp object + cộng dồn số lượng
            const mergedItem = deepMerge(existing, item);
            const totalQty = getCount(existing) + getCount(item);
            mergedItem.quantity = totalQty;
            // Giữ tương thích với các tên field khác
            if ("_count" in existing || "_count" in item) mergedItem._count = totalQty;
            if ("count" in existing || "count" in item) mergedItem.count = totalQty;
            map.set(key, mergedItem);
          } else {
            // Bản sao để không mutate dữ liệu gốc
            const copy = { ...item };
            if (!("quantity" in copy) && !("_count" in copy) && !("count" in copy)) {
              copy.quantity = 1;
            }
            map.set(key, copy);
          }
        } else {
          // Item không có original: giữ nguyên (đưa vào map với key unique)
          const uniqueKey = "__no_original__" + JSON.stringify(item);
          if (!map.has(uniqueKey)) map.set(uniqueKey, item);
        }
      });
      return Array.from(map.values());
    }

    // Fallback: gộp theo "id" (logic cũ)
    const hasId = source.some(
      (item) => item && typeof item === "object" && "id" in item
    ) || target.some(
      (item) => item && typeof item === "object" && "id" in item
    );

    if (hasId) {
      const map = new Map();
      [...target, ...source].forEach((item) => {
        if (item && typeof item === "object" && "id" in item) {
          map.set(item.id, deepMerge(map.get(item.id) || {}, item));
        }
      });
      return Array.from(map.values());
    }

    // Cuối cùng: unique theo JSON.stringify
    const seen = new Set();
    const result = [];
    [...target, ...source].forEach((item) => {
      const key = JSON.stringify(item);
      if (!seen.has(key)) {
        seen.add(key);
        result.push(item);
      }
    });
    return result;
  }

  if (
    typeof target === "object" &&
    typeof source === "object" &&
    !Array.isArray(target) &&
    !Array.isArray(source)
  ) {
    const result = { ...target };
    for (const key of Object.keys(source)) {
      result[key] = deepMerge(target[key], source[key]);
    }
    return result;
  }

  return source;
}

// ===================== JSON Tree: render 1 dòng (dùng bởi VirtualList) =====================
function renderRow(row) {
  const el = document.createElement("div");
  el.style.paddingLeft = row.level * 16 + "px";

  if (row.type === "node") {
    el.className = "tree-row tree-node-row";
    const label = row.path === "root" ? "root" : String(row.key);
    const countLabel = row.isArray ? `[${row.count}]` : `{${row.count}}`;
    el.innerHTML = `
      <span class="tree-toggle" data-action="toggle" data-path="${escapeHtml(row.path)}">${row.collapsed ? "▶" : "▼"}</span>
      <span class="tree-key">${escapeHtml(label)} ${countLabel}</span>
    `;
    return el;
  }

  if (row.type === "pagination") {
    el.className = "tree-row tree-pagination-row";
    const from = row.pageIndex * row.pageSize + 1;
    const to = Math.min(row.total, from + row.pageSize - 1);
    el.innerHTML = `
      <button class="page-btn" data-action="page-prev" data-path="${escapeHtml(row.path)}" ${row.pageIndex === 0 ? "disabled" : ""}>‹ Trước</button>
      <span class="page-info">${from}-${to} / ${row.total} · Trang ${row.pageIndex + 1}/${row.totalPages}</span>
      <button class="page-btn" data-action="page-next" data-path="${escapeHtml(row.path)}" ${row.pageIndex >= row.totalPages - 1 ? "disabled" : ""}>Sau ›</button>
    `;
    return el;
  }

  // leaf
  el.className = "tree-row";
  el.title = `${row.key}: ${row.value}`; // xem đầy đủ khi giá trị bị cắt bớt (ellipsis)
  el.innerHTML = `
    <span class="tree-key">${highlightMatches(String(row.key))}: </span>
    <span class="tree-value">${highlightMatches(String(row.value))}</span>
  `;
  return el;
}

// ===================== Virtual list instance =====================
const virtualList = new TreeEngine.VirtualList(treeViewportEl, renderRow);

/** Tính tổng số lượng dữ liệu (ưu tiên field quantity / _count / count nếu có) */
function computeTotalQuantity(data) {
  if (data == null) return 0;

  // Nếu root là mảng các object có original/quantity
  if (Array.isArray(data)) {
    let total = 0;
    for (const item of data) {
      if (item && typeof item === "object") {
        if (typeof item.quantity === "number") total += item.quantity;
        else if (typeof item._count === "number") total += item._count;
        else if (typeof item.count === "number") total += item.count;
        else total += 1;
      } else {
        total += 1;
      }
    }
    return total;
  }

  // Nếu root là object, đếm số key lá hoặc đệ quy nhẹ
  if (typeof data === "object") {
    // Ưu tiên nếu có field tổng sẵn
    if (typeof data.totalQuantity === "number") return data.totalQuantity;
    if (typeof data.total === "number") return data.total;
    // Đếm số entry ở cấp 1
    return Object.keys(data).length;
  }

  return 1;
}

function updateDataStats() {
  if (!lastData) {
    dataStatsEl.classList.add("hidden");
    return;
  }
  const totalQty = computeTotalQuantity(lastData);
  const isArray = Array.isArray(lastData);
  const uniqueCount = isArray ? lastData.length : Object.keys(lastData || {}).length;

  if (isArray && totalQty !== uniqueCount) {
    dataStatsEl.textContent = `Tổng số lượng dữ liệu: ${totalQty.toLocaleString("vi-VN")} (sau hợp nhất còn ${uniqueCount.toLocaleString("vi-VN")} mục duy nhất theo original)`;
  } else {
    dataStatsEl.textContent = `Tổng số lượng dữ liệu load được: ${totalQty.toLocaleString("vi-VN")}`;
  }
  dataStatsEl.classList.remove("hidden");
}

function refreshTree() {
  if (!lastData) {
    virtualList.setRows([]);
    updateDataStats();
    return;
  }
  const rows = TreeEngine.flattenTree(lastData, {
    collapsedPaths,
    arrayPages,
    pageSize,
    visiblePaths: currentVisiblePaths,
  });
  virtualList.setRows(rows);

  if (currentVisiblePaths && rows.length === 0) {
    emptyMsg.textContent = "Không tìm thấy kết quả phù hợp";
    emptyMsg.classList.remove("hidden");
    treeViewportEl.classList.add("hidden");
  } else {
    emptyMsg.classList.add("hidden");
    treeViewportEl.classList.remove("hidden");
  }
  updateDataStats();
}

function setSearching(on) {
  searchSpinner.classList.toggle("hidden", !on);
}

function updateMatchInfo(searchResult) {
  if (!searchResult.active) {
    matchInfoEl.classList.add("hidden");
    hintEl.classList.remove("hidden");
    return;
  }
  hintEl.classList.add("hidden");
  matchInfoEl.classList.remove("hidden");
  const count = searchResult.matches.size;
  matchInfoEl.textContent =
    count > 0 ? `Tìm thấy ${count} kết quả phù hợp với bộ lọc` : "Không tìm thấy kết quả nào phù hợp với bộ lọc";
}

// Chạy thuật toán lọc (duyệt cây 1 lần) rồi vẽ lại. debounce=true dùng khi gọi
// từ sự kiện gõ phím liên tục (ô tìm kiếm); các control rời rạc (select/checkbox)
// gọi ngay lập tức vì không cần debounce.
function applyFilter({ debounce } = { debounce: false }) {
  if (debounce) {
    clearTimeout(searchDebounceTimer);
    setSearching(true);
    searchDebounceTimer = setTimeout(runFilterNow, SEARCH_DEBOUNCE_MS);
  } else {
    clearTimeout(searchDebounceTimer);
    runFilterNow();
  }
}

function runFilterNow() {
  setSearching(false);
  const result = SearchEngine.searchTree(lastData, filterState);
  currentVisiblePaths = result.visible;
  updateMatchInfo(result);
  refreshTree();
}

// ===================== Wiring: tìm kiếm & bộ lọc =====================
searchInput.addEventListener("input", () => {
  filterState.query = searchInput.value;
  searchClearBtn.classList.toggle("hidden", !filterState.query);
  applyFilter({ debounce: true });
});

searchClearBtn.addEventListener("click", () => {
  searchInput.value = "";
  filterState.query = "";
  searchClearBtn.classList.add("hidden");
  applyFilter({ debounce: false });
  searchInput.focus();
});

filterToggleBtn.addEventListener("click", () => {
  filterPanel.classList.toggle("hidden");
});

filterTargetSelect.addEventListener("change", () => {
  filterState.target = filterTargetSelect.value;
  applyFilter({ debounce: false });
});

filterModeSelect.addEventListener("change", () => {
  filterState.mode = filterModeSelect.value;
  applyFilter({ debounce: false });
});

filterCaseCheckbox.addEventListener("change", () => {
  filterState.caseSensitive = filterCaseCheckbox.checked;
  applyFilter({ debounce: false });
});

filterTypeCheckboxes.forEach((cb) => {
  cb.addEventListener("change", () => {
    filterState.types = new Set(filterTypeCheckboxes.filter((c) => c.checked).map((c) => c.value));
    applyFilter({ debounce: false });
  });
});

pageSizeSelect.addEventListener("change", () => {
  pageSize = parseInt(pageSizeSelect.value, 10) || 50;
  arrayPages = {}; // đổi kích thước trang -> quay về trang đầu cho mọi mảng
  refreshTree();
});

filterResetBtn.addEventListener("click", () => {
  filterState.query = "";
  filterState.target = "both";
  filterState.mode = "contains";
  filterState.caseSensitive = false;
  filterState.types = new Set();

  searchInput.value = "";
  searchClearBtn.classList.add("hidden");
  filterTargetSelect.value = "both";
  filterModeSelect.value = "contains";
  filterCaseCheckbox.checked = false;
  filterTypeCheckboxes.forEach((c) => (c.checked = false));

  applyFilter({ debounce: false });
});

// Click "▶/▼" để thu gọn/mở rộng, hoặc nút phân trang — dùng event delegation
// (1 listener duy nhất) để không phải gắn listener cho từng dòng.
treeViewportEl.addEventListener("click", (e) => {
  const target = e.target.closest("[data-action]");
  if (!target) return;
  const { action, path } = target.dataset;

  if (action === "toggle") {
    if (collapsedPaths.has(path)) collapsedPaths.delete(path);
    else collapsedPaths.add(path);
  } else if (action === "page-prev") {
    arrayPages[path] = Math.max(0, (arrayPages[path] || 0) - 1);
  } else if (action === "page-next") {
    arrayPages[path] = (arrayPages[path] || 0) + 1;
  } else {
    return;
  }
  refreshTree();
});

// ===================== Auth UI =====================
function updateAuthModeUI() {
  loginSubtitle.textContent = isRegister ? "Đăng ký tài khoản" : "Đăng nhập";
  authBtnText.textContent = isRegister ? "Đăng ký" : "Đăng nhập";
  switchModeBtn.textContent = isRegister
    ? "Đã có tài khoản? Đăng nhập"
    : "Chưa có tài khoản? Đăng ký";
}

switchModeBtn.addEventListener("click", () => {
  isRegister = !isRegister;
  updateAuthModeUI();
});

authBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    showAlert("Lỗi", "Vui lòng nhập đầy đủ email và mật khẩu");
    return;
  }

  setAuthLoading(true);
  try {
    if (isRegister) {
      await auth.createUserWithEmailAndPassword(email, password);
      showAlert("Thành công", "Đăng ký thành công!");
    } else {
      await auth.signInWithEmailAndPassword(email, password);
    }
  } catch (err) {
    showAlert("Lỗi", err.message || String(err));
  } finally {
    setAuthLoading(false);
  }
});

// Enter key
[emailInput, passwordInput].forEach((el) => {
  el.addEventListener("keydown", (e) => {
    if (e.key === "Enter") authBtn.click();
  });
});

logoutBtn.addEventListener("click", () => auth.signOut());

// ===================== Upload =====================
uploadBtn.addEventListener("click", () => fileInput.click());

/** Path dữ liệu riêng của từng user: users/{uid}/appData */
function userDataRef(uid) {
  return db.ref(`users/${uid}/appData`);
}

fileInput.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  e.target.value = ""; // reset so same file can be re-selected

  if (!file) return;

  if (
    !file.name.toLowerCase().endsWith(".json") &&
    file.type !== "application/json"
  ) {
    showAlert("Lỗi", "Vui lòng chọn file .json");
    return;
  }

  const user = auth.currentUser;
  if (!user) {
    showAlert("Lỗi", "Bạn cần đăng nhập trước khi upload");
    return;
  }

  setUploadLoading(true);
  try {
    const content = await file.text();
    const newJson = JSON.parse(content);

    const dataRef = userDataRef(user.uid);
    const snapshot = await dataRef.get();
    const currentData = snapshot.val() || {};
    const merged = deepMerge(currentData, newJson);

    await dataRef.set(merged);
    showAlert("Thành công", "Đã upload và hợp nhất dữ liệu thành công!");
  } catch (err) {
    console.error(err);
    showAlert("Lỗi", "Không thể xử lý file JSON: " + (err.message || err));
  } finally {
    setUploadLoading(false);
  }
});

// ===================== Auth state & data listener =====================
auth.onAuthStateChanged((user) => {
  loadingEl.classList.add("hidden");

  if (dataListener) {
    dataListener.off();
    dataListener = null;
  }

  if (user) {
    loginScreen.classList.add("hidden");
    homeScreen.classList.remove("hidden");

    // Hiệu ứng loading: hiện skeleton trong lúc chờ lần tải dữ liệu đầu tiên từ Firebase.
    skeletonEl.classList.remove("hidden");
    emptyMsg.classList.add("hidden");
    treeViewportEl.classList.add("hidden");

    dataListener = userDataRef(user.uid);
    dataListener.on("value", (snap) => {
      lastData = snap.val();
      skeletonEl.classList.add("hidden");

      if (!lastData) {
        emptyMsg.textContent = "Chưa có dữ liệu";
        emptyMsg.classList.remove("hidden");
        treeViewportEl.classList.add("hidden");
        virtualList.setRows([]);
        updateDataStats();
        return;
      }

      // Dữ liệu mới -> chạy lại bộ lọc hiện tại (nếu có) trên dữ liệu mới.
      if (SearchEngine.isFilterActive(filterState)) {
        runFilterNow();
      } else {
        emptyMsg.classList.add("hidden");
        treeViewportEl.classList.remove("hidden");
        refreshTree();
      }
    });
  } else {
    homeScreen.classList.add("hidden");
    loginScreen.classList.remove("hidden");

    lastData = null;
    collapsedPaths.clear();
    arrayPages = {};
    currentVisiblePaths = null;
    virtualList.setRows([]);
    skeletonEl.classList.add("hidden");
    emptyMsg.textContent = "Chưa có dữ liệu";
    emptyMsg.classList.remove("hidden");
    treeViewportEl.classList.add("hidden");
    updateDataStats();
  }
});
