/**
 * searchEngine.js
 * ================
 * Bộ lọc & tìm kiếm "nâng cao" trên cây JSON — duyệt toàn bộ cây một lần (O(n))
 * mỗi khi bộ lọc thay đổi (đã debounce ở app.js để không chạy trên từng phím gõ).
 *
 * Các tiêu chí lọc hỗ trợ đồng thời:
 * - target: "key" | "value" | "both" — tìm theo tên trường, giá trị, hay cả hai
 * - mode: "contains" | "exact" | "regex" — kiểu khớp chuỗi
 * - caseSensitive: có phân biệt hoa/thường hay không
 * - types: Set các kiểu dữ liệu của value cần giữ lại ("string","number","boolean","null")
 *
 * Trả về:
 * - matches: Set các path khớp trực tiếp (để đếm số kết quả)
 * - visible: Set các path được phép hiển thị = matches + mọi path tổ tiên của chúng,
 *   đảm bảo đường đi từ root tới từng kết quả luôn được mở ra cho người dùng thấy.
 *   Bằng null khi bộ lọc không hoạt động (không có gì để lọc).
 */
(function (global) {
  function getValueType(value) {
    if (value === null) return "null";
    if (Array.isArray(value)) return "array";
    if (typeof value === "object") return "object";
    return typeof value; // "string" | "number" | "boolean"
  }

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function matchesText(str, query, mode, caseSensitive) {
    if (!query) return true;
    if (mode === "regex") {
      try {
        return new RegExp(query, caseSensitive ? "" : "i").test(str);
      } catch (e) {
        return false; // regex không hợp lệ -> coi như không khớp, không throw ra ngoài
      }
    }
    let s = str;
    let q = query;
    if (!caseSensitive) {
      s = s.toLowerCase();
      q = q.toLowerCase();
    }
    return mode === "exact" ? s === q : s.includes(q);
  }

  function isFilterActive(filter) {
    return !!(filter.query && filter.query.trim()) || (filter.types && filter.types.size > 0);
  }

  function searchTree(data, filter) {
    const matches = new Set();
    const visible = new Set();

    if (!data || !isFilterActive(filter)) {
      return { matches, visible: null, active: false };
    }

    const query = (filter.query || "").trim();
    const mode = filter.mode || "contains";
    const caseSensitive = !!filter.caseSensitive;
    const target = filter.target || "both";
    const types = filter.types && filter.types.size > 0 ? filter.types : null;

    function markVisible(path) {
      const parts = path.split(".");
      let cur = "";
      for (const p of parts) {
        cur = cur ? `${cur}.${p}` : p;
        visible.add(cur);
      }
    }

    function textMatch(keyStr, valStr) {
      if (!query) return true; // chỉ đang lọc theo type, không có từ khóa
      if (target === "key") return matchesText(keyStr, query, mode, caseSensitive);
      if (target === "value") return matchesText(valStr, query, mode, caseSensitive);
      return (
        matchesText(keyStr, query, mode, caseSensitive) || matchesText(valStr, query, mode, caseSensitive)
      );
    }

    function walk(path, key, value) {
      const isLeaf = value === null || typeof value !== "object";

      if (isLeaf) {
        const type = getValueType(value);
        if (types && !types.has(type)) return; // không đúng kiểu dữ liệu -> loại
        if (textMatch(String(key), String(value))) {
          matches.add(path);
          markVisible(path);
        }
        return;
      }

      // Cho phép khớp theo tên của chính node cha (object/array) khi tìm theo key/both,
      // để có thể tìm nhanh một object/array theo tên trường của nó.
      if (!types && query && target !== "value" && matchesText(String(key), query, mode, caseSensitive)) {
        matches.add(path);
        markVisible(path);
      }

      const entries = Array.isArray(value) ? value.map((v, i) => [i, v]) : Object.entries(value);
      for (const [childKey, childValue] of entries) {
        walk(`${path}.${childKey}`, childKey, childValue);
      }
    }

    walk("root", "root", data);
    return { matches, visible, active: true };
  }

  global.SearchEngine = { searchTree, getValueType, isFilterActive, escapeRegExp };
})(window);
