// ─── App Logic (personal remittance tracker) ───────────────────────────────

function getUserDbUrl() {
  return `https://urf1forall-default-rtdb.firebaseio.com/users/${window.userId}/remittances`;
}

let allRecords = [];
let currentLang = 'vi';

function setLang(lang) {
  currentLang = lang;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.lang-btn').forEach(b => {
    if (b.textContent.includes(lang === 'vi' ? 'Việt' : 'English')) b.classList.add('active');
  });
  document.querySelectorAll('[data-vi]').forEach(el => {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.placeholder = el.getAttribute('data-' + lang) || el.placeholder;
    } else if (el.tagName === 'OPTION') {
      el.textContent = el.getAttribute('data-' + lang) || el.textContent;
    } else {
      el.textContent = el.getAttribute('data-' + lang) || el.textContent;
    }
  });
  document.getElementById('filter-search').placeholder = lang === 'vi' ? '🔍 Tìm kiếm…' : '🔍 Search…';
  renderHistory();
}

window.addEventListener('DOMContentLoaded', () => {
  const now = new Date();
  const local = new Date(now - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  document.getElementById('f-date').value = local;
});

async function fetchAll() {
  if (!window.userToken || !window.userId) return;
  try {
    const res = await fetch(`${getUserDbUrl()}.json?auth=${window.userToken}`);
    const data = await res.json();
    allRecords = data
      ? Object.entries(data).map(([id, val]) => ({ id, ...val }))
      : [];
    allRecords.sort((a, b) => new Date(b.date) - new Date(a.date));
    renderAll();
  } catch (e) {
    showToast('Không thể kết nối database', 'error');
    document.getElementById('history-list').innerHTML = `
      <div class="history-empty">
        <i class="ri-error-warning-line"></i>
        <p>${currentLang === 'vi' ? 'Lỗi kết nối Firebase' : 'Firebase connection error'}</p>
      </div>`;
  }
}

async function saveRecord(record) {
  const res = await fetch(`${getUserDbUrl()}.json?auth=${window.userToken}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(record)
  });
  const data = await res.json();
  return data.name;
}

async function deleteRecord(id) {
  await fetch(`${getUserDbUrl()}/${id}.json?auth=${window.userToken}`, { method: 'DELETE' });
}

async function submitTransfer() {
  const sender = document.getElementById('f-sender').value.trim();
  const recipient = document.getElementById('f-recipient').value.trim();
  const amount = parseFloat(document.getElementById('f-amount').value);
  const currency = document.getElementById('f-currency').value;
  const type = document.getElementById('f-type').value;
  const date = document.getElementById('f-date').value;
  const note = document.getElementById('f-note').value.trim();

  if (!sender || !recipient || !amount || !date) {
    showToast(currentLang === 'vi' ? 'Vui lòng điền đầy đủ thông tin' : 'Please fill in all required fields', 'error');
    return;
  }
  if (amount <= 0) {
    showToast(currentLang === 'vi' ? 'Số tiền phải lớn hơn 0' : 'Amount must be greater than 0', 'error');
    return;
  }

  const btn = document.getElementById('btn-submit');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>';

  const record = { sender, recipient, amount, currency, type, date, note, createdAt: new Date().toISOString() };
  try {
    const id = await saveRecord(record);
    allRecords.unshift({ id, ...record });
    renderAll();
    resetForm();
    showToast(currentLang === 'vi' ? '✅ Đã gửi tiền thành công!' : '✅ Money sent successfully!', 'success');
  } catch (e) {
    showToast(currentLang === 'vi' ? 'Gửi thất bại, thử lại' : 'Send failed, try again', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span id="btn-text" data-vi="Gửi tiền ngay" data-en="Send Money Now">${currentLang === 'vi' ? 'Gửi tiền ngay' : 'Send Money Now'}</span>`;
  }
}

function resetForm() {
  document.getElementById('f-sender').value = '';
  document.getElementById('f-recipient').value = '';
  document.getElementById('f-amount').value = '';
  document.getElementById('f-note').value = '';
}

function renderAll() {
  renderStats();
  renderHistory();
  renderChart();
}

function renderStats() {
  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();

  const totalVND = allRecords
    .filter(r => r.currency === 'VND' || !r.currency)
    .reduce((s, r) => s + r.amount, 0);

  const monthRecords = allRecords.filter(r => {
    const d = new Date(r.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  });
  const monthVND = monthRecords
    .filter(r => r.currency === 'VND' || !r.currency)
    .reduce((s, r) => s + r.amount, 0);

  const count = allRecords.length;
  const avgVND = count > 0 ? totalVND / count : 0;

  document.getElementById('stat-total').textContent = fmtVND(totalVND);
  document.getElementById('stat-month').textContent = fmtVND(monthVND);
  document.getElementById('stat-month-sub').textContent =
    currentLang === 'vi'
      ? `${monthRecords.length} lần • tháng ${thisMonth + 1}/${thisYear}`
      : `${monthRecords.length} transfers • ${now.toLocaleString('en', { month: 'long' })} ${thisYear}`;
  document.getElementById('stat-count').textContent = count;
  document.getElementById('stat-avg').textContent =
    avgVND > 0 ? fmtVND(Math.round(avgVND)) : '—';
}

function renderHistory() {
  const search = document.getElementById('filter-search').value.toLowerCase();
  const typeFilter = document.getElementById('filter-type').value;
  const sort = document.getElementById('filter-sort').value;

  let records = [...allRecords];

  if (search) records = records.filter(r =>
    r.sender?.toLowerCase().includes(search) ||
    r.recipient?.toLowerCase().includes(search) ||
    r.note?.toLowerCase().includes(search)
  );
  if (typeFilter) records = records.filter(r => r.type === typeFilter);

  if (sort === 'oldest') records.sort((a, b) => new Date(a.date) - new Date(b.date));
  else if (sort === 'highest') records.sort((a, b) => b.amount - a.amount);
  else records.sort((a, b) => new Date(b.date) - new Date(a.date));

  const label = document.getElementById('tx-count-label');
  label.textContent = currentLang === 'vi' ? `${records.length} giao dịch` : `${records.length} transfers`;

  const list = document.getElementById('history-list');
  if (!records.length) {
    list.innerHTML = `
      <div class="history-empty">
        <i class="ri-inbox-archive-line"></i>
        <p>${currentLang === 'vi' ? 'Chưa có giao dịch nào' : 'No transactions found'}</p>
      </div>`;
    return;
  }

  list.innerHTML = records.map(r => {
    const d = new Date(r.date);
    const dateStr = d.toLocaleDateString(currentLang === 'vi' ? 'vi-VN' : 'en-US', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const tagClass = { monthly: 'tag-monthly', transfer: 'tag-transfer', emergency: 'tag-emergency', other: 'tag-other' }[r.type] || 'tag-other';
    const tagLabel = {
      vi: { monthly: '💚 Hàng tháng', transfer: '🔵 Chuyển khoản', emergency: '🔴 Khẩn cấp', other: '⚪ Khác' },
      en: { monthly: '💚 Monthly', transfer: '🔵 Transfer', emergency: '🔴 Emergency', other: '⚪ Other' }
    }[currentLang][r.type] || '⚪';

    return `
      <div class="tx-item">
        <div class="tx-main">
          <div class="tx-name">
            ${escHtml(r.sender)} → ${escHtml(r.recipient)}
          </div>
          <div class="tx-date">${dateStr}</div>
          ${r.note ? `<div class="tx-note">${escHtml(r.note)}</div>` : ''}
        </div>
        <div>
          <div class="tx-amount">${fmtCurrency(r.amount, r.currency)}</div>
          <div class="tx-currency">${r.currency || 'VND'}</div>
        </div>
        <span class="tx-tag ${tagClass}">${tagLabel}</span>
        <button class="tx-delete" onclick="deleteItem('${r.id}')" title="${currentLang === 'vi' ? 'Xóa' : 'Delete'}"><i class="ri-close-line"></i></button>
      </div>`;
  }).join('');
}

function renderChart() {
  const container = document.getElementById('chart-bars');
  if (!allRecords.length) {
    container.innerHTML = `<div style="color:var(--text-dim);font-size:13px;width:100%;text-align:center;padding:40px 0">${currentLang === 'vi' ? 'Chưa có dữ liệu' : 'No data yet'}</div>`;
    return;
  }

  const now = new Date();
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ year: d.getFullYear(), month: d.getMonth(), label: d.toLocaleString(currentLang === 'vi' ? 'vi-VN' : 'en-US', { month: 'short' }) });
  }

  const totals = months.map(m => {
    return allRecords
      .filter(r => {
        const d = new Date(r.date);
        return d.getMonth() === m.month && d.getFullYear() === m.year && (!r.currency || r.currency === 'VND');
      })
      .reduce((s, r) => s + r.amount, 0);
  });

  const max = Math.max(...totals, 1);

  container.innerHTML = months.map((m, i) => {
    const pct = (totals[i] / max) * 100;
    const valStr = totals[i] > 0 ? fmtVND(totals[i]) : '—';
    return `
      <div class="bar-col">
        <div class="bar-val">${totals[i] > 0 ? shortFmt(totals[i]) : ''}</div>
        <div class="bar" style="height:${Math.max(pct, 2)}%" data-val="${valStr}"></div>
        <div class="bar-label">${m.label}</div>
      </div>`;
  }).join('');
}

async function deleteItem(id) {
  const confirmMsg = currentLang === 'vi' ? 'Xóa giao dịch này?' : 'Delete this transaction?';
  if (!window.confirm(confirmMsg)) return;
  try {
    await deleteRecord(id);
    allRecords = allRecords.filter(r => r.id !== id);
    renderAll();
    showToast(currentLang === 'vi' ? 'Đã xóa giao dịch' : 'Transaction deleted', 'success');
  } catch {
    showToast(currentLang === 'vi' ? 'Xóa thất bại' : 'Delete failed', 'error');
  }
}

function fmtVND(n) {
  if (!n) return '0 ₫';
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 }).format(n);
}

function fmtCurrency(n, cur) {
  if (!n) return '0';
  const c = cur || 'VND';
  try {
    return new Intl.NumberFormat(currentLang === 'vi' ? 'vi-VN' : 'en-US', {
      style: 'currency', currency: c, maximumFractionDigits: c === 'VND' || c === 'JPY' ? 0 : 2
    }).format(n);
  } catch {
    return n.toLocaleString();
  }
}

function shortFmt(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(0) + 'K';
  return n.toString();
}

function escHtml(s) {
  return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function setQuickAmount(v) {
  document.getElementById('f-amount').value = v;
}

function updateCurrencyPrefix() {
  const cur = document.getElementById('f-currency').value;
  const symbols = { VND: '₫', USD: '$', EUR: '€', JPY: '¥', KRW: '₩', AUD: 'A$' };
  document.getElementById('currency-prefix').textContent = symbols[cur] || cur;
  document.getElementById('quick-amounts').style.display = cur === 'VND' ? 'flex' : 'none';
}

function showToast(msg, type = 'success') {
  const wrap = document.getElementById('toast-wrap');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}
