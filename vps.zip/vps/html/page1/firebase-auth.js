import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDVRzkeY2reKjR5Gv0dHx55geqgivUjEAQ",
  authDomain: "urf1forall.firebaseapp.com",
  databaseURL: "https://urf1forall-default-rtdb.firebaseio.com",
  projectId: "urf1forall",
  storageBucket: "urf1forall.firebasestorage.app",
  messagingSenderId: "335719421403",
  appId: "1:335719421403:web:bd46318fad54a532a4c3fe",
  measurementId: "G-4DB7Q6Q51D"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

window.userToken = null;
window.userId = null;

window.loginWithGoogle = async function () {
  try {
    await signInWithPopup(auth, provider);
    showToast(currentLang === 'vi' ? 'Đăng nhập thành công!' : 'Login Successful!', 'success');
  } catch (error) {
    console.error(error);
    showToast(currentLang === 'vi' ? 'Đăng nhập thất bại' : 'Login failed', 'error');
  }
};

window.logout = function () {
  signOut(auth).then(() => {
    showToast(currentLang === 'vi' ? 'Đã đăng xuất' : 'Logged out', 'success');
  }).catch((error) => {
    console.error(error);
  });
};

onAuthStateChanged(auth, async (user) => {
  const authSection = document.getElementById('auth-section');
  const appContent = document.getElementById('app-content');
  const loginNotice = document.getElementById('login-notice');

  if (user) {
    window.userToken = await user.getIdToken();
    window.userId = user.uid;

    authSection.innerHTML = `
      <div class="user-profile">
        <span class="user-info">Hi, <b>${user.displayName || 'User'}</b></span>
        <img class="user-avatar" src="${user.photoURL || ''}" alt="Avatar" referrerpolicy="no-referrer">
        <button class="btn-logout" onclick="logout()" title="Đăng xuất"><i class="ri-logout-box-r-line"></i></button>
      </div>
    `;

    loginNotice.style.display = 'none';
    appContent.classList.remove('auth-lock-state');

    if (typeof fetchAll === 'function') fetchAll();
  } else {
    window.userToken = null;
    window.userId = null;
    authSection.innerHTML = `
      <button class="btn-google" onclick="loginWithGoogle()">
        <i class="ri-google-fill"></i> Đăng nhập
      </button>
    `;

    loginNotice.style.display = 'block';
    appContent.classList.add('auth-lock-state');
  }
});
