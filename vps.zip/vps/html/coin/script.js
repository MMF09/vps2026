// ===== Random coincidence data =====
const coincidences = [
  "Mark Twain sinh năm 1835 cùng lúc sao chổi Halley xuất hiện và qua đời năm 1910 khi sao chổi trở lại.",
  "Thomas Jefferson và John Adams – hai người soạn thảo Tuyên ngôn Độc lập – cùng qua đời ngày 4/7/1826, đúng 50 năm sau ngày Mỹ độc lập.",
  "Năm 1898, tiểu thuyết 'The Wreck of the Titan' mô tả một con tàu 'không thể chìm' va phải tảng băng. 14 năm sau Titanic gặp đúng số phận đó.",
  "Hai anh em song sinh Jim bị tách từ nhỏ, 39 năm sau đoàn tụ: cùng tên Jim, cùng vợ tên Linda, cùng con trai James Allan/Alan, cùng chó tên Toy.",
  "Ngày 1/3/1950, nhà thờ Beatrice (Nebraska) phát nổ đúng giờ tập hợp xướng. Cả 15 thành viên đều đến muộn vì lý do riêng – không ai bị thương.",
  "Violet Jessop sống sót qua 3 thảm họa của 3 tàu chị em: Olympic (1911), Titanic (1912) và Britannic (1916).",
  "Edwin Booth (anh trai của sát thủ John Wilkes Booth) từng cứu mạng Robert Todd Lincoln – con trai của Tổng thống Abraham Lincoln.",
  "Wilmer McLean chứng kiến Nội chiến Mỹ bắt đầu ngay sân nhà ông (1861) và kết thúc trong phòng khách nhà ông (1865).",
  "Abraham Lincoln và John F. Kennedy được bầu Tổng thống cách nhau đúng 100 năm, đều bị ám sát vào thứ Sáu và đều được kế nhiệm bởi người tên Johnson.",
  "Tsutomu Yamaguchi sống sót qua cả hai quả bom nguyên tử Hiroshima và Nagasaki năm 1945.",
  "Năm 1664 và 1785, hai con tàu khác nhau chìm gần bờ biển Wales. Trong cả hai vụ, người sống sót duy nhất đều tên Hugh Williams.",
  "Alexander Fleming phát hiện penicillin nhờ một đĩa petri bị nấm mốc xâm nhập khi ông đi nghỉ – một 'sự cố' vô tình cứu hàng triệu mạng người."
];

let lastIndex = -1;

function showRandom() {
  const el = document.getElementById('random-text');
  el.classList.add('fade');

  setTimeout(() => {
    let idx;
    do {
      idx = Math.floor(Math.random() * coincidences.length);
    } while (idx === lastIndex && coincidences.length > 1);

    lastIndex = idx;
    el.textContent = coincidences[idx];
    el.classList.remove('fade');
  }, 280);
}

// ===== Floating particles =====
const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');
let particles = [];
let w, h;

function resize() {
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}

function createParticles() {
  particles = [];
  const count = Math.min(60, Math.floor(w * h / 18000));
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.8 + 0.4,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      alpha: Math.random() * 0.5 + 0.2
    });
  }
}

function draw() {
  ctx.clearRect(0, 0, w, h);
  particles.forEach(p => {
    p.x += p.vx;
    p.y += p.vy;

    if (p.x < 0) p.x = w;
    if (p.x > w) p.x = 0;
    if (p.y < 0) p.y = h;
    if (p.y > h) p.y = 0;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(196, 181, 253, ${p.alpha})`;
    ctx.fill();
  });
  requestAnimationFrame(draw);
}

window.addEventListener('resize', () => {
  resize();
  createParticles();
});

resize();
createParticles();
draw();

// Show one random on load after a short delay
setTimeout(showRandom, 800);
