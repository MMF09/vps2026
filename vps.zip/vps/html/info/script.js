// ==================== FIREBASE CONFIG ====================
const firebaseConfig = {
  apiKey: "AIzaSyASfKSM4k9PVqGSu2ycd5Uv1ax0vbScg0I",
  authDomain: "soloskill.firebaseapp.com",
  databaseURL: "https://soloskill-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "soloskill",
  storageBucket: "soloskill.firebasestorage.app",
  messagingSenderId: "959816905162",
  appId: "1:959816905162:web:ccdd0823a2f40d1f71df33",
  measurementId: "G-PSDVH32MQT"
};

// Khởi tạo Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// Chỉ cho phép email này
const ALLOWED_EMAIL = "lapgia57@gmail.com";

// ==================== PHÂN TRANG & INFINITE SCROLL ====================
const PAGE_SIZE = 15;                 // Số bản ghi mỗi lần tải
let currentUserId = null;
let houses = [];                      // Dữ liệu đã tải
let oldestCreatedAt = null;           // createdAt nhỏ nhất hiện có (để tải trang tiếp)
let isLoading = false;
let hasMore = true;
let isFirstLoad = true;

// ==================== AUTH ====================
function login() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!email || !password) {
    showLoginError("Vui lòng nhập đầy đủ email và mật khẩu");
    return;
  }

  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      if (user.email !== ALLOWED_EMAIL) {
        auth.signOut();
        showLoginError("Chỉ email " + ALLOWED_EMAIL + " được phép đăng nhập!");
        return;
      }
      document.getElementById('loginError').classList.add('hidden');
    })
    .catch((error) => {
      let msg = "Đăng nhập thất bại";
      if (error.code === 'auth/user-not-found') msg = "Email chưa được đăng ký trên Firebase";
      else if (error.code === 'auth/wrong-password') msg = "Mật khẩu không đúng";
      else if (error.code === 'auth/invalid-email') msg = "Email không hợp lệ";
      else if (error.code === 'auth/invalid-credential') msg = "Email hoặc mật khẩu không đúng";
      else if (error.code === 'auth/too-many-requests') msg = "Quá nhiều lần thử. Vui lòng thử lại sau";
      showLoginError(msg);
    });
}

function logout() {
  auth.signOut();
}

function showLoginError(msg) {
  const el = document.getElementById('loginError');
  el.textContent = msg;
  el.classList.remove('hidden');
}

// Theo dõi trạng thái đăng nhập
auth.onAuthStateChanged((user) => {
  if (user && user.email === ALLOWED_EMAIL) {
    currentUserId = user.uid;
    document.getElementById('loginSection').classList.add('hidden');
    document.getElementById('mainContent').classList.remove('hidden');
    document.getElementById('userInfo').classList.remove('hidden');
    document.getElementById('userEmail').textContent = user.email;

    // Reset trạng thái phân trang và tải trang đầu
    resetPagination();
    loadMoreHouses();
  } else {
    currentUserId = null;
    document.getElementById('loginSection').classList.remove('hidden');
    document.getElementById('mainContent').classList.add('hidden');
    document.getElementById('userInfo').classList.add('hidden');
  }
});

// ==================== PATH THEO RULES MỚI ====================
// Rules: users/$uid → chỉ user đó đọc/ghi
function housesRef() {
  return db.ref(`users/${currentUserId}/houses`);
}

// ==================== CRUD ====================
function showAddForm() {
  resetForm();
  document.getElementById('formTitle').textContent = "Thêm thông tin chủ nhà";
  document.getElementById('adminForm').scrollIntoView({ behavior: 'smooth' });
}

function resetForm() {
  document.getElementById('editId').value = '';
  document.getElementById('address').value = '';
  document.getElementById('ownerName').value = '';
  document.getElementById('phone').value = '';
  document.getElementById('status').value = 'da_o';
  document.getElementById('notes').value = '';
  document.getElementById('formTitle').textContent = "Thêm thông tin chủ nhà";
  document.getElementById('formMessage').classList.add('hidden');
}

function saveHouse() {
  if (!currentUserId) return;

  const id = document.getElementById('editId').value;
  const address = document.getElementById('address').value.trim();
  const ownerName = document.getElementById('ownerName').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const status = document.getElementById('status').value;
  const notes = document.getElementById('notes').value.trim();

  if (!address || !ownerName) {
    showFormMessage("Vui lòng nhập Địa chỉ và Tên chủ nhà", false);
    return;
  }

  const data = {
    address,
    ownerName,
    phone,
    status,
    notes,
    updatedAt: Date.now()
  };

  const ref = housesRef();

  if (id) {
    // Cập nhật
    ref.child(id).update(data)
      .then(() => {
        showFormMessage("Cập nhật thành công!", true);
        // Cập nhật local
        const idx = houses.findIndex(h => h.id === id);
        if (idx !== -1) {
          houses[idx] = { ...houses[idx], ...data };
          renderHouses();
        }
        resetForm();
      })
      .catch(err => showFormMessage("Lỗi: " + err.message, false));
  } else {
    // Thêm mới
    data.createdAt = Date.now();
    ref.push(data)
      .then(() => {
        showFormMessage("Thêm mới thành công!", true);
        resetForm();
        // Tải lại từ đầu để thấy bản ghi mới nhất
        resetPagination();
        loadMoreHouses();
      })
      .catch(err => showFormMessage("Lỗi: " + err.message, false));
  }
}

function showFormMessage(msg, isSuccess) {
  const el = document.getElementById('formMessage');
  el.textContent = msg;
  el.className = isSuccess ? 'success' : 'error';
  el.classList.remove('hidden');
}

function editHouse(id, data) {
  document.getElementById('editId').value = id;
  document.getElementById('address').value = data.address || '';
  document.getElementById('ownerName').value = data.ownerName || '';
  document.getElementById('phone').value = data.phone || '';
  document.getElementById('status').value = data.status || 'da_o';
  document.getElementById('notes').value = data.notes || '';
  document.getElementById('formTitle').textContent = "Sửa thông tin chủ nhà";
  document.getElementById('adminForm').scrollIntoView({ behavior: 'smooth' });
}

function deleteHouse(id) {
  if (!confirm("Bạn có chắc muốn xóa thông tin này?")) return;
  if (!currentUserId) return;

  housesRef().child(id).remove()
    .then(() => {
      houses = houses.filter(h => h.id !== id);
      renderHouses();
      if (houses.length === 0) {
        document.getElementById('houseList').innerHTML =
          '<p class="empty-state">Chưa có dữ liệu nào.</p>';
      }
    })
    .catch(err => alert("Lỗi xóa: " + err.message));
}

// ==================== PHÂN TRANG + INFINITE SCROLL ====================
function resetPagination() {
  houses = [];
  oldestCreatedAt = null;
  hasMore = true;
  isFirstLoad = true;
  isLoading = false;
  document.getElementById('houseList').innerHTML = '';
  document.getElementById('endOfList').classList.add('hidden');
  document.getElementById('loadingIndicator').classList.add('hidden');
}

function showLoading(show) {
  const el = document.getElementById('loadingIndicator');
  if (show) {
    el.classList.remove('hidden');
  } else {
    el.classList.add('hidden');
  }
}

function loadMoreHouses() {
  if (!currentUserId || isLoading || !hasMore) return;

  isLoading = true;
  showLoading(true);

  let query = housesRef().orderByChild('createdAt');

  if (oldestCreatedAt !== null) {
    // Tải các bản ghi cũ hơn
    query = query.endBefore(oldestCreatedAt).limitToLast(PAGE_SIZE);
  } else {
    // Trang đầu tiên
    query = query.limitToLast(PAGE_SIZE);
  }

  query.once('value')
    .then((snapshot) => {
      const data = snapshot.val();
      let newItems = [];

      if (data) {
        newItems = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));

        // Sắp xếp giảm dần theo createdAt (mới nhất trước)
        newItems.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      }

      if (newItems.length < PAGE_SIZE) {
        hasMore = false;
      }

      if (newItems.length > 0) {
        // Cập nhật oldestCreatedAt (bản ghi cũ nhất trong đợt này)
        const oldestInBatch = newItems[newItems.length - 1];
        oldestCreatedAt = oldestInBatch.createdAt;

        // Thêm vào danh sách (tránh trùng)
        const existingIds = new Set(houses.map(h => h.id));
        const uniqueNew = newItems.filter(h => !existingIds.has(h.id));
        houses = houses.concat(uniqueNew);
      }

      renderHouses();

      if (!hasMore) {
        document.getElementById('endOfList').classList.remove('hidden');
      }

      isFirstLoad = false;
      isLoading = false;
      showLoading(false);
    })
    .catch((error) => {
      console.error(error);
      document.getElementById('houseList').innerHTML =
        `<p class="error">Lỗi tải dữ liệu: ${error.message}</p>`;
      isLoading = false;
      showLoading(false);
    });
}

function renderHouses() {
  const listEl = document.getElementById('houseList');

  if (houses.length === 0 && !isLoading) {
    listEl.innerHTML = '<p class="empty-state">Chưa có dữ liệu nào.</p>';
    return;
  }

  let html = `
    <table>
      <thead>
        <tr>
          <th>Địa chỉ</th>
          <th>Chủ nhà</th>
          <th>Điện thoại</th>
          <th>Trạng thái</th>
          <th>Ghi chú</th>
          <th>Thao tác</th>
        </tr>
      </thead>
      <tbody>
  `;

  houses.forEach(h => {
    const statusText = h.status === 'da_o' ? 'Đã ở' : 'Chưa ở';
    const statusClass = h.status === 'da_o' ? 'status-da-o' : 'status-chua-o';
    const safeData = JSON.stringify({
      address: h.address,
      ownerName: h.ownerName,
      phone: h.phone,
      status: h.status,
      notes: h.notes
    }).replace(/'/g, "&#39;");

    html += `
      <tr>
        <td data-label="Địa chỉ">${escapeHtml(h.address)}</td>
        <td data-label="Chủ nhà">${escapeHtml(h.ownerName)}</td>
        <td data-label="Điện thoại">${escapeHtml(h.phone || '-')}</td>
        <td data-label="Trạng thái"><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td data-label="Ghi chú">${escapeHtml(h.notes || '-')}</td>
        <td data-label="Thao tác" class="actions">
          <button class="btn btn-primary" onclick='editHouse("${h.id}", ${safeData})'>Sửa</button>
          <button class="btn btn-danger" onclick="deleteHouse('${h.id}')">Xóa</button>
        </td>
      </tr>
    `;
  });

  html += '</tbody></table>';
  listEl.innerHTML = html;
}

// Infinite scroll: lắng nghe sự kiện cuộn
window.addEventListener('scroll', () => {
  if (isLoading || !hasMore || !currentUserId) return;

  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const windowHeight = window.innerHeight;
  const docHeight = document.documentElement.scrollHeight;

  // Khi cách đáy khoảng 200px thì tải thêm
  if (scrollTop + windowHeight >= docHeight - 200) {
    loadMoreHouses();
  }
});

// Hàm chống XSS
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}