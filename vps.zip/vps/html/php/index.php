<?php
require_once __DIR__ . '/includes/config.php';

$categories = load_categories();

$totalItems = 0;
foreach ($categories as $cat) {
    $totalItems += count($cat['items']);
}

$pageTitle = SITE_NAME . ' — Trang chủ';

require __DIR__ . '/includes/header.php';
?>

<section class="hero" data-reveal>
    <h1>Khám phá các nhóm chủ đề an ninh mạng</h1>
    <p>
        Portal này trình bày lại — dưới dạng mô tả tổng quan, <strong>không phải mã khai thác</strong> —
        các nhóm lỗ hổng thường được nhắc tới trong lĩnh vực kiểm thử xâm nhập (penetration testing).
    </p>

    <div class="stats">
        <div class="stat">
            <strong><?php echo count($categories); ?></strong>
            <span>Danh mục</span>
        </div>
        <div class="stat">
            <strong><?php echo $totalItems; ?></strong>
            <span>Chủ đề con</span>
        </div>
    </div>

    <div class="filter-bar">
        <label class="sr-only" for="liveFilter">Lọc nhanh danh mục</label>
        <input
            type="text"
            id="liveFilter"
            placeholder="Lọc nhanh theo tên danh mục... (không tải lại trang)"
            autocomplete="off"
        >
    </div>
</section>

<section class="grid" data-filter-list>
    <?php foreach ($categories as $slug => $cat) {
        $filterText = h(mb_strtolower($cat['title'] . ' ' . $cat['summary']));
        $href = h(url('category.php?slug=' . urlencode($slug)));
    ?>
        <a class="card"
           href="<?php echo $href; ?>"
           data-filter-item="<?php echo $filterText; ?>"
           data-reveal>
            <div class="card-icon"><?php echo $cat['icon']; ?></div>
            <h2><?php echo h($cat['title']); ?></h2>
            <p><?php echo h($cat['summary']); ?></p>
            <span class="card-meta"><?php echo count($cat['items']); ?> chủ đề</span>
            <span class="card-link">Xem chi tiết <span aria-hidden="true">→</span></span>
        </a>
    <?php } ?>
</section>

<p id="filterEmpty" class="empty-state" hidden>
    Không tìm thấy danh mục nào khớp với từ khóa lọc. Thử dùng
    <a href="<?php echo h(url('search.php')); ?>">trang tìm kiếm đầy đủ</a> để tìm trong cả các chủ đề con.
</p>

<?php require __DIR__ . '/includes/footer.php'; ?>
