<?php
require_once __DIR__ . '/includes/config.php';

$categories = load_categories();
$slug = isset($_GET['slug']) ? (string)$_GET['slug'] : '';

if (!isset($categories[$slug])) {
    http_response_code(404);
    $pageTitle = 'Không tìm thấy — ' . SITE_NAME;
    require __DIR__ . '/includes/header.php';
    ?>
    <section class="hero" data-reveal>
        <h1>404 — Không tìm thấy danh mục</h1>
        <p>Danh mục bạn yêu cầu không tồn tại hoặc đã bị thay đổi đường dẫn.</p>
        <p><a class="btn" href="<?php echo h(url('index.php')); ?>">&larr; Quay lại trang chủ</a></p>
    </section>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$cat = $categories[$slug];
$pageTitle = $cat['title'] . ' — ' . SITE_NAME;

require __DIR__ . '/includes/header.php';
?>

<nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="<?php echo h(url('index.php')); ?>">Trang chủ</a>
    <span aria-hidden="true">/</span>
    <span aria-current="page"><?php echo h($cat['title']); ?></span>
</nav>

<div class="category-layout">
    <div class="category-main">
        <section class="hero" data-reveal>
            <div class="card-icon big"><?php echo $cat['icon']; ?></div>
            <h1><?php echo h($cat['title']); ?></h1>
            <p><?php echo h($cat['summary']); ?></p>

            <?php if (count($cat['items']) > 3) { ?>
                <div class="filter-bar">
                    <label class="sr-only" for="liveFilter">Lọc nhanh chủ đề con</label>
                    <input
                        type="text"
                        id="liveFilter"
                        placeholder="Lọc nhanh trong danh mục này..."
                        autocomplete="off"
                    >
                </div>
            <?php } ?>
        </section>

        <section class="item-list" data-filter-list>
            <?php foreach ($cat['items'] as $item) {
                $anchor = slugify($item['name']);
                $filterText = h(mb_strtolower($item['name'] . ' ' . $item['desc']));
            ?>
                <article
                    class="item"
                    id="<?php echo h($anchor); ?>"
                    data-filter-item="<?php echo $filterText; ?>"
                    data-reveal
                >
                    <h3>
                        <?php echo h($item['name']); ?>
                        <a class="anchor-link" href="#<?php echo h($anchor); ?>" aria-label="Liên kết tới mục này">#</a>
                    </h3>
                    <p><?php echo h($item['desc']); ?></p>
                </article>
            <?php } ?>
        </section>

        <p id="filterEmpty" class="empty-state" hidden>
            Không có chủ đề con nào khớp với từ khóa lọc.
        </p>
    </div>

    <aside class="category-sidebar" aria-label="Các danh mục khác">
        <h2>Danh mục khác</h2>
        <ul>
            <?php foreach ($categories as $otherSlug => $otherCat) {
                $isActive = ($otherSlug === $slug);
                $href = h(url('category.php?slug=' . urlencode($otherSlug)));
            ?>
                <li>
                    <a
                        href="<?php echo $href; ?>"
                        class="<?php echo $isActive ? 'active' : ''; ?>"
                        <?php echo $isActive ? 'aria-current="page"' : ''; ?>
                    >
                        <span class="sidebar-icon"><?php echo $otherCat['icon']; ?></span>
                        <?php echo h($otherCat['title']); ?>
                    </a>
                </li>
            <?php } ?>
        </ul>
    </aside>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
