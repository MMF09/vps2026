<?php
require_once __DIR__ . '/includes/config.php';

$categories = load_categories();
$query = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$results = ($query !== '') ? search_categories($categories, $query) : array();

$pageTitle = (($query !== '') ? 'Kết quả: ' . $query . ' — ' : 'Tìm kiếm — ') . SITE_NAME;

require __DIR__ . '/includes/header.php';
?>

<section class="hero" data-reveal>
    <h1>Tìm kiếm</h1>
    <p>Tìm trong tiêu đề và mô tả của tất cả danh mục, chủ đề con trên portal.</p>

    <form class="search-form search-form--big" action="<?php echo h(url('search.php')); ?>" method="get" role="search">
        <label class="sr-only" for="pageSearch">Từ khóa tìm kiếm</label>
        <input
            type="search"
            id="pageSearch"
            name="q"
            value="<?php echo h($query); ?>"
            placeholder="Ví dụ: XSS, router, phân quyền..."
            autocomplete="off"
            autofocus
        >
        <button type="submit">Tìm kiếm</button>
    </form>
</section>

<?php if ($query === '') { ?>

    <p class="empty-state">Nhập từ khóa phía trên để bắt đầu tìm kiếm.</p>

<?php } elseif (empty($results)) { ?>

    <p class="empty-state">
        Không tìm thấy kết quả nào cho “<strong><?php echo h($query); ?></strong>”.
        Hãy thử một từ khóa khác hoặc xem toàn bộ
        <a href="<?php echo h(url('index.php')); ?>">danh mục tại trang chủ</a>.
    </p>

<?php } else { ?>

    <p class="result-count">
        Tìm thấy <strong><?php echo count($results); ?></strong> kết quả cho “<strong><?php echo h($query); ?></strong>”.
    </p>

    <section class="item-list">
        <?php foreach ($results as $r) {
            $href = url('category.php?slug=' . urlencode($r['slug']));
            if ($r['anchor'] !== '') {
                $href .= '#' . $r['anchor'];
            }
        ?>
            <article class="item result-item" data-reveal>
                <span class="result-badge"><?php echo $r['icon']; ?> <?php echo h($r['cat_title']); ?></span>
                <h3>
                    <a href="<?php echo h($href); ?>"><?php echo h($r['name']); ?></a>
                </h3>
                <p><?php echo h($r['text']); ?></p>
            </article>
        <?php } ?>
    </section>

<?php } ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
