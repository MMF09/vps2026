/**
 * SecKnowledge Portal — app.js
 * Toàn bộ hiệu ứng ở đây chỉ nhằm cải thiện UX (progressive enhancement).
 * Website vẫn hoạt động đầy đủ khi tắt JavaScript (PHP render sẵn mọi nội dung).
 */
(function () {
  'use strict';

  var root = document.documentElement;
  var body = document.body;

  /* ---------------------------------------------------------------
   * 1. Theme toggle (dark / light) — lưu lựa chọn vào localStorage
   * ------------------------------------------------------------- */
  function initTheme() {
    var btn = document.getElementById('themeToggle');
    if (!btn) return;

    btn.addEventListener('click', function () {
      var current = root.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
      var next = current === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('secportal-theme', next); } catch (e) {}
    });
  }

  /* ---------------------------------------------------------------
   * 2. Menu điều hướng trên mobile
   * ------------------------------------------------------------- */
  function initNavToggle() {
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('siteNav');
    if (!toggle || !nav) return;

    toggle.addEventListener('click', function () {
      var isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      toggle.classList.toggle('is-active', isOpen);
    });

    document.addEventListener('click', function (e) {
      if (!nav.classList.contains('is-open')) return;
      if (nav.contains(e.target) || toggle.contains(e.target)) return;
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.classList.remove('is-active');
    });

    var links = nav.querySelectorAll('a');
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener('click', function () {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.classList.remove('is-active');
      });
    }
  }

  /* ---------------------------------------------------------------
   * 3. Phím tắt "/" để focus vào ô tìm kiếm
   * ------------------------------------------------------------- */
  function initSearchShortcut() {
    var input = document.getElementById('navSearch');
    if (!input) return;

    document.addEventListener('keydown', function (e) {
      var tag = (document.activeElement && document.activeElement.tagName) || '';
      var isTyping = tag === 'INPUT' || tag === 'TEXTAREA';
      if (e.key === '/' && !isTyping) {
        e.preventDefault();
        input.focus();
      }
      if (e.key === 'Escape' && document.activeElement === input) {
        input.blur();
      }
    });
  }

  /* ---------------------------------------------------------------
   * 4. Lọc trực tiếp (client-side) trên trang chủ / trang danh mục
   * ------------------------------------------------------------- */
  function initLiveFilter() {
    var filterInput = document.getElementById('liveFilter');
    var list = document.querySelector('[data-filter-list]');
    if (!filterInput || !list) return;

    var items = Array.prototype.slice.call(list.querySelectorAll('[data-filter-item]'));
    var emptyState = document.getElementById('filterEmpty');

    function applyFilter() {
      var term = filterInput.value.trim().toLowerCase();
      var visibleCount = 0;

      items.forEach(function (item) {
        var haystack = item.getAttribute('data-filter-item').toLowerCase();
        var match = term === '' || haystack.indexOf(term) !== -1;
        item.hidden = !match;
        if (match) visibleCount++;
      });

      if (emptyState) {
        emptyState.hidden = visibleCount !== 0;
      }
    }

    filterInput.addEventListener('input', applyFilter);
    applyFilter();
  }

  /* ---------------------------------------------------------------
   * 5. Hiệu ứng xuất hiện khi cuộn tới (scroll reveal)
   * ------------------------------------------------------------- */
  function initScrollReveal() {
    var targets = document.querySelectorAll('[data-reveal]');
    if (!targets.length) return;

    if (!('IntersectionObserver' in window)) {
      targets.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    targets.forEach(function (el, i) {
      el.style.transitionDelay = Math.min(i * 40, 240) + 'ms';
      observer.observe(el);
    });
  }

  /* ---------------------------------------------------------------
   * 6. Nút "lên đầu trang"
   * ------------------------------------------------------------- */
  function initBackToTop() {
    var btn = document.getElementById('backToTop');
    if (!btn) return;

    var onScroll = function () {
      btn.hidden = window.scrollY < 420;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------------------------------------------------------------
   * 7. Thanh tiến trình + fade-out mượt khi chuyển trang
   * ------------------------------------------------------------- */
  function initPageTransitions() {
    var progress = document.getElementById('pageProgress');

    function isSameOriginLink(link) {
      try {
        var url = new URL(link.href, window.location.href);
        return url.origin === window.location.origin;
      } catch (e) {
        return false;
      }
    }

    document.addEventListener('click', function (e) {
      var link = e.target.closest ? e.target.closest('a[href]') : null;
      if (!link) return;
      if (e.defaultPrevented || e.button !== 0) return;
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (link.target === '_blank' || link.hasAttribute('download')) return;
      if (!isSameOriginLink(link)) return;

      var url = new URL(link.href, window.location.href);
      if (url.pathname === window.location.pathname && url.search === window.location.search) {
        return;
      }

      e.preventDefault();
      if (progress) progress.classList.add('is-active');
      body.classList.add('is-leaving');

      window.setTimeout(function () {
        window.location.href = link.href;
      }, 160);
    });

    window.addEventListener('pageshow', function () {
      body.classList.remove('is-leaving');
      body.classList.remove('is-loading');
      if (progress) progress.classList.remove('is-active');
    });
  }

  /* ---------------------------------------------------------------
   * 8. Form tìm kiếm: ngăn submit rỗng
   * ------------------------------------------------------------- */
  function initSearchForms() {
    var forms = document.querySelectorAll('.search-form');
    for (var i = 0; i < forms.length; i++) {
      forms[i].addEventListener('submit', function (e) {
        var input = this.querySelector('input[name="q"]');
        if (input && input.value.trim() === '') {
          e.preventDefault();
          input.focus();
        }
      });
    }
  }

  function init() {
    initTheme();
    initNavToggle();
    initSearchShortcut();
    initLiveFilter();
    initScrollReveal();
    initBackToTop();
    initPageTransitions();
    initSearchForms();

    requestAnimationFrame(function () {
      body.classList.remove('is-loading');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
