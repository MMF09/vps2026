<?php
/**
 * Dữ liệu mô tả các nhóm chủ đề an ninh mạng.
 * CHỈ là nội dung tổng quan / giáo dục — không chứa mã khai thác (exploit/PoC).
 * Tương thích PHP 5.6+ (chỉ dùng mảng thuần, không dùng cú pháp mới).
 */

return array(
    'iot' => array(
        'title'   => 'Thiết bị IoT & Di động',
        'icon'    => '📡',
        'summary' => 'Tổng quan về các lớp lỗ hổng thường gặp trên thiết bị phần cứng kết nối mạng.',
        'items'   => array(
            array(
                'name' => 'Router gia đình / doanh nghiệp',
                'desc' => 'Các lỗi cấu hình mặc định, giao diện quản trị lộ ra ngoài Internet, hoặc lỗi xử lý tham số đầu vào trên firmware.',
            ),
            array(
                'name' => 'Camera an ninh (IP Camera / NVR)',
                'desc' => 'Các vấn đề thường gặp: tài khoản mặc định không đổi, giao thức truyền hình ảnh không mã hóa, cơ chế xác thực yếu.',
            ),
            array(
                'name' => 'Thiết bị di động (Android/iOS)',
                'desc' => 'Các nguyên tắc chung về mô hình quyền hạn ứng dụng, sandbox, và tầm quan trọng của việc cập nhật bản vá hệ điều hành.',
            ),
        ),
    ),
    'web' => array(
        'title'   => 'Ứng dụng Web & CMS',
        'icon'    => '🌐',
        'summary' => 'Các lớp lỗ hổng phổ biến trong ứng dụng web và hệ quản trị nội dung (CMS).',
        'items'   => array(
            array(
                'name' => 'SQL Injection (SQLi)',
                'desc' => 'Xảy ra khi dữ liệu đầu vào của người dùng được đưa trực tiếp vào câu truy vấn SQL mà không qua kiểm tra/tham số hóa.',
            ),
            array(
                'name' => 'Cross-Site Scripting (XSS)',
                'desc' => 'Xảy ra khi dữ liệu đầu vào không được mã hóa/escape đúng cách trước khi hiển thị lại trên trang web.',
            ),
            array(
                'name' => 'File Upload không an toàn',
                'desc' => 'Thiếu kiểm tra loại file, phần mở rộng hoặc nội dung file khi cho phép người dùng tải lên.',
            ),
            array(
                'name' => 'Deserialization không an toàn',
                'desc' => 'Xử lý dữ liệu tuần tự hóa (serialized data) từ nguồn không tin cậy mà không kiểm soát chặt chẽ.',
            ),
        ),
    ),
    'oa' => array(
        'title'   => 'Hệ thống OA / Quản trị Doanh nghiệp',
        'icon'    => '🏢',
        'summary' => 'Nguyên tắc bảo mật chung khi triển khai phần mềm văn phòng điện tử nội bộ.',
        'items'   => array(
            array(
                'name' => 'Kiểm soát truy cập (Access Control)',
                'desc' => 'Tầm quan trọng của việc phân quyền đúng vai trò (RBAC) và không để lộ các endpoint quản trị ra Internet công cộng.',
            ),
            array(
                'name' => 'Quản lý phiên đăng nhập',
                'desc' => 'Thiết lập session timeout hợp lý, luân chuyển token, chống đánh cắp phiên.',
            ),
        ),
    ),
    'postex' => array(
        'title'   => 'Nâng quyền & Hậu kiểm tra',
        'icon'    => '🛡️',
        'summary' => 'Khái niệm phòng thủ theo chiều sâu nhằm hạn chế thiệt hại sau khi một lớp bảo vệ bị vượt qua.',
        'items'   => array(
            array(
                'name' => 'Nguyên tắc đặc quyền tối thiểu',
                'desc' => 'Mỗi tài khoản dịch vụ chỉ nên có đúng quyền cần thiết để hoạt động.',
            ),
            array(
                'name' => 'Giám sát & ghi log',
                'desc' => 'Thu thập log tập trung giúp phát hiện sớm hành vi bất thường trong hệ thống.',
            ),
        ),
    ),
    'docs' => array(
        'title'   => 'Tài liệu & Thực hành tốt',
        'icon'    => '📚',
        'summary' => 'Khuyến nghị quy trình kiểm thử an toàn và hợp pháp.',
        'items'   => array(
            array(
                'name' => 'Phạm vi kiểm thử (Scope)',
                'desc' => 'Chỉ thực hiện kiểm thử trên hệ thống mình sở hữu hoặc đã được cấp phép bằng văn bản.',
            ),
            array(
                'name' => 'Môi trường cô lập',
                'desc' => 'Luôn thử nghiệm công cụ/kịch bản chưa rõ nguồn gốc trong máy ảo cách ly, không kết nối mạng thật.',
            ),
        ),
    ),
);
