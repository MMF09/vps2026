<?php
/**
 * config.php
 * Cấu hình chung + các hàm tiện ích.
 * Viết bằng PHP thuần, tránh cú pháp mới (arrow fn, union types, match...)
 * để chạy ổn định trên nhiều phiên bản PHP (kể cả host dùng PHP 5.6 - 7.x).
 */

// Tránh cảnh báo "It is not safe to rely on the system's timezone settings"
// (một trong những nguyên nhân phổ biến khiến trang hiển thị lỗi/chữ cảnh báo
// chèn trước nội dung HTML trên một số host chưa cấu hình date.timezone).
if (!ini_get('date.timezone')) {
    date_default_timezone_set('Asia/Ho_Chi_Minh');
}

define('SITE_NAME', 'SecKnowledge Portal');
define('SITE_TAGLINE', 'Cổng thông tin tổng quan về các nhóm lỗ hổng an ninh mạng (chỉ mang tính giáo dục)');
define('BASE_PATH', dirname(__DIR__));

/**
 * Tính đường dẫn gốc (base URL) của website dựa trên nơi file đang chạy.
 * Giúp site chạy đúng dù đặt ở domain gốc (http://domain.com/)
 * hay trong thư mục con (http://domain.com/secportal/).
 * Luôn trả về chuỗi KHÔNG có dấu "/" ở cuối (có thể là chuỗi rỗng).
 */
function base_url()
{
    $scriptName = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';
    $dir = str_replace('\\', '/', dirname($scriptName));
    $dir = rtrim($dir, '/');
    if ($dir === '.' || $dir === '/') {
        $dir = '';
    }
    return $dir;
}

/**
 * Tạo đường dẫn đầy đủ (tính theo base_url) tới 1 trang hoặc file asset.
 * Dùng thay cho việc viết cứng "/index.php" hay "/assets/..." trong code.
 */
function url($path)
{
    $path = ltrim($path, '/');
    $base = base_url();
    if ($base === '') {
        return '/' . $path;
    }
    return $base . '/' . $path;
}

/**
 * Nạp dữ liệu danh mục (chỉ nạp 1 lần / request).
 */
function load_categories()
{
    static $cache = null;
    if ($cache === null) {
        $cache = require BASE_PATH . '/data/categories.php';
    }
    return $cache;
}

/**
 * Escape an toàn khi in dữ liệu ra HTML.
 */
function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* ---------------------------------------------------------------------
 * Polyfill cho mbstring / iconv, phòng trường hợp extension chưa bật
 * trên môi trường hosting. Nếu có sẵn hàm gốc thì dùng hàm gốc
 * (xử lý tiếng Việt chính xác hơn khi tìm kiếm không phân biệt hoa/thường).
 * ------------------------------------------------------------------- */
if (!function_exists('mb_stripos')) {
    function mb_stripos($haystack, $needle)
    {
        return stripos($haystack, $needle);
    }
}
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($value)
    {
        return strtolower($value);
    }
}

/**
 * Chuyển chuỗi (có dấu tiếng Việt) thành slug an toàn dùng cho id/anchor.
 */
function slugify($text)
{
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if ($converted !== false && $converted !== '') {
            $text = $converted;
        }
    }
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    if ($text === null) {
        $text = '';
    }
    return trim($text, '-');
}

/**
 * Tìm kiếm (phía server) trên toàn bộ categories/items theo từ khóa.
 * Trả về mảng kết quả phẳng để hiển thị trên trang search.php
 */
function search_categories($categories, $query)
{
    $query = trim((string)$query);
    $results = array();

    if ($query === '') {
        return $results;
    }

    foreach ($categories as $slug => $cat) {
        $catMatches = (mb_stripos($cat['title'], $query) !== false)
            || (mb_stripos($cat['summary'], $query) !== false);

        if ($catMatches) {
            $results[] = array(
                'type'      => 'category',
                'slug'      => $slug,
                'cat_title' => $cat['title'],
                'icon'      => $cat['icon'],
                'name'      => $cat['title'],
                'text'      => $cat['summary'],
                'anchor'    => '',
            );
        }

        foreach ($cat['items'] as $item) {
            $itemMatches = (mb_stripos($item['name'], $query) !== false)
                || (mb_stripos($item['desc'], $query) !== false);

            if ($itemMatches) {
                $results[] = array(
                    'type'      => 'item',
                    'slug'      => $slug,
                    'cat_title' => $cat['title'],
                    'icon'      => $cat['icon'],
                    'name'      => $item['name'],
                    'text'      => $item['desc'],
                    'anchor'    => slugify($item['name']),
                );
            }
        }
    }

    return $results;
}

/**
 * Danh sách các mục cho thanh điều hướng chính.
 */
function nav_links()
{
    return array(
        array('href' => url('index.php'), 'label' => 'Trang chủ'),
        array('href' => url('search.php'), 'label' => 'Tìm kiếm'),
    );
}

/**
 * Đường dẫn hiện tại (không kèm query string) — dùng để tô sáng menu active.
 */
function current_path()
{
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    $path = parse_url($uri, PHP_URL_PATH);
    return $path ? $path : '/';
}
