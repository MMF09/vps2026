<?php
/** @var string $pageTitle */
if (!isset($pageTitle)) {
    $pageTitle = SITE_NAME;
}
$currentPath = current_path();
$q = isset($_GET['q']) ? (string)$_GET['q'] : '';
?>
<!DOCTYPE html>
<html lang="vi" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark light">
<title><?php echo h($pageTitle); ?></title>
<meta name="description" content="<?php echo h(SITE_TAGLINE); ?>">
<link rel="icon" type="image/x-icon" href="<?php echo h(url('assets/favicon.ico')); ?>">
<link rel="icon" type="image/svg+xml" href="<?php echo h(url('assets/favicon.svg')); ?>">
<link rel="stylesheet" href="<?php echo h(url('assets/style.css')); ?>">
<script>
  /* Set theme trước khi render để tránh "nháy" màu (FOUC) */
  (function () {
    try {
      var saved = localStorage.getItem('secportal-theme');
      if (saved === 'light' || saved === 'dark') {
        document.documentElement.setAttribute('data-theme', saved);
      }
    } catch (e) {}
  })();
</script>
</head>
<body class="is-loading">
<a class="skip-link" href="#main-content">Bỏ qua đến nội dung chính</a>

<header class="site-header">
    <div class="header-row">
        <a class="brand" href="<?php echo h(url('index.php')); ?>">
            <img src="<?php echo h(url('assets/favicon.svg')); ?>" alt="" class="brand-icon" width="32" height="32">
            <span><?php echo h(SITE_NAME); ?></span>
        </a>

        <button class="nav-toggle" id="navToggle" type="button" aria-expanded="false" aria-controls="siteNav" aria-label="Mở menu điều hướng">
            <span></span><span></span><span></span>
        </button>

        <nav class="site-nav" id="siteNav">
            <ul>
                <?php foreach (nav_links() as $link) { ?>
                    <li>
                        <a href="<?php echo h($link['href']); ?>"
                           class="<?php echo ($currentPath === $link['href']) ? 'active' : ''; ?>">
                            <?php echo h($link['label']); ?>
                        </a>
                    </li>
                <?php } ?>
            </ul>

            <form class="search-form" action="<?php echo h(url('search.php')); ?>" method="get" role="search">
                <label class="sr-only" for="navSearch">Tìm kiếm</label>
                <input
                    type="search"
                    id="navSearch"
                    name="q"
                    placeholder="Tìm kiếm chủ đề... (/)"
                    autocomplete="off"
                    value="<?php echo h($q); ?>"
                >
                <button type="submit" aria-label="Tìm kiếm">🔍</button>
            </form>

            <button class="theme-toggle" id="themeToggle" type="button" aria-label="Chuyển chế độ sáng/tối">
                <span class="icon-dark">🌙</span>
                <span class="icon-light">☀️</span>
            </button>
        </nav>
    </div>

    <p class="tagline"><?php echo h(SITE_TAGLINE); ?></p>
</header>

<div class="page-progress" id="pageProgress" aria-hidden="true"></div>

<main class="container" id="main-content">
