</main>

<button id="backToTop" class="back-to-top" type="button" aria-label="Lên đầu trang" hidden>
    ↑
</button>

<footer class="site-footer">
    <p>
        Nội dung trên trang này chỉ mang tính tổng quan / giáo dục về các <strong>nhóm</strong> lỗ hổng bảo mật.
        Trang không chứa mã khai thác (exploit/PoC). Chỉ thực hiện kiểm thử bảo mật trên hệ thống bạn sở hữu
        hoặc đã được cấp phép hợp pháp.
    </p>
    <p>&copy; <?php echo date('Y'); ?> <?php echo h(SITE_NAME); ?></p>
</footer>

<script src="<?php echo h(url('assets/app.js')); ?>" defer></script>
</body>
</html>
