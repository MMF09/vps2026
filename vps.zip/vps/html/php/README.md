# SecKnowledge Portal (PHP thuần)

Website PHP portal mô tả tổng quan các NHÓM chủ đề an ninh mạng (IoT, Web/CMS,
OA, Post-Exploitation, Tài liệu). CHỈ mang tính mô tả / giáo dục — không chứa
mã khai thác (exploit/PoC).

## Vì sao bản này fix được lỗi "load trang"?

Hai nguyên nhân phổ biến nhất gây lỗi khi mang code PHP lên host thật:

1. **Đường dẫn tuyệt đối cứng (`/assets/...`)** — nếu bạn đặt site trong thư
   mục con (`htdocs/secportal/` chẳng hạn) thay vì thẳng gốc domain, trình
   duyệt sẽ tìm sai chỗ, mất hết CSS/JS/favicon → trang "vỡ".
   **Đã fix**: toàn bộ link/asset giờ đi qua hàm `url()` trong
   `includes/config.php`, tự tính đường dẫn gốc dựa theo nơi file đang chạy,
   chạy đúng dù đặt ở gốc domain hay thư mục con bất kỳ.

2. **Cú pháp PHP quá mới** (arrow function, union return type...) — chỉ chạy
   được PHP 8.0+, trong khi nhiều hosting giá rẻ vẫn chạy PHP 7.x → lỗi
   **fatal ngay khi load trang**.
   **Đã fix**: viết lại toàn bộ bằng cú pháp PHP cổ điển (`array()`, `function`,
   không dùng `fn()`, không dùng union type), tương thích từ PHP 5.6 trở lên.

Ngoài ra còn chủ động:
- Tự set `date.timezone` nếu host chưa cấu hình (tránh warning chèn vào đầu trang).
- Có polyfill cho `mb_stripos`/`mb_strtolower` nếu thiếu extension `mbstring`.
- `slugify()` tự kiểm tra `iconv` có tồn tại trước khi dùng.

**Lưu ý quan trọng**: phải chạy qua một PHP server (built-in server, XAMPP,
Nginx/Apache + PHP-FPM...), KHÔNG mở trực tiếp file `.php` bằng cách double-click
(giao thức `file://`) — trình duyệt sẽ hiển thị mã nguồn thô thay vì chạy nó,
vì chỉ máy chủ có cài PHP mới thông dịch được file `.php`.

## Chạy thử nhanh

```bash
php -S localhost:8000
```
Mở: http://localhost:8000/index.php

## Cấu trúc

```
secportal/
├── index.php             # Trang chủ, liệt kê danh mục + lọc nhanh
├── category.php          # Chi tiết 1 danh mục (?slug=...), sidebar + anchor
├── search.php            # Tìm kiếm toàn site (server-side)
├── includes/
│   ├── config.php        # Hằng số, helper: url(), slugify(), search_categories()
│   ├── header.php
│   └── footer.php
├── data/
│   └── categories.php    # Dữ liệu mô tả danh mục (mảng PHP, dễ mở rộng)
└── assets/
    ├── style.css
    ├── app.js
    ├── favicon.svg
    └── favicon.ico
```

## Mở rộng

Thêm danh mục/chủ đề mới: sửa `data/categories.php`, không cần đụng logic hiển thị.
