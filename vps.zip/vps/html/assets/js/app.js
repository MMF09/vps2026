const BASE_URL = 'uploads/';
const state = { dir: '' };

function $(sel) { return document.querySelector(sel); }
function $all(sel) { return document.querySelectorAll(sel); }

function humanSize(bytes) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (bytes >= 1024 && i < 3) { bytes /= 1024; i++; }
  return bytes.toFixed(1) + ' ' + units[i];
}

/* ---------------------------------------------------------
 * PHÂN LUỒNG THÔNG BÁO LỖI (client-side routing)
 * info      -> chỉ log ra console, không làm phiền người dùng
 * warning   -> hiện toast màu vàng
 * error     -> hiện toast màu đỏ
 * critical  -> hiện toast đỏ đậm + chặn bằng alert() để đảm bảo người dùng thấy
 * --------------------------------------------------------- */
function showToast(level, message) {
  const container = $('#toast-container');
  const el = document.createElement('div');
  el.className = 'toast toast-' + level;
  const icons = { info: 'ℹ️', warning: '⚠️', error: '❌', critical: '🚨' };
  el.innerHTML = `<span>${icons[level] || ''}</span><span>${message}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, 5000);
}

function routeNotification(n) {
  switch (n.level) {
    case 'info':
      console.log('[INFO]', n.message);
      break;
    case 'warning':
    case 'error':
      showToast(n.level, n.message);
      break;
    case 'critical':
      showToast('critical', n.message);
      alert('🚨 LỖI NGHIÊM TRỌNG:\n' + n.message);
      break;
    default:
      showToast('info', n.message);
  }
}

async function pollNotifications() {
  try {
    const res = await fetch('api/notifications.php');
    const data = await res.json();
    (data.notifications || []).forEach(routeNotification);
  } catch (e) {
    // im lặng để tránh vòng lặp lỗi vô hạn khi mất kết nối
  }
}
setInterval(pollNotifications, 4000);

/** Wrapper gọi API: tự động phân luồng lỗi trả về từ server */
async function apiCall(url, options = {}) {
  try {
    const res = await fetch(url, options);
    const data = await res.json();
    if (!data.success) {
      routeNotification({ level: data.level || 'error', message: data.message || 'Lỗi không xác định' });
      return null;
    }
    return data;
  } catch (e) {
    routeNotification({ level: 'critical', message: 'Không thể kết nối máy chủ: ' + e.message });
    return null;
  }
}

function renderBreadcrumb() {
  const parts = state.dir.split('/').filter(Boolean);
  let html = `<a href="#" data-dir="">🏠 Gốc</a>`;
  let acc = '';
  for (const p of parts) {
    acc += (acc ? '/' : '') + p;
    html += ` / <a href="#" data-dir="${acc}">${p}</a>`;
  }
  $('#breadcrumb').innerHTML = html;
  $all('#breadcrumb a').forEach(a => {
    a.onclick = (e) => { e.preventDefault(); state.dir = a.dataset.dir; loadFiles(); };
  });
}

async function loadFiles() {
  const data = await apiCall('api/list.php?dir=' + encodeURIComponent(state.dir));
  if (!data) return;
  renderBreadcrumb();

  const tbody = $('#file-table tbody');
  tbody.innerHTML = '';

  if (data.items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty">Thư mục trống</td></tr>';
    return;
  }

  for (const item of data.items) {
    const tr = document.createElement('tr');
    const icon = item.is_dir ? '📁' : '📄';
    const nameCell = item.is_dir
      ? `<a href="#" class="dir-link" data-name="${item.name}">${item.name}</a>`
      : item.name;
    const filePath = BASE_URL + (state.dir ? state.dir + '/' : '') + encodeURIComponent(item.name);

    tr.innerHTML = `
      <td>${icon}</td>
      <td>${nameCell}</td>
      <td>${item.is_dir ? '-' : humanSize(item.size)}</td>
      <td>${item.modified}</td>
      <td>
        ${!item.is_dir ? `<a href="${filePath}" download class="btn-mini" title="Tải xuống">⬇</a>` : ''}
        <button class="btn-mini" data-action="rename" data-name="${item.name}" title="Đổi tên">✏️</button>
        <button class="btn-mini danger" data-action="delete" data-name="${item.name}" title="Xóa">🗑️</button>
      </td>`;
    tbody.appendChild(tr);
  }

  $all('.dir-link').forEach(a => {
    a.onclick = (e) => {
      e.preventDefault();
      state.dir = (state.dir ? state.dir + '/' : '') + a.dataset.name;
      loadFiles();
    };
  });
  $all('[data-action="delete"]').forEach(btn => btn.onclick = () => deleteEntry(btn.dataset.name));
  $all('[data-action="rename"]').forEach(btn => btn.onclick = () => renameEntry(btn.dataset.name));
}

async function deleteEntry(name) {
  if (!confirm(`Xóa "${name}"? Hành động này không thể hoàn tác.`)) return;
  const data = await apiCall('api/delete.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dir: state.dir, name }),
  });
  if (data) { showToast('info', data.message); loadFiles(); }
}

async function renameEntry(oldName) {
  const newName = prompt('Tên mới:', oldName);
  if (!newName || newName === oldName) return;
  const data = await apiCall('api/rename.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dir: state.dir, old_name: oldName, new_name: newName }),
  });
  if (data) { showToast('info', data.message); loadFiles(); }
}

$('#upload-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fileInput = $('#file-input');
  if (!fileInput.files.length) return;
  const fd = new FormData();
  fd.append('file', fileInput.files[0]);
  fd.append('dir', state.dir);
  const data = await apiCall('api/upload.php', { method: 'POST', body: fd });
  if (data) { showToast('info', data.message); fileInput.value = ''; loadFiles(); }
});

$('#btn-mkdir').onclick = async () => {
  const name = prompt('Tên thư mục mới:');
  if (!name) return;
  const data = await apiCall('api/mkdir.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dir: state.dir, name }),
  });
  if (data) { showToast('info', data.message); loadFiles(); }
};

$('#btn-refresh').onclick = loadFiles;

// Khởi động
loadFiles();
