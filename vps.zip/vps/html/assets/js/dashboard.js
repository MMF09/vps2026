let charts = {};

function $(sel) { return document.querySelector(sel); }
function $all(sel) { return document.querySelectorAll(sel); }

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

/* ---------------------------------------------------------
 * PHÂN LUỒNG THÔNG BÁO LỖI
 * --------------------------------------------------------- */
function showToast(level, message) {
  const container = $('#toast-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'toast toast-' + level;
  const icons = { info: 'ℹ️', warning: '⚠️', error: '❌', critical: '🚨' };
  el.innerHTML = `<span>${icons[level] || ''}</span><span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, 5000);
}

function routeNotification(n) {
  switch (n.level) {
    case 'info':
      console.log('[INFO]', n.message);
      break;
    case 'warning':
    case 'error':
      showToast(n.level, n.message);
      break;
    case 'critical':
      showToast('critical', n.message);
      alert('🚨 LỖI NGHIÊM TRỌNG:\n' + n.message);
      break;
    default:
      showToast('info', n.message);
  }
}

async function pollNotifications() {
  try {
    const res = await fetch('api/notifications.php');
    const data = await res.json();
    (data.notifications || []).forEach(routeNotification);
  } catch (e) { /* im lặng */ }
}
setInterval(pollNotifications, 4000);

async function apiCall(url, options = {}) {
  try {
    const res = await fetch(url, options);
    const data = await res.json();
    if (!data.success) {
      routeNotification({ level: data.level || 'error', message: data.message || 'Lỗi không xác định' });
      return null;
    }
    return data;
  } catch (e) {
    routeNotification({ level: 'critical', message: 'Không thể kết nối máy chủ: ' + e.message });
    return null;
  }
}

/* =========================================================
 * DANH SÁCH FILE ĐÃ QUÉT TỪ SERVER
 * ========================================================= */

function renderFileList(files) {
  const tbody = $('#file-table tbody');
  if (!tbody) return;

  if (!files || files.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty">Không tìm thấy file nào</td></tr>';
    return;
  }

  tbody.innerHTML = files.map(f => `
    <tr>
      <td>📄</td>
      <td>${escapeHtml(f.name)}</td>
      <td>${escapeHtml(f.extension || '—')}</td>
      <td>${escapeHtml(f.size_human)}</td>
      <td>${escapeHtml(f.modified || '')}</td>
    </tr>
  `).join('');

  const label = $('#file-count-label');
  if (label) {
    label.textContent = files.length + ' file';
  }
}

/* =========================================================
 * PHÂN TÍCH + BIỂU ĐỒ
 * ========================================================= */

function renderStats(d) {
  const el = $('#stats-grid');
  if (!el) return;
  el.innerHTML = `
    <div class="stat-card"><div class="stat-value">${d.total_files}</div><div class="stat-label">Tổng số file</div></div>
    <div class="stat-card"><div class="stat-value">${escapeHtml(d.total_size_human)}</div><div class="stat-label">Tổng dung lượng</div></div>
    <div class="stat-card"><div class="stat-value">${Object.keys(d.by_extension || {}).length}</div><div class="stat-label">Loại định dạng</div></div>
  `;
}

function renderCharts(d) {
  Object.values(charts).forEach(c => {
    if (c && typeof c.destroy === 'function') c.destroy();
  });
  charts = {};

  const extLabels = Object.keys(d.by_extension || {});
  const extData = Object.values(d.by_extension || {});

  const canvasExt = $('#chart-ext');
  if (canvasExt) {
    charts.ext = new Chart(canvasExt, {
      type: 'pie',
      data: {
        labels: extLabels.length ? extLabels : ['(trống)'],
        datasets: [{
          data: extData.length ? extData : [1],
          backgroundColor: [
            '#4f8cff', '#7c5cff', '#00c9a7', '#ffb020', '#ff5c5c',
            '#36cfc9', '#9254de', '#ff85c0', '#73d13d', '#ffa940'
          ],
        }],
      },
      options: {
        plugins: {
          title: { display: true, text: 'Phân bố theo định dạng file' },
          legend: { position: 'bottom' },
        },
      },
    });
  }

  const canvasSize = $('#chart-size');
  if (canvasSize) {
    charts.size = new Chart(canvasSize, {
      type: 'bar',
      data: {
        labels: Object.keys(d.by_size_range || {}),
        datasets: [{
          label: 'Số file',
          data: Object.values(d.by_size_range || {}),
          backgroundColor: '#4f8cff',
          borderRadius: 6,
        }],
      },
      options: {
        plugins: { title: { display: true, text: 'Phân bố theo kích thước' } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } },
      },
    });
  }

  const canvasMonth = $('#chart-month');
  if (canvasMonth) {
    charts.month = new Chart(canvasMonth, {
      type: 'line',
      data: {
        labels: Object.keys(d.by_month || {}),
        datasets: [{
          label: 'Số file theo tháng sửa đổi',
          data: Object.values(d.by_month || {}),
          borderColor: '#7c5cff',
          backgroundColor: 'rgba(124,92,255,0.15)',
          tension: 0.3,
          fill: true,
          pointRadius: 4,
        }],
      },
      options: {
        plugins: { title: { display: true, text: 'Xu hướng theo tháng (dựa trên ngày sửa đổi)' } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } },
      },
    });
  }
}

function renderLargest(list) {
  const tbody = $('#largest-table tbody');
  if (!tbody) return;
  if (!list || list.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" class="empty">Không có dữ liệu</td></tr>';
    return;
  }
  tbody.innerHTML = list.map(f => `
    <tr>
      <td>${escapeHtml(f.name)}</td>
      <td>${escapeHtml(f.size_human)}</td>
      <td>${escapeHtml(f.modified || '')}</td>
    </tr>
  `).join('');
}

function applyAnalysis(d) {
  if (!d) return;
  renderStats(d);
  renderCharts(d);
  renderLargest(d.largest_files || []);
  renderFileList(d.all_files || []);
  const updated = $('#last-updated');
  if (updated) {
    updated.textContent = 'Cập nhật lúc ' + new Date().toLocaleTimeString('vi-VN');
  }
  const label = $('#file-count-label');
  if (label && d.total_files != null) {
    label.textContent = d.total_files + ' file · ' + (d.total_size_human || '');
  }
}

/** Quét lại / làm mới từ API (SCAN_DIR trên server) */
async function loadDashboard() {
  const data = await apiCall('api/analyze.php');
  if (!data) return;
  applyAnalysis(data.data);
  showToast('info', 'Đã quét lại thư mục server: ' + (data.data.total_files || 0) + ' file');
}

const btnRefresh = $('#btn-refresh');
if (btnRefresh) btnRefresh.onclick = loadDashboard;

const btnRefreshDash = $('#btn-refresh-dash');
if (btnRefreshDash) btnRefreshDash.onclick = loadDashboard;

/* =========================================================
 * NHẬT KÝ HOẠT ĐỘNG
 * ========================================================= */

const levelMeta = {
  info:     { icon: 'ℹ️', label: 'Thông tin' },
  warning:  { icon: '⚠️', label: 'Cảnh báo' },
  error:    { icon: '❌', label: 'Lỗi' },
  critical: { icon: '🚨', label: 'Nghiêm trọng' },
};

function renderActivityCounts(counts) {
  const el = $('#activity-counts');
  if (!el) return;
  el.innerHTML = Object.entries(counts || {}).map(([level, n]) => `
    <div class="stat-card stat-${level}">
      <div class="stat-value">${n}</div>
      <div class="stat-label">${levelMeta[level]?.icon || ''} ${levelMeta[level]?.label || level}</div>
    </div>
  `).join('');
}

function renderActivityFeed(entries) {
  const el = $('#activity-feed');
  if (!el) return;
  if (!entries || !entries.length) {
    el.innerHTML = '<div class="empty">Chưa có sự kiện nào được ghi nhận</div>';
    return;
  }
  el.innerHTML = entries.map(e => `
    <div class="activity-item activity-${e.level}">
      <span class="activity-icon">${levelMeta[e.level]?.icon || 'ℹ️'}</span>
      <div class="activity-body">
        <div class="activity-message">${escapeHtml(e.message)}</div>
        <div class="activity-time">${escapeHtml(e.time)}</div>
      </div>
      <span class="activity-badge badge-${e.level}">${levelMeta[e.level]?.label || e.level}</span>
    </div>
  `).join('');
}

async function loadActivity() {
  const data = await apiCall('api/activity.php?limit=30');
  if (!data) return;
  renderActivityCounts(data.counts);
  renderActivityFeed(data.entries);
}

setInterval(loadActivity, 10000);

/* =========================================================
 * KHỞI ĐỘNG: dùng dữ liệu PHP đã quét sẵn trên server
 * ========================================================= */
if (window.INITIAL_ANALYSIS) {
  applyAnalysis(window.INITIAL_ANALYSIS);
} else {
  loadDashboard();
}
loadActivity();
