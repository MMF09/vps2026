(() => {
  'use strict';

  // ========== DOM refs ==========
  const $ = (id) => document.getElementById(id);

  const dashboard      = $('dashboard');
  const viewer         = $('viewer');
  const viewerFrame    = $('viewerFrame');
  const filePreview    = $('filePreview');
  const viewerLoading  = $('viewerLoading');
  const btnBack        = $('btnBack');
  const btnClose       = $('btnClose');
  const btnOpenNew     = $('btnOpenNew');
  const crumbHome      = $('crumbHome');
  const crumbCurrent   = $('crumbCurrent');

  const gridWithIndex  = $('gridWithIndex');
  const gridWithoutIndex = $('gridWithoutIndex');
  const fileList       = $('fileList');
  const emptyState     = $('emptyState');
  const searchInput    = $('search');
  const refreshBtn     = $('refreshBtn');

  const countWithIndex    = $('countWithIndex');
  const countWithoutIndex = $('countWithoutIndex');
  const countFiles        = $('countFiles');

  // ========== State ==========
  let data = {
    folders_with_index: [],
    folders_without_index: [],
    files: []
  };

  // ========== Load data ==========
  async function loadData() {
    gridWithIndex.innerHTML = Array(4).fill('<div class="skeleton"></div>').join('');
    gridWithoutIndex.innerHTML = '';
    fileList.innerHTML = '';
    emptyState.hidden = true;

    try {
      const res = await fetch('scan.php?t=' + Date.now());
      if (!res.ok) throw new Error('Không tải được dữ liệu (HTTP ' + res.status + ')');
      data = await res.json();
      renderAll(data);
    } catch (err) {
      gridWithIndex.innerHTML = '';
      emptyState.hidden = false;
      emptyState.innerHTML = `
        <div class="empty-icon">⚠️</div>
        <p>Lỗi: ${escapeHtml(err.message)}</p>
      `;
    }
  }

  // ========== Render ==========
  function renderAll(source) {
    const keyword = searchInput.value.toLowerCase().trim();

    const withIndex = source.folders_with_index.filter(f =>
      f.name.toLowerCase().includes(keyword) ||
      (f.description || '').toLowerCase().includes(keyword)
    );
    const withoutIndex = source.folders_without_index.filter(f =>
      f.name.toLowerCase().includes(keyword) ||
      (f.description || '').toLowerCase().includes(keyword)
    );
    const files = source.files.filter(f =>
      f.name.toLowerCase().includes(keyword)
    );

    countWithIndex.textContent = withIndex.length;
    countWithoutIndex.textContent = withoutIndex.length;
    countFiles.textContent = files.length;

    // Folders with index
    gridWithIndex.innerHTML = '';
    withIndex.forEach(folder => {
      gridWithIndex.appendChild(createFolderCard(folder, true));
    });

    // Folders without index
    gridWithoutIndex.innerHTML = '';
    withoutIndex.forEach(folder => {
      gridWithoutIndex.appendChild(createFolderCard(folder, false));
    });

    // Files
    fileList.innerHTML = '';
    files.forEach(file => {
      const item = document.createElement('div');
      item.className = 'file-item';
      item.innerHTML = `
        <div class="file-icon">${file.icon}</div>
        <div class="file-info">
          <div class="file-name">${escapeHtml(file.name)}</div>
          <div class="file-meta">${escapeHtml(file.size)} · ${escapeHtml(file.modified)}</div>
        </div>
        <span class="file-action">Xem</span>
      `;
      item.addEventListener('click', () => openFile(file));
      fileList.appendChild(item);
    });

    const total = withIndex.length + withoutIndex.length + files.length;
    emptyState.hidden = total > 0;
    if (total === 0 && !keyword) {
      emptyState.innerHTML = `
        <div class="empty-icon">📂</div>
        <p>Không tìm thấy dữ liệu nào.</p>
      `;
    } else if (total === 0) {
      emptyState.innerHTML = `
        <div class="empty-icon">🔍</div>
        <p>Không có kết quả cho “${escapeHtml(keyword)}”.</p>
      `;
    }
  }

  function createFolderCard(folder, hasIndex) {
    const card = document.createElement('div');
    card.className = 'folder-card ' + (hasIndex ? 'with-index' : 'without-index');
    card.innerHTML = `
      <div class="folder-icon">${folder.icon}</div>
      <div class="folder-name">${escapeHtml(folder.name)}</div>
      <div class="folder-desc">${escapeHtml(folder.description)}</div>
      <div class="folder-meta">
        <span>${folder.items} mục</span>
        <span>${escapeHtml(folder.modified)}</span>
      </div>
    `;
    if (hasIndex) {
      card.addEventListener('click', () => openFolder(folder));
    }
    return card;
  }

  // ========== Viewer helpers ==========
  function setBreadcrumb(label) {
    crumbCurrent.textContent = label;
    crumbCurrent.title = label;
  }

  function showLoading(show) {
    viewerLoading.hidden = !show;
  }

  function showViewer() {
    dashboard.classList.add('hidden');
    viewer.classList.add('open');
    viewer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeViewer() {
    viewer.classList.remove('open');
    dashboard.classList.remove('hidden');
    viewer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';

    // Reset sau animation
    setTimeout(() => {
      viewerFrame.src = 'about:blank';
      viewerFrame.hidden = false;
      filePreview.innerHTML = '';
      filePreview.hidden = true;
      showLoading(false);
    }, 380);
  }

  // ========== Open folder (HTML page) ==========
  function openFolder(folder) {
    const url = folder.path + '/index.html';

    setBreadcrumb(folder.name);
    btnOpenNew.href = url;
    btnOpenNew.hidden = false;

    // Hiện iframe, ẩn preview
    viewerFrame.hidden = false;
    filePreview.hidden = true;
    filePreview.innerHTML = '';

    showLoading(true);
    showViewer();

    // Load iframe
    viewerFrame.onload = () => {
      showLoading(false);
      viewerFrame.onload = null;
    };
    viewerFrame.src = url;

    // Fallback timeout (trường hợp onload không fire)
    setTimeout(() => showLoading(false), 4000);
  }

  // ========== Open file ==========
  function openFile(file) {
    const ext = (file.ext || '').toLowerCase();
    const url = file.path;

    setBreadcrumb(file.name);
    btnOpenNew.href = url;
    btnOpenNew.hidden = false;

    // Ẩn iframe
    viewerFrame.hidden = true;
    viewerFrame.src = 'about:blank';

    // Hiện preview
    filePreview.hidden = false;
    filePreview.innerHTML = '';
    showLoading(true);
    showViewer();

    const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico'];
    const TEXT_EXTS  = ['txt', 'md', 'json', 'csv', 'log', 'js', 'css', 'html', 'php', 'xml', 'yml', 'yaml', 'ini', 'conf'];

    if (IMAGE_EXTS.includes(ext)) {
      const img = document.createElement('img');
      img.src = url;
      img.alt = file.name;
      img.onload = () => showLoading(false);
      img.onerror = () => {
        showLoading(false);
        showNoPreview(file, ext);
      };
      filePreview.appendChild(img);
    }
    else if (ext === 'pdf') {
      const iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.title = file.name;
      iframe.onload = () => showLoading(false);
      filePreview.appendChild(iframe);
      setTimeout(() => showLoading(false), 3000);
    }
    else if (TEXT_EXTS.includes(ext)) {
      fetch(url)
        .then(r => {
          if (!r.ok) throw new Error('Fetch failed');
          return r.text();
        })
        .then(text => {
          const pre = document.createElement('pre');
          pre.textContent = text;
          filePreview.appendChild(pre);
          showLoading(false);
        })
        .catch(() => {
          showLoading(false);
          showNoPreview(file, ext);
        });
    }
    else {
      showLoading(false);
      showNoPreview(file, ext);
    }
  }

  function showNoPreview(file, ext) {
    filePreview.innerHTML = `
      <div class="no-preview">
        <div class="icon">${file.icon || '📄'}</div>
        <p>Không hỗ trợ xem trước định dạng <strong>.${escapeHtml(ext || '?')}</strong></p>
        <a href="${escapeAttr(file.path)}" download>Tải xuống file</a>
      </div>
    `;
  }

  // ========== Utils ==========
  function escapeHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(str) {
    return escapeHtml(str).replace(/'/g, '&#39;');
  }

  // ========== Events ==========
  btnBack.addEventListener('click', closeViewer);
  btnClose.addEventListener('click', closeViewer);
  crumbHome.addEventListener('click', closeViewer);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && viewer.classList.contains('open')) {
      closeViewer();
    }
  });

  searchInput.addEventListener('input', () => renderAll(data));
  refreshBtn.addEventListener('click', loadData);

  // First load
  loadData();
})();
