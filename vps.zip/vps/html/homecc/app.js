// ========== FIREBASE ==========
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getDatabase, ref, onValue, set, update, get } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyCvMzAs3etL30t9-hZa-jVPDTQQorq0ouU",
  authDomain: "ptptt-pcpc.firebaseapp.com",
  databaseURL: "https://ptptt-pcpc-default-rtdb.firebaseio.com",
  projectId: "ptptt-pcpc",
  storageBucket: "ptptt-pcpc.firebasestorage.app",
  messagingSenderId: "334612619008",
  appId: "1:334612619008:web:3a7cf1a73dba9023335de5"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// ========== CONSTANTS ==========
const FLOORS = 6;
const APTS_PER_FLOOR = 4;
const DB_PATH = "locations/building";   // phù hợp với rules: locations.* cần auth

// ========== STATE ==========
let currentUser = null;
let apartmentsData = {};   // { floor: { apartments: { aptId: { ... } } } }
let currentFloor = null;
let selectedAptId = null;
let elevatorFloor = 1;     // vị trí thang máy hiện tại (1-6)
let unsubscribe = null;
let unsubscribeMeta = null;

// ========== DOM ==========
const loginScreen = document.getElementById("login-screen");
const appEl = document.getElementById("app");
const loadingEl = document.getElementById("loading");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const loginBtn = document.getElementById("login-btn");
const userEmailEl = document.getElementById("user-email");
const syncStatus = document.getElementById("sync-status");

// ========== AUTH ==========
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.textContent = "";
  loginBtn.disabled = true;
  loginBtn.textContent = "Đang đăng nhập...";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  try {
    await signInWithEmailAndPassword(auth, email, password);
    // onAuthStateChanged sẽ xử lý tiếp
  } catch (err) {
    console.error(err);
    let msg = "Đăng nhập thất bại.";
    if (err.code === "auth/invalid-credential" || err.code === "auth/wrong-password") {
      msg = "Email hoặc mật khẩu không đúng.";
    } else if (err.code === "auth/user-not-found") {
      msg = "Tài khoản chưa tồn tại trong Firebase Authentication.";
    } else if (err.code === "auth/too-many-requests") {
      msg = "Quá nhiều lần thử. Vui lòng thử lại sau.";
    } else if (err.code === "auth/invalid-email") {
      msg = "Email không hợp lệ.";
    }
    loginError.textContent = msg;
    loginBtn.disabled = false;
    loginBtn.textContent = "Đăng nhập";
  }
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  if (unsubscribe) {
    unsubscribe();
    unsubscribe = null;
  }
  if (unsubscribeMeta) {
    unsubscribeMeta();
    unsubscribeMeta = null;
  }
  await signOut(auth);
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    currentUser = user;
    userEmailEl.textContent = user.email;
    loginScreen.classList.add("hidden");
    appEl.classList.add("visible");
    loadingEl.classList.remove("hidden");
    await initBuildingData();
    startRealtimeListener();
    buildBuildingUI();
    loadingEl.classList.add("hidden");
  } else {
    currentUser = null;
    apartmentsData = {};
    currentFloor = null;
    selectedAptId = null;
    elevatorFloor = 1;
    if (unsubscribe) {
      unsubscribe();
      unsubscribe = null;
    }
    if (unsubscribeMeta) {
      unsubscribeMeta();
      unsubscribeMeta = null;
    }
    loginScreen.classList.remove("hidden");
    appEl.classList.remove("visible");
    loginBtn.disabled = false;
    loginBtn.textContent = "Đăng nhập";
    syncStatus.textContent = "Chưa kết nối";
    syncStatus.classList.remove("live");
  }
});

// ========== DATABASE ==========
function defaultApartment(floor, index) {
  const id = `${floor}0${index}`;
  return {
    id,
    name: `Căn ${id}`,
    occupied: Math.random() > 0.35,
    residents: 0,
    phone: "",
    type: ["Studio", "1 PN", "2 PN", "3 PN"][Math.floor(Math.random() * 4)],
    area: 60 + Math.floor(Math.random() * 50),
    notes: "",
    lightsOn: Math.random() > 0.5
  };
}

async function initBuildingData() {
  const buildingRef = ref(db, DB_PATH);
  const snap = await get(buildingRef);

  if (!snap.exists()) {
    // Khởi tạo dữ liệu mặc định lần đầu
    const data = { floors: {} };
    for (let f = 1; f <= FLOORS; f++) {
      data.floors[f] = { apartments: {} };
      for (let a = 1; a <= APTS_PER_FLOOR; a++) {
        const apt = defaultApartment(f, a);
        if (apt.occupied) apt.residents = Math.floor(Math.random() * 4) + 1;
        data.floors[f].apartments[apt.id] = apt;
      }
    }
    data.meta = {
      name: "Chung cư 6 Tầng",
      totalFloors: FLOORS,
      aptsPerFloor: APTS_PER_FLOOR,
      elevatorFloor: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await set(buildingRef, data);
    apartmentsData = data.floors;
    elevatorFloor = 1;
  } else {
    const val = snap.val();
    apartmentsData = val.floors || {};
    elevatorFloor = val.meta?.elevatorFloor || 1;
  }
  // Áp dụng vị trí thang máy ngay khi load
  applyElevatorPosition(elevatorFloor);
}

function startRealtimeListener() {
  if (unsubscribe) unsubscribe();
  if (unsubscribeMeta) unsubscribeMeta();

  // Lắng nghe dữ liệu tầng + căn hộ
  const floorsRef = ref(db, DB_PATH + "/floors");
  unsubscribe = onValue(floorsRef, (snap) => {
    if (snap.exists()) {
      apartmentsData = snap.val();
      syncStatus.textContent = "● Đồng bộ realtime";
      syncStatus.classList.add("live");
      // Refresh UI nếu đang xem tầng
      if (currentFloor) {
        renderFloor(currentFloor);
        if (selectedAptId) {
          const apt = apartmentsData[currentFloor]?.apartments?.[selectedAptId];
          if (apt) showAptDetail(apt);
        }
      }
      updateGlobalStats();
      updateWindowsFromData();
    }
  }, (err) => {
    console.error("Realtime error:", err);
    syncStatus.textContent = "Lỗi đồng bộ";
    syncStatus.classList.remove("live");
  });

  // Lắng nghe vị trí thang máy (meta) – luôn áp dụng để hỗ trợ load lại liên tục
  const metaRef = ref(db, DB_PATH + "/meta");
  unsubscribeMeta = onValue(metaRef, (snap) => {
    if (snap.exists()) {
      const meta = snap.val();
      if (meta.elevatorFloor != null) {
        const newFloor = Number(meta.elevatorFloor) || 1;
        // Luôn áp dụng (kể cả khi trùng tầng) để animation / reflow chạy lại khi cần
        applyElevatorPosition(newFloor);
      }
    }
  });
}

async function saveApartment(floor, aptId, updates) {
  const path = `${DB_PATH}/floors/${floor}/apartments/${aptId}`;
  updates.updatedAt = Date.now();
  await update(ref(db, path), updates);
  // Cũng cập nhật meta
  await update(ref(db, DB_PATH + "/meta"), { updatedAt: Date.now() });
}

/** Tính vị trí CSS bottom của thang máy theo tầng */
function getElevatorBottom(floor) {
  // Tầng 1 = gần mặt đất, mỗi tầng cao ~70px
  return 25 + (floor - 1) * 70 + 11;
}

/** Áp dụng vị trí thang máy lên giao diện – hỗ trợ gọi liên tục mỗi lần click */
function applyElevatorPosition(floor) {
  const elev = document.getElementById("elevator");
  if (!elev) return;
  const f = Math.max(1, Math.min(FLOORS, Number(floor) || 1));
  const newBottomPx = getElevatorBottom(f);
  const newBottom = newBottomPx + "px";
  const currentBottom = elev.style.bottom || getComputedStyle(elev).bottom;

  // Luôn reset transition rồi force reflow để animation chạy lại mượt mỗi lần (kể cả cùng tầng)
  elev.style.transition = "none";
  // Nếu đang ở đúng vị trí, lệch 1px tạm thời để kích hoạt lại transition
  if (currentBottom === newBottom || parseFloat(currentBottom) === newBottomPx) {
    elev.style.bottom = (newBottomPx + 1) + "px";
  } else {
    // Giữ vị trí hiện tại (không nhảy) trước khi animate
    elev.style.bottom = currentBottom;
  }
  // Force reflow
  void elev.offsetHeight;
  elev.style.transition = "bottom 1.2s cubic-bezier(0.4, 0, 0.2, 1)";
  elev.style.bottom = newBottom;
  elevatorFloor = f;
}

/** Lưu vị trí thang máy lên Firebase và cập nhật UI – hỗ trợ gọi liên tục */
async function moveElevatorTo(floor) {
  const target = Math.max(1, Math.min(FLOORS, Number(floor) || 1));
  // Luôn áp dụng animation ngay (kể cả cùng tầng)
  applyElevatorPosition(target);

  try {
    // Luôn ghi lên Firebase (kể cả trùng tầng) để realtime listener + các client khác cập nhật
    await update(ref(db, DB_PATH + "/meta"), {
      elevatorFloor: target,
      updatedAt: Date.now()
    });
  } catch (err) {
    console.error("Lỗi lưu vị trí thang máy:", err);
  }
}

// ========== UI BUILDING ==========
function buildBuildingUI() {
  const building = document.getElementById("building");
  building.innerHTML = "";

  for (let f = FLOORS; f >= 1; f--) {
    const floorEl = document.createElement("div");
    floorEl.className = "floor";
    floorEl.dataset.floor = f;

    const label = document.createElement("div");
    label.className = "floor-label";
    label.textContent = `Tầng ${f}`;
    floorEl.appendChild(label);

    for (let w = 1; w <= APTS_PER_FLOOR; w++) {
      const aptId = `${f}0${w}`;
      const win = document.createElement("div");
      win.className = "window";
      win.dataset.floor = f;
      win.dataset.apt = aptId;
      const apt = apartmentsData[f]?.apartments?.[aptId];
      if (apt?.lightsOn) win.classList.add("lit");

      win.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!currentUser) return;
        win.classList.toggle("lit");
        const isLit = win.classList.contains("lit");
        try {
          await saveApartment(f, aptId, { lightsOn: isLit });
        } catch (err) {
          console.error(err);
          win.classList.toggle("lit"); // revert
        }
      });
      floorEl.appendChild(win);
    }

    floorEl.addEventListener("click", () => selectFloor(f));
    building.appendChild(floorEl);
  }
}

function updateWindowsFromData() {
  document.querySelectorAll(".window").forEach(win => {
    const f = win.dataset.floor;
    const aptId = win.dataset.apt;
    const apt = apartmentsData[f]?.apartments?.[aptId];
    if (apt) {
      win.classList.toggle("lit", !!apt.lightsOn);
    }
  });
}

function selectFloor(f) {
  currentFloor = f;
  selectedAptId = null;

  document.querySelectorAll(".floor").forEach(el => {
    el.classList.toggle("active", parseInt(el.dataset.floor) === f);
  });

  document.getElementById("welcome").classList.remove("visible");
  document.getElementById("floor-details").classList.add("visible");
  document.getElementById("panel-title").textContent = `Tầng ${f}`;
  document.getElementById("apt-detail").classList.remove("visible");

  renderFloor(f);
}

function renderFloor(f) {
  const grid = document.getElementById("apt-grid");
  grid.innerHTML = "";
  const floorData = apartmentsData[f]?.apartments || {};

  // Sort by apt id
  const sorted = Object.values(floorData).sort((a, b) => a.id.localeCompare(b.id));

  sorted.forEach(apt => {
    const div = document.createElement("div");
    div.className = "apartment" + (selectedAptId === apt.id ? " selected" : "");
    div.innerHTML = `
      <div class="apt-name">${apt.name || apt.id}</div>
      <div class="apt-status ${apt.occupied ? "occupied" : "empty"}">
        ${apt.occupied ? "🟢 Đang ở" : "⚪ Trống"}
      </div>
      <div class="apt-phone">${apt.phone ? "📞 " + apt.phone : "Chưa có SĐT"}</div>
    `;
    div.addEventListener("click", (e) => {
      e.stopPropagation();
      selectedAptId = apt.id;
      document.querySelectorAll(".apartment").forEach(a => a.classList.remove("selected"));
      div.classList.add("selected");
      showAptDetail(apt);
    });
    grid.appendChild(div);
  });

  const occupied = sorted.filter(a => a.occupied).length;
  document.getElementById("floor-stats").innerHTML = `
    <div><span>Căn đang ở:</span> <strong>${occupied}/${APTS_PER_FLOOR}</strong></div>
    <div><span>Tỷ lệ lấp đầy:</span> <strong>${Math.round(occupied / APTS_PER_FLOOR * 100)}%</strong></div>
  `;
}

function showAptDetail(apt) {
  const box = document.getElementById("apt-detail");
  box.classList.add("visible");
  box.innerHTML = `
    <h3>${apt.name || apt.id}</h3>
    <div class="edit-row">
      <label>Số điện thoại</label>
      <input type="tel" id="edit-phone" value="${apt.phone || ""}" placeholder="VD: 0912345678">
    </div>
    <div class="edit-row">
      <label>Trạng thái</label>
      <select id="edit-occupied">
        <option value="true" ${apt.occupied ? "selected" : ""}>Đang có người ở</option>
        <option value="false" ${!apt.occupied ? "selected" : ""}>Trống</option>
      </select>
    </div>
    <div class="edit-row">
      <label>Số người ở</label>
      <input type="number" id="edit-residents" min="0" max="20" value="${apt.residents || 0}">
    </div>
    <div class="edit-row">
      <label>Loại căn</label>
      <select id="edit-type">
        ${["Studio", "1 PN", "2 PN", "3 PN"].map(t =>
          `<option value="${t}" ${apt.type === t ? "selected" : ""}>${t}</option>`
        ).join("")}
      </select>
    </div>
    <div class="edit-row">
      <label>Diện tích (m²)</label>
      <input type="number" id="edit-area" min="20" max="300" value="${apt.area || 70}">
    </div>
    <div class="edit-row">
      <label>Ghi chú</label>
      <textarea id="edit-notes" placeholder="Ghi chú thêm...">${apt.notes || ""}</textarea>
    </div>
    <button class="save-btn" id="save-apt-btn">💾 Lưu vào Firebase</button>
    <div class="save-status" id="save-status"></div>
  `;

  document.getElementById("save-apt-btn").onclick = async () => {
    const statusEl = document.getElementById("save-status");
    statusEl.textContent = "Đang lưu...";
    statusEl.className = "save-status";

    const updates = {
      phone: document.getElementById("edit-phone").value.trim(),
      occupied: document.getElementById("edit-occupied").value === "true",
      residents: parseInt(document.getElementById("edit-residents").value) || 0,
      type: document.getElementById("edit-type").value,
      area: parseInt(document.getElementById("edit-area").value) || 70,
      notes: document.getElementById("edit-notes").value.trim()
    };

    try {
      await saveApartment(currentFloor, apt.id, updates);
      statusEl.textContent = "✓ Đã lưu thành công";
      statusEl.classList.add("ok");
    } catch (err) {
      console.error(err);
      statusEl.textContent = "Lỗi khi lưu: " + (err.message || "unknown");
      statusEl.classList.add("err");
    }
  };
}

function updateGlobalStats() {
  let totalOccupied = 0;
  let totalApts = 0;
  for (let f = 1; f <= FLOORS; f++) {
    const apts = apartmentsData[f]?.apartments || {};
    const list = Object.values(apts);
    totalApts += list.length;
    totalOccupied += list.filter(a => a.occupied).length;
  }
  const el = document.getElementById("global-stats");
  if (el) {
    el.innerHTML = `
      <div><span>Tổng số tầng:</span> <strong>${FLOORS}</strong></div>
      <div><span>Tổng căn hộ:</span> <strong>${totalApts || 24}</strong></div>
      <div><span>Đang có người ở:</span> <strong>${totalOccupied}</strong></div>
      <div><span>Tỷ lệ lấp đầy:</span> <strong>${totalApts ? Math.round(totalOccupied / totalApts * 100) : 0}%</strong></div>
    `;
  }
}

// ========== CONTROLS ==========
document.getElementById("btn-lights").addEventListener("click", async () => {
  if (!currentUser) return;
  const windows = document.querySelectorAll(".window");
  const anyLit = [...windows].some(w => w.classList.contains("lit"));
  const updates = {};
  for (let f = 1; f <= FLOORS; f++) {
    for (let a = 1; a <= APTS_PER_FLOOR; a++) {
      const id = `${f}0${a}`;
      updates[`floors/${f}/apartments/${id}/lightsOn`] = !anyLit;
    }
  }
  try {
    await update(ref(db, DB_PATH), updates);
  } catch (err) {
    console.error(err);
  }
});

document.getElementById("btn-random").addEventListener("click", async () => {
  if (!currentUser) return;
  const updates = {};
  for (let f = 1; f <= FLOORS; f++) {
    for (let a = 1; a <= APTS_PER_FLOOR; a++) {
      const id = `${f}0${a}`;
      updates[`floors/${f}/apartments/${id}/lightsOn`] = Math.random() > 0.5;
    }
  }
  try {
    await update(ref(db, DB_PATH), updates);
  } catch (err) {
    console.error(err);
  }
});

document.getElementById("btn-elevator").addEventListener("click", async () => {
  if (!currentUser) return;

  // 1. Luôn load lại dữ liệu thang máy mới nhất từ Firebase mỗi lần click (hỗ trợ liên tục)
  try {
    const metaSnap = await get(ref(db, DB_PATH + "/meta"));
    if (metaSnap.exists() && metaSnap.val().elevatorFloor != null) {
      const latest = Number(metaSnap.val().elevatorFloor) || 1;
      elevatorFloor = latest;
      // Áp dụng ngay vị trí mới nhất (kể cả trùng tầng vẫn force animation)
      applyElevatorPosition(latest);
    }
  } catch (err) {
    console.error("Không load được vị trí thang máy:", err);
  }

  // 2. Xác định tầng đích
  let target;
  if (currentFloor) {
    // Đang chọn tầng → gọi thang đến tầng đó
    target = currentFloor;
  } else {
    // Chưa chọn tầng → chọn ngẫu nhiên khác vị trí hiện tại
    do {
      target = Math.floor(Math.random() * FLOORS) + 1;
    } while (target === elevatorFloor && FLOORS > 1);
    selectFloor(target);
  }

  // 3. Di chuyển + lưu lên Firebase (kể cả khi trùng tầng vẫn cập nhật updatedAt + animation)
  // Gọi luôn để hỗ trợ click liên tục không bị block
  await moveElevatorTo(target);
});
