// ===== Constants =====
const CLAIM_CONTRACT = '0xd4f0d1c37407dc7f878f3fb42d3558f10e366ab5';
const CLAIM_ABI = ['function claim()']; // selector 0x4e71d92d
const POLYGON_CHAIN_ID = '0x89'; // 137
const MINT_AMOUNT = 21000000; // 21 triệu

const MINT_ABI = [
  'function mint(address to, uint256 amount)',
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)'
];

// ===== State =====
let provider = null;
let signer = null;
let claimContract = null;
let mintContract = null;
let currentDecimals = 18;

// ===== DOM =====
const statusEl = document.getElementById('status');
const connectBtn = document.getElementById('connectBtn');
const walletInfo = document.getElementById('walletInfo');
const userAddressEl = document.getElementById('userAddress');

const claimBtn = document.getElementById('claimBtn');
const claimStatus = document.getElementById('claimStatus');

const tokenAddressInput = document.getElementById('tokenAddress');
const loadContractBtn = document.getElementById('loadContractBtn');
const tokenInfoEl = document.getElementById('tokenInfo');
const toAddressInput = document.getElementById('toAddress');
const mintBtn = document.getElementById('mintBtn');
const mintStatus = document.getElementById('mintStatus');

// ===== Helpers =====
function setStatus(msg, type = 'info') {
  statusEl.className = `status ${type}`;
  statusEl.innerHTML = msg;
}

function shortAddress(addr) {
  return addr.slice(0, 6) + '...' + addr.slice(-4);
}

function setClaimStatus(html) {
  claimStatus.innerHTML = html;
}

function setMintStatus(html) {
  mintStatus.innerHTML = html;
}

// ===== Tabs =====
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('panel-' + tab.dataset.tab).classList.add('active');
  });
});

// ===== Network =====
async function ensurePolygon() {
  const network = await provider.getNetwork();
  if (network.chainId !== 137n) {
    setStatus('Đang chuyển sang Polygon...', 'warning');
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: POLYGON_CHAIN_ID }]
      });
    } catch (e) {
      if (e.code === 4902) {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: POLYGON_CHAIN_ID,
            chainName: 'Polygon Mainnet',
            nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
            rpcUrls: ['https://polygon-rpc.com/'],
            blockExplorerUrls: ['https://polygonscan.com/']
          }]
        });
      } else {
        throw e;
      }
    }
  }
}

// ===== Connect Wallet =====
async function connectWallet() {
  try {
    if (!window.ethereum) {
      setStatus('Vui lòng cài MetaMask hoặc ví Web3 khác', 'error');
      return;
    }

    setStatus('<span class="loader"></span>Đang kết nối...', 'info');
    connectBtn.disabled = true;

    await window.ethereum.request({ method: 'eth_requestAccounts' });
    provider = new ethers.BrowserProvider(window.ethereum);
    signer = await provider.getSigner();

    await ensurePolygon();

    const address = await signer.getAddress();
    claimContract = new ethers.Contract(CLAIM_CONTRACT, CLAIM_ABI, signer);

    userAddressEl.textContent = shortAddress(address);
    walletInfo.classList.remove('hidden');
    connectBtn.classList.add('hidden');
    claimBtn.disabled = false;

    setStatus('✅ Kết nối thành công. Sẵn sàng sử dụng', 'success');

    // Auto-load mint contract if address is present
    if (tokenAddressInput.value.trim()) {
      await loadMintContract();
    }
  } catch (err) {
    console.error(err);
    setStatus(`Lỗi: ${err.message || 'Kết nối thất bại'}`, 'error');
    connectBtn.disabled = false;
  }
}

// ===== Claim =====
async function handleClaim() {
  if (!claimContract) {
    setClaimStatus('Chưa kết nối ví.');
    return;
  }

  try {
    claimBtn.disabled = true;
    setClaimStatus('<span class="loader"></span>Đang gửi giao dịch...');

    const tx = await claimContract.claim();
    setClaimStatus(
      `Đã gửi TX: <a class="tx-link" href="https://polygonscan.com/tx/${tx.hash}" target="_blank" rel="noopener">${tx.hash.slice(0, 10)}...</a>`
    );

    const receipt = await tx.wait();
    if (receipt.status === 1) {
      setClaimStatus(
        `✅ Claim thành công! <a class="tx-link" href="https://polygonscan.com/tx/${tx.hash}" target="_blank" rel="noopener">Xem trên PolygonScan</a>`
      );
      claimBtn.textContent = 'Đã Claim';
    } else {
      throw new Error('Transaction failed');
    }
  } catch (err) {
    console.error(err);
    if (err.code === 'ACTION_REJECTED') {
      setClaimStatus('Bạn đã hủy giao dịch');
      claimBtn.disabled = false;
    } else if (err.message && err.message.includes('insufficient funds')) {
      setClaimStatus('Ví không đủ MATIC để trả gas');
      claimBtn.disabled = false;
    } else {
      setClaimStatus(`Claim thất bại: ${err.reason || err.message}`);
      claimBtn.disabled = false;
    }
  }
}

// ===== Mint =====
async function loadMintContract() {
  const addr = tokenAddressInput.value.trim();
  if (!ethers.isAddress(addr)) {
    tokenInfoEl.classList.remove('hidden');
    tokenInfoEl.textContent = 'Địa chỉ contract không hợp lệ.';
    mintBtn.disabled = true;
    return;
  }

  if (!signer) {
    tokenInfoEl.classList.remove('hidden');
    tokenInfoEl.textContent = 'Kết nối ví trước đã.';
    return;
  }

  try {
    mintContract = new ethers.Contract(addr, MINT_ABI, signer);
    tokenInfoEl.classList.remove('hidden');
    tokenInfoEl.textContent = 'Đang load thông tin token...';

    const [name, symbol, decimals] = await Promise.all([
      mintContract.name().catch(() => 'N/A'),
      mintContract.symbol().catch(() => 'N/A'),
      mintContract.decimals().catch(() => 18)
    ]);

    currentDecimals = Number(decimals);

    tokenInfoEl.innerHTML = `
      <b>Contract:</b> <a target="_blank" rel="noopener" href="https://polygonscan.com/address/${addr}">${addr.slice(0, 10)}...${addr.slice(-8)}</a><br>
      <b>Token:</b> ${name} (${symbol}) | <b>Decimals:</b> ${currentDecimals}<br>
      <b>Mint mỗi lần:</b> <span class="highlight">${MINT_AMOUNT.toLocaleString()} ${symbol}</span>
    `;
    mintBtn.disabled = false;
    setMintStatus('');
  } catch (e) {
    tokenInfoEl.textContent = `Không load được contract. Đảm bảo contract có hàm mint(address,uint256). Lỗi: ${e.message}`;
    mintBtn.disabled = true;
  }
}

async function handleMint() {
  const to = toAddressInput.value.trim();
  if (!ethers.isAddress(to)) {
    setMintStatus('Địa chỉ nhận không hợp lệ.');
    return;
  }
  if (!mintContract) {
    setMintStatus('Load contract trước đã.');
    return;
  }

  mintBtn.disabled = true;
  setMintStatus('<span class="loader"></span>Đang gửi giao dịch...');

  try {
    const amount = ethers.parseUnits(MINT_AMOUNT.toString(), currentDecimals);
    const tx = await mintContract.mint(to, amount);
    setMintStatus(
      `Đã gửi tx: <a target="_blank" rel="noopener" href="https://polygonscan.com/tx/${tx.hash}">${tx.hash.slice(0, 12)}...</a><br>Chờ xác nhận...`
    );
    await tx.wait();
    setMintStatus(
      `✅ Thành công! Đã mint ${MINT_AMOUNT.toLocaleString()} token.<br>` +
      `<a target="_blank" rel="noopener" href="https://polygonscan.com/tx/${tx.hash}">Xem giao dịch</a>`
    );
  } catch (e) {
    setMintStatus(`Thất bại: ${e.reason || e.message}`);
    console.error(e);
  } finally {
    mintBtn.disabled = false;
  }
}

// ===== Events =====
connectBtn.addEventListener('click', connectWallet);
claimBtn.addEventListener('click', handleClaim);
loadContractBtn.addEventListener('click', loadMintContract);
mintBtn.addEventListener('click', handleMint);

tokenAddressInput.addEventListener('change', () => {
  mintBtn.disabled = true;
  tokenInfoEl.classList.add('hidden');
  mintContract = null;
});

// Auto-reload on account / chain change
if (window.ethereum) {
  window.ethereum.on('accountsChanged', () => window.location.reload());
  window.ethereum.on('chainChanged', () => window.location.reload());
}
