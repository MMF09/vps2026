<?php
require_once __DIR__ . '/bootstrap.php';

try {
    if (empty($_FILES['file'])) {
        throw new InvalidArgumentException('Không có file được gửi lên');
    }
    $fm = new FileManager(BASE_DIR);
    $subdir = $_POST['dir'] ?? '';
    $name = $fm->upload($_FILES['file'], $subdir);
    echo json_encode(['success' => true, 'message' => "Tải lên thành công: $name"], JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException $e) {
    // Lỗi do người dùng (sai định dạng, quá dung lượng...) -> mức WARNING
    ErrorHandler::jsonError(ErrorHandler::LEVEL_WARNING, $e->getMessage(), 422);
} catch (Throwable $e) {
    // Lỗi hệ thống (không ghi được đĩa...) -> mức ERROR
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
