<?php
require_once __DIR__ . '/bootstrap.php';

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $subdir = $input['dir'] ?? '';
    $oldName = trim($input['old_name'] ?? '');
    $newName = trim($input['new_name'] ?? '');

    if ($oldName === '' || $newName === '') {
        throw new InvalidArgumentException('Thiếu tên nguồn hoặc tên mới');
    }

    $fm = new FileManager(BASE_DIR);
    $fm->rename($subdir, $oldName, $newName);
    echo json_encode(['success' => true, 'message' => "Đã đổi tên thành: $newName"], JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_WARNING, $e->getMessage(), 422);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
