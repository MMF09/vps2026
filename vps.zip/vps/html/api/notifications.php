<?php
require_once __DIR__ . '/bootstrap.php';

// Endpoint này được JS gọi định kỳ (polling) để lấy các thông báo lỗi/sự kiện
// đã được ErrorHandler::route() xếp hàng, rồi phân luồng hiển thị phía client.
echo json_encode([
    'success'       => true,
    'notifications' => ErrorHandler::getNotifications(),
], JSON_UNESCAPED_UNICODE);
