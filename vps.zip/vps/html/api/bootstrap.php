<?php
// Không in lỗi thô ra output của API - mọi lỗi phải đi qua ErrorHandler để phân luồng đúng
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/ErrorHandler.php';
require_once __DIR__ . '/../includes/FileManager.php';
require_once __DIR__ . '/../includes/DataAnalyzer.php';

ErrorHandler::init(LOG_DIR);

header('Content-Type: application/json; charset=utf-8');
