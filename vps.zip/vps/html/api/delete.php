<?php
require_once __DIR__ . '/bootstrap.php';

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $name = trim($input['name'] ?? '');
    $subdir = $input['dir'] ?? '';

    if ($name === '') {
        throw new InvalidArgumentException('Thiếu tên file/thư mục cần xóa');
    }

    $fm = new FileManager(BASE_DIR);
    $fm->delete($subdir, $name);
    echo json_encode(['success' => true, 'message' => "Đã xóa: $name"], JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_WARNING, $e->getMessage(), 422);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
