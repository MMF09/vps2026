<?php
require_once __DIR__ . '/bootstrap.php';

/**
 * Đọc N dòng log gần nhất từ logs/app.log và phân tích thành danh sách hoạt động
 * có gắn nhãn mức độ (info/warning/error/critical) để hiển thị trên dashboard.
 */
try {
    $limit = isset($_GET['limit']) ? max(1, min(200, (int) $_GET['limit'])) : 30;
    $logFile = LOG_DIR . '/app.log';

    $entries = [];
    if (is_file($logFile)) {
        $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lines = array_slice($lines, -$limit);
        $lines = array_reverse($lines); // mới nhất lên đầu

        foreach ($lines as $line) {
            if (preg_match('/^\[(.+?)\]\s\[(.+?)\]\s(.*)$/', $line, $m)) {
                $message = preg_replace('/\s\{.*\}$/', '', $m[3]); // bỏ context JSON ở cuối nếu có
                $entries[] = [
                    'time'    => $m[1],
                    'level'   => strtolower($m[2]),
                    'message' => $message,
                ];
            }
        }
    }

    // Đếm số lượng theo mức độ trong tập log đã đọc
    $counts = ['info' => 0, 'warning' => 0, 'error' => 0, 'critical' => 0];
    foreach ($entries as $e) {
        if (isset($counts[$e['level']])) {
            $counts[$e['level']]++;
        }
    }

    echo json_encode(['success' => true, 'entries' => $entries, 'counts' => $counts], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
