<?php
require_once __DIR__ . '/bootstrap.php';

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $subdir = $input['dir'] ?? '';
    $name = trim($input['name'] ?? '');

    if ($name === '') {
        throw new InvalidArgumentException('Thiếu tên thư mục');
    }

    $fm = new FileManager(BASE_DIR);
    $fm->makeDir($subdir, $name);
    echo json_encode(['success' => true, 'message' => "Đã tạo thư mục: $name"], JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_WARNING, $e->getMessage(), 422);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
