<?php
require_once __DIR__ . '/bootstrap.php';

try {
    $fm = new FileManager(BASE_DIR);
    $subdir = $_GET['dir'] ?? '';
    $items = $fm->listFiles($subdir);
    echo json_encode(['success' => true, 'items' => $items, 'dir' => $subdir], JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_WARNING, $e->getMessage(), 422);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
