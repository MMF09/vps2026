<?php
require_once __DIR__ . '/bootstrap.php';

try {
    // Quét thư mục trên SERVER (SCAN_DIR), không phụ thuộc uploads
    $scanPath = SCAN_DIR;
    // Cho phép override bằng query ?dir= (chỉ trong phạm vi SCAN_DIR để an toàn)
    if (!empty($_GET['dir'])) {
        $requested = realpath(SCAN_DIR . '/' . str_replace(['..', '\\'], '', $_GET['dir']));
        if ($requested !== false && strpos($requested, realpath(SCAN_DIR)) === 0) {
            $scanPath = $requested;
        }
    }

    $analyzer = new DataAnalyzer($scanPath);
    $data = $analyzer->analyze();
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    ErrorHandler::jsonError(ErrorHandler::LEVEL_ERROR, $e->getMessage(), 500);
}
