import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  push,
  onValue,
  remove,
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC3eiZy3Jxltpx-QXKFx-WNUlKdNLhBH2I",
  authDomain: "bigdata-c9bd2.firebaseapp.com",
  databaseURL: "https://bigdata-c9bd2-default-rtdb.firebaseio.com",
  projectId: "bigdata-c9bd2",
  storageBucket: "bigdata-c9bd2.firebasestorage.app",
  messagingSenderId: "168926822259",
  appId: "1:168926822259:web:8d298f671dbe456d958f06",
};

// Khởi tạo App
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// App State
let currentUser = null;
let rawRecords = {};
let activeTab = "MONTHLY"; // 'MONTHLY' | 'PARTTIME' | 'ACTUAL'

// DOM References
const viewLoggedOut = document.getElementById("view-logged-out");
const viewLoggedIn = document.getElementById("view-logged-in");
const userInfo = document.getElementById("user-info");
const userEmailSpan = document.getElementById("user-email");
const authError = document.getElementById("auth-error");

const tabMonthly = document.getElementById("tab-monthly");
const tabParttime = document.getElementById("tab-parttime");
const tabActual = document.getElementById("tab-actual");
const containerTimeInput = document.getElementById("container-time-input");
const containerJobTitle = document.getElementById("container-job-title");
const dynamicFormFields = document.getElementById("dynamic-form-fields");
const formIncome = document.getElementById("form-income");

const recordsTable = document.getElementById("records-table");
const recordsTbody = document.getElementById("records-tbody");
const tableSkeleton = document.getElementById("table-skeleton");
const emptyState = document.getElementById("empty-state");
const filterMonthSelect = document.getElementById("filter-month");
const filterTypeSelect = document.getElementById("filter-type");

// Thống kê DOM
const statMonthly = document.getElementById("stat-monthly");
const statParttime = document.getElementById("stat-parttime");
const statActual = document.getElementById("stat-actual");
const statTotal = document.getElementById("stat-total");

// Toast Notification System
function showToast(message, type = "info") {
  const toastContainer = document.getElementById("toast-container");
  const toast = document.createElement("div");

  const bgColors = {
    success: "bg-emerald-900/90 border-emerald-500 text-emerald-200",
    error: "bg-red-900/90 border-red-500 text-red-200",
    info: "bg-blue-900/90 border-blue-500 text-blue-200",
  };

  toast.className = `px-4 py-3 rounded-xl border text-xs font-medium shadow-2xl backdrop-blur-md transition-all duration-300 transform translate-x-10 opacity-0 flex items-center gap-2 ${
    bgColors[type] || bgColors.info
  }`;
  toast.innerHTML = `<span>${message}</span>`;
  toastContainer.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.remove("translate-x-10", "opacity-0");
  });

  setTimeout(() => {
    toast.classList.add("opacity-0", "translate-x-10");
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Helper format VNĐ & Date
const formatVND = (num) =>
  new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
    num || 0
  );

const formatDateVN = (dateStr) => {
  if (!dateStr) return "—";
  const parts = dateStr.split("-");
  if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
  if (parts.length === 2) return `Tháng ${parts[1]}/${parts[0]}`;
  return dateStr;
};

// Format month key for display (YYYY-MM → Tháng MM/YYYY)
function formatMonthLabel(monthKey) {
  if (!monthKey || !monthKey.includes("-")) return monthKey;
  const [y, m] = monthKey.split("-");
  return `Tháng ${m}/${y}`;
}

// Tính tổng giờ đã nhập trong cùng 1 ngày (chỉ PARTTIME HOURLY)
function getExistingHoursForDate(dateStr) {
  let total = 0;
  Object.values(rawRecords).forEach((rec) => {
    if (
      rec.type === "PARTTIME" &&
      rec.unit === "HOURLY" &&
      rec.timeStr === dateStr
    ) {
      total += parseFloat(rec.qty) || 0;
    }
  });
  return total;
}

// Render Form theo Tab
function switchTab(tab) {
  activeTab = tab;

  // Reset active styles
  const inactiveClass =
    "px-3 py-2 text-xs sm:text-sm font-medium rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/60 transition flex items-center gap-2";
  tabMonthly.className = inactiveClass;
  tabParttime.className = inactiveClass;
  tabActual.className = inactiveClass;

  // Hiện lại job title mặc định
  containerJobTitle.classList.remove("hidden");
  document.getElementById("income-job-title").required = true;

  if (tab === "MONTHLY") {
    tabMonthly.className =
      "px-3 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center gap-2 bg-blue-600 text-white shadow-lg shadow-blue-600/20";

    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(
      now.getMonth() + 1
    ).padStart(2, "0")}`;

    containerTimeInput.innerHTML = `
      <label class="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1">
        <i data-lucide="calendar" class="w-3.5 h-3.5 text-blue-400"></i> Tháng/Năm Tính Lương
      </label>
      <input type="month" id="income-time-monthly" required value="${currentMonth}" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500">
    `;

    dynamicFormFields.innerHTML = `
      <div>
        <label class="block text-xs font-medium text-slate-400 mb-1">Mức lương cố định tháng (VNĐ)</label>
        <input type="number" id="input-monthly-base" min="0" required placeholder="10000000" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500">
      </div>
      <div>
        <label class="block text-xs font-medium text-slate-400 mb-1">Tiền thưởng / OT / Phụ cấp thêm (VNĐ)</label>
        <input type="number" id="input-monthly-extra" min="0" placeholder="0" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500">
      </div>
    `;
  } else if (tab === "PARTTIME") {
    tabParttime.className =
      "px-3 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center gap-2 bg-purple-600 text-white shadow-lg shadow-purple-600/20";

    const today = new Date().toISOString().split("T")[0];

    containerTimeInput.innerHTML = `
      <label class="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1">
        <i data-lucide="calendar-days" class="w-3.5 h-3.5 text-purple-400"></i> Ngày Thực Hiện
      </label>
      <input type="date" id="income-time-parttime" required value="${today}" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500">
    `;

    dynamicFormFields.innerHTML = `
      <div>
        <label class="block text-xs font-medium text-slate-400 mb-1">Đơn vị chấm công</label>
        <select id="parttime-unit" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500">
          <option value="HOURLY">⏱️ Tính Theo Số Giờ Làm Việc</option>
          <option value="PRODUCT">📦 Tính Theo Số Lượng Sản Phẩm/Đơn</option>
        </select>
      </div>
      <div class="grid grid-cols-2 gap-2">
        <div>
          <label id="label-qty" class="block text-xs font-medium text-slate-400 mb-1">Số Giờ Làm (tối đa 24h/ngày)</label>
          <input type="number" step="0.5" id="input-qty" min="0" max="24" required placeholder="0" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500">
          <p id="hours-hint" class="text-[11px] text-slate-500 mt-1">Tối đa 24 giờ trong 1 ngày (bao gồm các bản ghi khác cùng ngày)</p>
        </div>
        <div>
          <label id="label-rate" class="block text-xs font-medium text-slate-400 mb-1">Đơn Giá / Giờ (VNĐ)</label>
          <input type="number" id="input-rate" min="0" required placeholder="0" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500">
        </div>
      </div>
    `;

    // Lắng nghe thay đổi đơn vị tính
    const unitSelect = document.getElementById("parttime-unit");
    const labelQty = document.getElementById("label-qty");
    const labelRate = document.getElementById("label-rate");
    const inputQty = document.getElementById("input-qty");
    const hoursHint = document.getElementById("hours-hint");

    unitSelect.addEventListener("change", (e) => {
      if (e.target.value === "HOURLY") {
        labelQty.textContent = "Số Giờ Làm (tối đa 24h/ngày)";
        labelRate.textContent = "Đơn Giá / Giờ (VNĐ)";
        inputQty.max = "24";
        inputQty.step = "0.5";
        hoursHint.classList.remove("hidden");
      } else {
        labelQty.textContent = "Số Sản Phẩm / Đơn";
        labelRate.textContent = "Đơn Giá / Sản Phẩm (VNĐ)";
        inputQty.removeAttribute("max");
        inputQty.step = "1";
        hoursHint.classList.add("hidden");
      }
    });
  } else if (tab === "ACTUAL") {
    tabActual.className =
      "px-3 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center gap-2 bg-amber-600 text-white shadow-lg shadow-amber-600/20";

    // Ẩn job title vì lương thực nhận thường gắn với tháng
    containerJobTitle.classList.add("hidden");
    document.getElementById("income-job-title").required = false;
    document.getElementById("income-job-title").value = "Lương thực nhận";

    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(
      now.getMonth() + 1
    ).padStart(2, "0")}`;

    containerTimeInput.innerHTML = `
      <label class="block text-xs font-medium text-slate-400 mb-1 flex items-center gap-1">
        <i data-lucide="calendar" class="w-3.5 h-3.5 text-amber-400"></i> Tháng/Năm Nhận Lương
      </label>
      <input type="month" id="income-time-actual" required value="${currentMonth}" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500">
    `;

    dynamicFormFields.innerHTML = `
      <div class="md:col-span-2">
        <label class="block text-xs font-medium text-slate-400 mb-1">Số tiền thực nhận về tài khoản / tiền mặt (VNĐ)</label>
        <input type="number" id="input-actual-amount" min="0" required placeholder="8500000" class="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500">
        <p class="text-[11px] text-slate-500 mt-1">Ghi nhận số tiền thực tế đã nhận (sau thuế, BHXH, khấu trừ...)</p>
      </div>
    `;
  }

  lucide.createIcons();
}

// Gắn sự kiện Chuyển Tab
tabMonthly.addEventListener("click", () => switchTab("MONTHLY"));
tabParttime.addEventListener("click", () => switchTab("PARTTIME"));
tabActual.addEventListener("click", () => switchTab("ACTUAL"));

// Khởi tạo tab mặc định
switchTab("MONTHLY");

// Auth Change Listener
onAuthStateChanged(auth, (user) => {
  currentUser = user;
  if (user) {
    viewLoggedOut.classList.add("hidden");
    viewLoggedIn.classList.remove("hidden");
    userInfo.classList.remove("hidden");
    userEmailSpan.textContent = user.email || user.displayName || "Google User";
    listenToUserData(user.uid);
  } else {
    viewLoggedOut.classList.remove("hidden");
    viewLoggedIn.classList.add("hidden");
    userInfo.classList.add("hidden");
    rawRecords = {};
  }
  lucide.createIcons();
});

// Login Handler (Email)
document.getElementById("form-auth").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("auth-email").value.trim();
  const pass = document.getElementById("auth-password").value;
  authError.classList.add("hidden");

  try {
    await signInWithEmailAndPassword(auth, email, pass);
    showToast("Đăng nhập thành công!", "success");
  } catch (err) {
    authError.textContent = "Lỗi đăng nhập: " + err.message;
    authError.classList.remove("hidden");
  }
});

// Register Handler
document.getElementById("btn-register").addEventListener("click", async () => {
  const email = document.getElementById("auth-email").value.trim();
  const pass = document.getElementById("auth-password").value;
  authError.classList.add("hidden");

  if (!email || pass.length < 6) {
    authError.textContent = "Mật khẩu cần ít nhất 6 ký tự.";
    authError.classList.remove("hidden");
    return;
  }

  try {
    await createUserWithEmailAndPassword(auth, email, pass);
    showToast("Đăng ký thành công!", "success");
  } catch (err) {
    authError.textContent = "Lỗi đăng ký: " + err.message;
    authError.classList.remove("hidden");
  }
});

// Google Login Handler
document.getElementById("btn-google-login").addEventListener("click", async () => {
  authError.classList.add("hidden");
  try {
    await signInWithPopup(auth, googleProvider);
    showToast("Đăng nhập Google thành công!", "success");
  } catch (err) {
    authError.textContent = "Lỗi đăng nhập Google: " + err.message;
    authError.classList.remove("hidden");
  }
});

// Logout Handler
document.getElementById("btn-logout").addEventListener("click", () => {
  signOut(auth);
  showToast("Đã đăng xuất.", "info");
});

// Lắng nghe Realtime Data từ Firebase
function listenToUserData(uid) {
  tableSkeleton.classList.remove("hidden");
  recordsTable.classList.add("hidden");
  emptyState.classList.add("hidden");

  const userRef = ref(db, `users/${uid}/income_records`);

  onValue(
    userRef,
    (snapshot) => {
      rawRecords = snapshot.val() || {};
      updateMonthFilterOptions();
      renderRecords();
      tableSkeleton.classList.add("hidden");
    },
    (error) => {
      showToast("Lỗi kết nối dữ liệu: " + error.message, "error");
      tableSkeleton.classList.add("hidden");
    }
  );
}

// Submit Form Lưu Dữ Liệu
formIncome.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUser) return;

  const jobTitle = document.getElementById("income-job-title").value.trim();
  const note = document.getElementById("income-note").value.trim();

  let recordData = {
    jobTitle: jobTitle || "Lương thực nhận",
    type: activeTab,
    note,
    createdAt: Date.now(),
  };

  if (activeTab === "MONTHLY") {
    const timeMonth = document.getElementById("income-time-monthly").value; // YYYY-MM
    const baseIncome =
      parseFloat(document.getElementById("input-monthly-base").value) || 0;
    const extraIncome =
      parseFloat(document.getElementById("input-monthly-extra").value) || 0;

    recordData = {
      ...recordData,
      timeStr: timeMonth,
      monthKey: timeMonth,
      baseIncome,
      extraIncome,
      total: baseIncome + extraIncome,
      detailText:
        extraIncome > 0
          ? `Lương gốc: ${formatVND(baseIncome)} + Thưởng/OT: ${formatVND(
              extraIncome
            )}`
          : "Lương cố định",
    };
  } else if (activeTab === "PARTTIME") {
    const timeDate = document.getElementById("income-time-parttime").value; // YYYY-MM-DD
    const monthKey = timeDate.substring(0, 7);
    const unit = document.getElementById("parttime-unit").value;
    const qty = parseFloat(document.getElementById("input-qty").value) || 0;
    const rate = parseFloat(document.getElementById("input-rate").value) || 0;
    const total = qty * rate;

    // === VALIDATION: Không cho nhập quá 24h/ngày ===
    if (unit === "HOURLY") {
      if (qty <= 0) {
        showToast("Số giờ làm phải lớn hơn 0.", "error");
        return;
      }
      if (qty > 24) {
        showToast("Không thể nhập quá 24 giờ trong một ngày!", "error");
        return;
      }
      const existingHours = getExistingHoursForDate(timeDate);
      if (existingHours + qty > 24) {
        showToast(
          `Tổng giờ làm ngày ${formatDateVN(timeDate)} đã có ${existingHours}h. Không thể thêm ${qty}h (vượt quá 24h).`,
          "error"
        );
        return;
      }
    }

    recordData = {
      ...recordData,
      timeStr: timeDate,
      monthKey,
      unit,
      qty,
      rate,
      total,
      detailText:
        unit === "HOURLY"
          ? `${qty} giờ x ${formatVND(rate)}/h`
          : `${qty} SP x ${formatVND(rate)}/sp`,
    };
  } else if (activeTab === "ACTUAL") {
    const timeMonth = document.getElementById("income-time-actual").value; // YYYY-MM
    const amount =
      parseFloat(document.getElementById("input-actual-amount").value) || 0;

    if (amount <= 0) {
      showToast("Số tiền thực nhận phải lớn hơn 0.", "error");
      return;
    }

    recordData = {
      ...recordData,
      timeStr: timeMonth,
      monthKey: timeMonth,
      total: amount,
      detailText: "Số tiền thực nhận về",
    };
  }

  try {
    const userRef = ref(db, `users/${currentUser.uid}/income_records`);
    await push(userRef, recordData);

    // Reset bớt các trường nhập
    document.getElementById("income-note").value = "";
    if (activeTab === "MONTHLY") {
      document.getElementById("input-monthly-base").value = "";
      document.getElementById("input-monthly-extra").value = "";
    } else if (activeTab === "PARTTIME") {
      document.getElementById("input-qty").value = "";
      document.getElementById("input-rate").value = "";
    } else if (activeTab === "ACTUAL") {
      document.getElementById("input-actual-amount").value = "";
    }

    showToast("Đã ghi nhận thu nhập thành công!", "success");
  } catch (err) {
    showToast("Lỗi lưu dữ liệu: " + err.message, "error");
  }
});

// Delete Record (Ủy quyền sự kiện)
recordsTbody.addEventListener("click", async (e) => {
  const deleteBtn = e.target.closest(".btn-delete-record");
  if (!deleteBtn) return;

  const recordId = deleteBtn.getAttribute("data-id");
  if (!recordId || !currentUser) return;

  if (confirm("Bạn có chắc chắn muốn xóa bản ghi này?")) {
    try {
      const itemRef = ref(
        db,
        `users/${currentUser.uid}/income_records/${recordId}`
      );
      await remove(itemRef);
      showToast("Đã xóa bản ghi.", "info");
    } catch (err) {
      showToast("Không thể xóa: " + err.message, "error");
    }
  }
});

// Render Bảng Dữ Liệu & Thống Kê
function renderRecords() {
  recordsTbody.innerHTML = "";

  const selectedMonth = filterMonthSelect.value;
  const selectedType = filterTypeSelect.value;

  let sumMonthly = 0;
  let sumParttime = 0;
  let sumActual = 0;

  const entries = Object.entries(rawRecords);

  const filtered = entries.filter(([id, item]) => {
    // Lọc theo Tháng
    const matchMonth =
      selectedMonth === "ALL" ||
      item.monthKey === selectedMonth ||
      (item.timeStr && item.timeStr.startsWith(selectedMonth));

    // Lọc theo Loại
    const itemType = item.type || (item.date ? "PARTTIME" : "MONTHLY");
    const matchType = selectedType === "ALL" || itemType === selectedType;

    return matchMonth && matchType;
  });

  // Sắp xếp thời gian mới nhất lên đầu
  filtered.sort((a, b) => {
    const timeA = a[1].timeStr || a[1].monthKey || "";
    const timeB = b[1].timeStr || b[1].monthKey || "";
    if (timeA === timeB) return (b[1].createdAt || 0) - (a[1].createdAt || 0);
    return timeB.localeCompare(timeA);
  });

  // Fix: Ẩn/hiện bảng + empty state đúng cách
  if (filtered.length === 0) {
    emptyState.classList.remove("hidden");
    recordsTable.classList.add("hidden");
  } else {
    emptyState.classList.add("hidden");
    recordsTable.classList.remove("hidden");
  }

  let htmlBuffer = "";

  filtered.forEach(([id, item]) => {
    const itemType = item.type || (item.date ? "PARTTIME" : "MONTHLY");
    const itemTotal = item.total || 0;

    if (itemType === "MONTHLY") {
      sumMonthly += itemTotal;
    } else if (itemType === "PARTTIME") {
      sumParttime += itemTotal;
    } else if (itemType === "ACTUAL") {
      sumActual += itemTotal;
    }

    let typeBadge = "";
    if (itemType === "MONTHLY") {
      typeBadge = `<span class="px-2 py-0.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-md text-[11px] font-medium">Lương Tháng</span>`;
    } else if (itemType === "PARTTIME") {
      typeBadge = `<span class="px-2 py-0.5 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded-md text-[11px] font-medium">Part-time</span>`;
    } else {
      typeBadge = `<span class="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-md text-[11px] font-medium">Thực nhận</span>`;
    }

    htmlBuffer += `
      <tr class="hover:bg-slate-900/50 transition border-b border-slate-800/40">
        <td class="px-4 py-3 font-medium text-white whitespace-nowrap">${formatDateVN(
          item.timeStr || item.month
        )}</td>
        <td class="px-4 py-3">
          <div class="font-medium text-slate-200">${
            item.jobTitle || item.industry || "Công việc"
          }</div>
          <div class="mt-0.5">${typeBadge}</div>
        </td>
        <td class="px-4 py-3 text-xs text-slate-400">${
          item.detailText || item.extraDetail || "—"
        }</td>
        <td class="px-4 py-3 font-bold text-emerald-400 whitespace-nowrap">${formatVND(
          itemTotal
        )}</td>
        <td class="px-4 py-3 text-xs text-slate-400 max-w-[150px] truncate">${
          item.note || "—"
        }</td>
        <td class="px-4 py-3 text-right">
          <button data-id="${id}" title="Xóa bản ghi" class="btn-delete-record p-1.5 text-slate-500 hover:text-red-400 hover:bg-slate-800/80 rounded-lg transition active:scale-95">
            <i data-lucide="trash-2" class="w-4 h-4"></i>
          </button>
        </td>
      </tr>
    `;
  });

  recordsTbody.innerHTML = htmlBuffer;

  // Cập nhật thẻ Thống kê
  statMonthly.textContent = formatVND(sumMonthly);
  statParttime.textContent = formatVND(sumParttime);
  if (statActual) statActual.textContent = formatVND(sumActual);
  // Tổng thu nhập lọc = lương tháng + parttime + thực nhận (theo bộ lọc hiện tại)
  statTotal.textContent = formatVND(sumMonthly + sumParttime + sumActual);

  lucide.createIcons();
}

// Cập nhật Options Bộ lọc Tháng
function updateMonthFilterOptions() {
  const months = new Set();

  Object.values(rawRecords).forEach((rec) => {
    if (rec.monthKey) months.add(rec.monthKey);
    else if (rec.timeStr) months.add(rec.timeStr.substring(0, 7));
    else if (rec.month) months.add(rec.month);
  });

  const sortedMonths = Array.from(months).sort().reverse();
  const currentSelection = filterMonthSelect.value;

  filterMonthSelect.innerHTML = `<option value="ALL">Tất cả các tháng</option>`;

  sortedMonths.forEach((m) => {
    const opt = document.createElement("option");
    opt.value = m;
    opt.textContent = formatMonthLabel(m);
    filterMonthSelect.appendChild(opt);
  });

  // Giữ lựa chọn cũ nếu còn tồn tại
  if (
    currentSelection === "ALL" ||
    sortedMonths.includes(currentSelection)
  ) {
    filterMonthSelect.value = currentSelection;
  } else {
    filterMonthSelect.value = "ALL";
  }
}

// Lắng nghe sự kiện thay đổi bộ lọc
filterMonthSelect.addEventListener("change", renderRecords);
filterTypeSelect.addEventListener("change", renderRecords);
