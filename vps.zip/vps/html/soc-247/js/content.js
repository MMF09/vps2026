// Content Module - Structured data from SOC-24-7 Framework repository
// Source: https://github.com/MarianoP23/-SOC-24-7---Security-Operations-Center-Framework

export const MODULES = [
  {
    id: "dashboard",
    number: "00",
    title: "Dashboard",
    icon: "📊",
    short: "Tổng quan KPI & hoạt động"
  },
  {
    id: "architecture",
    number: "01",
    title: "SOC Architecture",
    icon: "🏗️",
    short: "Kiến trúc & hạ tầng SOC"
  },
  {
    id: "playbooks",
    number: "02",
    title: "Detection & Response",
    icon: "📘",
    short: "Playbooks xử lý sự cố"
  },
  {
    id: "automation",
    number: "03",
    title: "SOC Automation",
    icon: "⚙️",
    short: "Tự động hóa phản ứng"
  },
  {
    id: "operations",
    number: "04",
    title: "Operational Procedures",
    icon: "📋",
    short: "MTTD, MTTR, Escalation"
  },
  {
    id: "hunting",
    number: "05",
    title: "Threat Hunting",
    icon: "🔍",
    short: "Khung săn tìm mối đe dọa"
  },
  {
    id: "dashboards",
    number: "06",
    title: "Dashboards & Visibility",
    icon: "📈",
    short: "Hiển thị thời gian thực"
  },
  {
    id: "roles",
    number: "07",
    title: "Roles & Responsibilities",
    icon: "👥",
    short: "Vai trò & trách nhiệm"
  },
  {
    id: "resources",
    number: "08",
    title: "Additional Resources",
    icon: "📚",
    short: "Đào tạo & chứng chỉ"
  },
  {
    id: "incidents",
    number: "IR",
    title: "Incident Tracker",
    icon: "🚨",
    short: "Quản lý sự cố thực tế"
  }
];

/* ========== 01 ARCHITECTURE ========== */
export const ARCHITECTURE = {
  title: "SOC Architecture & Infrastructure",
  intro: "Một SOC 24/7 là xương sống của tư thế an ninh mạng. Nó kết hợp người, quy trình và công nghệ để phát hiện, phân tích và phản ứng với các mối đe dọa theo thời gian thực.",
  components: [
    {
      name: "SIEM",
      full: "Security Information and Event Management",
      desc: "Trái tim của SOC — thu thập, tương quan và phân tích log từ nhiều nguồn để phát hiện sự cố.",
      tools: ["Splunk", "IBM QRadar", "Microsoft Sentinel", "Elastic Security"],
      responsibilities: [
        "Tổng hợp log từ thiết bị mạng, server, cloud và endpoint",
        "Tương quan sự kiện để phát hiện mẫu đe dọa",
        "Tạo cảnh báo và hỗ trợ forensic"
      ]
    },
    {
      name: "SOAR",
      full: "Security Orchestration, Automation and Response",
      desc: "Tự động hóa phản ứng sự cố, giảm MTTD và MTTR.",
      tools: ["Splunk SOAR (Phantom)", "Cortex XSOAR", "IBM Resilient", "Microsoft Sentinel Playbooks"],
      responsibilities: [
        "Tự động hóa task lặp lại (block IP, isolate endpoint)",
        "Tích hợp SIEM, EDR, IDS/IPS",
        "Workflow phản ứng dựa trên playbook"
      ]
    },
    {
      name: "EDR / XDR",
      full: "Endpoint / Extended Detection & Response",
      desc: "Tầm nhìn sâu vào hoạt động endpoint, phát hiện và phản ứng thời gian thực.",
      tools: ["CrowdStrike Falcon", "Microsoft Defender for Endpoint", "SentinelOne", "Palo Alto Cortex XDR"],
      responsibilities: [
        "Phát hiện fileless malware, ransomware, insider threats",
        "Phân tích forensic chi tiết",
        "Quarantine và remediation"
      ]
    },
    {
      name: "IDS / IPS",
      full: "Intrusion Detection & Prevention System",
      desc: "Giám sát traffic mạng để phát hiện và ngăn chặn tấn công.",
      tools: ["Suricata", "Snort", "Cisco Firepower", "Zeek"],
      responsibilities: [
        "Phát hiện mẫu đáng ngờ trong traffic",
        "Ngăn malware và C2 communication",
        "Cảnh báo thời gian thực + log forensic"
      ]
    },
    {
      name: "Threat Intelligence",
      full: "Threat Intelligence Feeds & Platforms",
      desc: "Làm giàu cảnh báo bằng dữ liệu đe dọa toàn cầu.",
      tools: ["MISP", "OpenCTI", "Recorded Future", "AlienVault OTX", "IBM X-Force"],
      responsibilities: [
        "Làm giàu alert với context",
        "Phát hiện IOC",
        "Giảm false positive bằng behavioral analytics"
      ]
    },
    {
      name: "Log Management",
      full: "Log Management & Data Retention",
      desc: "Chiến lược lưu trữ log dài hạn cho forensic và tuân thủ.",
      tools: ["Splunk", "Graylog", "Elastic Stack (ELK)"],
      responsibilities: [
        "Lưu log 6 tháng – 7 năm tùy quy định",
        "Đảm bảo tính toàn vẹn và mã hóa log",
        "Hỗ trợ ISO 27001, NIST, GDPR, HIPAA"
      ]
    }
  ],
  principles: [
    "Defense in Depth (DiD)",
    "Zero Trust",
    "Least Privilege Access",
    "Continuous Monitoring 24/7",
    "Automated Incident Response",
    "Threat Hunting Capabilities",
    "Compliance Alignment (NIST, ISO 27001)"
  ]
};

/* ========== 02 PLAYBOOKS ========== */
export const PLAYBOOKS = [
  {
    id: "phishing",
    title: "Phishing Attack Playbook",
    severity: "high",
    mitre: "T1566",
    objective: "Phát hiện, phân tích, chứa chấp và khắc phục email phishing và nỗ lực thu thập thông tin xác thực.",
    detection: [
      "SIEM Rules theo dõi email đáng ngờ hàng loạt",
      "Email Security Gateway phát hiện domain phishing",
      "Báo cáo từ người dùng",
      "Threat Intelligence (PhishTank, VirusTotal)"
    ],
    steps: {
      detection: [
        "Xác thực báo cáo email phishing",
        "Trích xuất và phân tích email headers",
        "Kiểm tra URL bằng sandbox + threat intel"
      ],
      containment: [
        "Block domain phishing trên email security tools",
        "Blacklist IP độc hại trên firewall",
        "Force password reset cho user bị nhắm"
      ],
      eradication: [
        "Xóa email phishing khỏi inbox",
        "Quét workstation bằng EDR",
        "Kiểm tra truy cập trái phép trên IAM"
      ],
      lessons: [
        "Đào tạo nhận thức phishing cho user",
        "Cập nhật control dựa trên TTP (MITRE T1566)",
        "Báo cáo theo ISO 27035 và NIST"
      ]
    }
  },
  {
    id: "ransomware",
    title: "Ransomware Attack Playbook",
    severity: "critical",
    mitre: "T1486 / T1055 / T1071",
    objective: "Phát hiện, chứa chấp và khắc phục ransomware nhằm giảm thiểu mất dữ liệu và gián đoạn hoạt động.",
    detection: [
      "SIEM: mã hóa file đột ngột, CPU cao, SMB bất thường",
      "EDR: fileless malware, process injection, persistence",
      "IDS/IPS: traffic C2 đến server ransomware",
      "Báo cáo từ user về file bị mã hóa"
    ],
    steps: {
      detection: [
        "Xác minh chỉ số ransomware (mã hóa, ransom note)",
        "Xác định strain (LockBit, Ryuk, Conti…) qua threat intel"
      ],
      containment: [
        "Isolate hệ thống bị ảnh hưởng (EDR / VLAN / NAC)",
        "Block C2 (firewall, DNS sinkhole)",
        "Vô hiệu hóa account bị xâm nhập"
      ],
      eradication: [
        "Khôi phục từ offline backup (kiểm tra integrity)",
        "Loại bỏ persistence (bootkit, scheduled task, registry)",
        "Phân tích forensic ngăn tái nhiễm"
      ],
      lessons: [
        "Application allowlisting",
        "Cải thiện endpoint policy và SIEM rules",
        "Báo cáo theo CISA / GDPR"
      ]
    }
  },
  {
    id: "insider",
    title: "Insider Threat Playbook",
    severity: "high",
    mitre: "T1020 / T1036",
    objective: "Phát hiện, điều tra và giảm thiểu đe dọa nội bộ: exfiltration, lạm dụng quyền, truy cập trái phép.",
    detection: [
      "DLP alerts cho chuyển dữ liệu nhạy cảm",
      "User Behavior Analytics (UBA)",
      "SIEM & IAM logs bất thường",
      "Endpoint: copy USB / cloud / personal email"
    ],
    steps: {
      detection: [
        "Điều tra DLP, AD logs, VPN logs",
        "Profiling rủi ro user hành vi bất thường",
        "Kiểm tra credential bị compromise"
      ],
      containment: [
        "Hạn chế truy cập hệ thống quan trọng",
        "Suspend account trong lúc điều tra",
        "Block kênh exfiltration"
      ],
      eradication: [
        "Reset password + enforce MFA",
        "Gỡ quyền truy cập trái phép",
        "Cải thiện rule SIEM / UEBA"
      ],
      lessons: [
        "Forensic review hoạt động account",
        "Tăng cường Least Privilege & Zero Trust",
        "Báo cáo theo ISO 27001, PCI DSS, NIST"
      ]
    }
  }
];

/* ========== 03 AUTOMATION ========== */
export const AUTOMATION = {
  title: "SOC Automation",
  intro: "Tự động hóa giúp SOC giảm thời gian phản ứng, giảm tải cho analyst và tăng độ nhất quán.",
  categories: [
    {
      name: "Python Scripts",
      items: ["Auto-enrich IOC từ VirusTotal / MISP", "Parse SIEM alerts → ticket", "Bulk block IP trên firewall API"]
    },
    {
      name: "PowerShell Scripts",
      items: ["Isolate endpoint qua Defender / CrowdStrike API", "Force password reset hàng loạt", "Collect forensic artifacts"]
    },
    {
      name: "Ansible Playbooks",
      items: ["Deploy detection agents", "Remediate configuration drift", "Orchestrate multi-tool response"]
    }
  ],
  goals: [
    "Giảm MTTR dưới 60 phút cho sự cố critical",
    "Tự động hóa >50% sự cố thường gặp",
    "Giảm false positive thông qua enrichment"
  ]
};

/* ========== 04 OPERATIONS ========== */
export const OPERATIONS = {
  title: "Operational Procedures",
  kpis: [
    { name: "MTTD", full: "Mean Time to Detect", target: "< 30 phút", formula: "Tổng thời gian phát hiện / Số sự cố" },
    { name: "MTTR", full: "Mean Time to Respond", target: "< 60 phút", formula: "Tổng thời gian phản ứng / Số sự cố" },
    { name: "False Positive Rate", full: "Tỷ lệ cảnh báo sai", target: "< 5%", formula: "False alerts / Total alerts" },
    { name: "Incident Closure Rate", full: "Tỷ lệ đóng sự cố trong SLA", target: "> 95%", formula: "Closed in SLA / Total" },
    { name: "SOC Coverage", full: "Tỷ lệ log được giám sát", target: "> 98%", formula: "Monitored sources / Total sources" },
    { name: "Automation Efficiency", full: "Tỷ lệ sự cố xử lý tự động", target: "> 50%", formula: "Auto-handled / Total incidents" }
  ],
  severityLevels: [
    { level: "L1 – Low", desc: "Cảnh báo nhỏ, không cần hành động ngay", escalate: "SOC Analyst → Log for Review", time: "24 giờ" },
    { level: "L2 – Medium", desc: "Có thể là breach, cần review", escalate: "Analyst → Supervisor", time: "6 giờ" },
    { level: "L3 – High", desc: "Sự cố xác nhận, ảnh hưởng vận hành", escalate: "Supervisor → IR Team", time: "2 giờ" },
    { level: "L4 – Critical", desc: "Ảnh hưởng liên tục kinh doanh", escalate: "IR → CISO → Executive", time: "15 phút" }
  ],
  irPhases: [
    { phase: "Preparation", desc: "Chính sách, quy trình, công cụ, đào tạo" },
    { phase: "Detection & Analysis", desc: "Nhận diện sự kiện, đánh giá impact, phân loại" },
    { phase: "Containment, Eradication & Recovery", desc: "Cô lập, loại bỏ đe dọa, khôi phục an toàn" },
    { phase: "Post-Incident Activity", desc: "Post-mortem, cập nhật playbook, cải thiện" }
  ]
};

/* ========== 05 THREAT HUNTING ========== */
export const HUNTING = {
  title: "Threat Hunting Frameworks",
  intro: "Săn tìm chủ động các đe dọa đã vượt qua phòng thủ truyền thống, dựa trên MITRE ATT&CK.",
  sources: [
    { name: "Splunk", queries: ["index=wineventlog EventCode=4688 NewProcessName=*powershell*", "Suspicious lateral movement via SMB"] },
    { name: "CrowdStrike", queries: ["Process injection indicators", "Unusual network connections from endpoint"] },
    { name: "Elastic / ELK", queries: ["Anomalous authentication patterns", "DNS tunneling candidates"] }
  ],
  focus: ["Adversary TTPs Tracking", "IOC / IOA correlation", "Behavioral anomaly detection"]
};

/* ========== 06 DASHBOARDS ========== */
export const DASHBOARDS_CONTENT = {
  title: "Dashboards & Real-Time Visibility",
  intro: "Dashboard SIEM cung cấp tầm nhìn thời gian thực về trạng thái bảo mật.",
  recommendations: [
    "Executive dashboard: high-level risk & KPI",
    "Analyst dashboard: live alerts, triage queue",
    "Threat intel dashboard: IOC hits, campaign tracking",
    "Compliance dashboard: coverage, retention, audit readiness"
  ]
};

/* ========== 07 ROLES ========== */
export const ROLES = [
  {
    tier: "L1",
    role: "SOC Analyst",
    function: "Alert Triage & Initial Investigation",
    responsibilities: [
      "Monitor SIEM dashboards",
      "Triage và xác định severity",
      "Escalate lên L2",
      "Document initial findings",
      "Identify false positives"
    ],
    skills: ["SIEM cơ bản (Splunk/ELK)", "MITRE ATT&CK", "Network & Endpoint basics"]
  },
  {
    tier: "L2",
    role: "SOC Investigator / Incident Responder",
    function: "Threat Investigation & Response",
    responsibilities: [
      "Forensic analysis",
      "Deep-dive investigation",
      "Contain incidents",
      "Coordinate remediation",
      "Work with Threat Hunting"
    ],
    skills: ["DFIR", "EDR (CrowdStrike/SentinelOne)", "Malware analysis basics"]
  },
  {
    tier: "L3",
    role: "Threat Hunter / SOC Engineer",
    function: "Advanced Detection & Infrastructure",
    responsibilities: [
      "Custom hunting queries",
      "Develop detection rules",
      "Maintain SIEM/SOAR",
      "Adversary emulation",
      "Integrate TIP"
    ],
    skills: ["CTI", "Python/PowerShell/Ansible", "Behavioral analytics"]
  },
  {
    tier: "Mgmt",
    role: "SOC Manager",
    function: "Operations & Oversight",
    responsibilities: [
      "SOC policies & procedures",
      "KPI monitoring (MTTD/MTTR)",
      "Staffing & budget",
      "Primary escalation point",
      "Compliance alignment"
    ],
    skills: ["Leadership", "Risk management", "Compliance frameworks"]
  },
  {
    tier: "Exec",
    role: "CISO",
    function: "Executive Security Leadership",
    responsibilities: [
      "Enterprise security strategy",
      "Risk & threat intel programs",
      "Regulatory compliance",
      "Budget & investment",
      "Security awareness"
    ],
    skills: ["Governance", "Strategic planning", "Business risk"]
  }
];

/* ========== 08 RESOURCES ========== */
export const RESOURCES = {
  title: "Additional Resources",
  frameworks: [
    { name: "NIST 800-61", desc: "Incident Handling & Response" },
    { name: "ISO/IEC 27035", desc: "Incident Management" },
    { name: "MITRE ATT&CK", desc: "Threat Hunting & Detection" },
    { name: "CIS Controls", desc: "Security Monitoring & Automation" },
    { name: "PCI DSS", desc: "Log Auditing & Compliance" },
    { name: "GDPR", desc: "Data Protection & Access Auditing" }
  ],
  techStack: {
    SIEM: ["Splunk", "Elastic Stack", "IBM QRadar", "Microsoft Sentinel"],
    SOAR: ["Cortex XSOAR", "Splunk Phantom", "Microsoft Sentinel"],
    EDR: ["CrowdStrike Falcon", "SentinelOne", "Microsoft Defender ATP"],
    TI: ["MISP", "OpenCTI", "ThreatConnect"],
    IDS: ["Suricata", "Zeek", "Cisco Firepower"],
    Automation: ["Python", "PowerShell", "Ansible"]
  },
  nextSteps: [
    "Enhance automation với AI-driven detection",
    "Tích hợp ITSM (ServiceNow, Jira)",
    "Refine threat hunting bằng ML & behavioral analytics"
  ]
};
