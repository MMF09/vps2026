// Authentication Module - Login only (no registration)
import { 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { ref, set, get, update } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";
import { auth, database } from "./firebase-config.js";

const googleProvider = new GoogleAuthProvider();

export async function loginWithEmail(email, password) {
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    await saveUserToDatabase(cred.user, "email");
    return { success: true, user: cred.user };
  } catch (error) {
    return { success: false, error: mapAuthError(error.code) };
  }
}

export async function loginWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    await saveUserToDatabase(result.user, "google");
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: mapAuthError(error.code) };
  }
}

export async function logout() {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function saveUserToDatabase(user, provider) {
  const userRef = ref(database, `users/${user.uid}`);
  const snapshot = await get(userRef);
  
  const base = {
    uid: user.uid,
    email: user.email || "",
    displayName: user.displayName || user.email?.split("@")[0] || "Analyst",
    photoURL: user.photoURL || "",
    provider,
    lastLogin: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (snapshot.exists()) {
    await update(userRef, {
      lastLogin: base.lastLogin,
      updatedAt: base.updatedAt,
      displayName: base.displayName,
      photoURL: base.photoURL
    });
  } else {
    // First login — default role analyst
    await set(userRef, {
      ...base,
      role: "analyst",          // analyst | investigator | engineer | manager
      tier: "L1",
      createdAt: new Date().toISOString(),
      preferences: { theme: "dark", sidebarCollapsed: false }
    });
  }
}

export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}

export function getCurrentUser() {
  return auth.currentUser;
}

function mapAuthError(code) {
  const map = {
    "auth/invalid-email": "Email không hợp lệ.",
    "auth/user-disabled": "Tài khoản đã bị vô hiệu hóa.",
    "auth/user-not-found": "Không tìm thấy tài khoản. Liên hệ quản trị viên để được cấp quyền.",
    "auth/wrong-password": "Mật khẩu không đúng.",
    "auth/invalid-credential": "Email hoặc mật khẩu không đúng.",
    "auth/too-many-requests": "Quá nhiều lần thử. Vui lòng thử lại sau.",
    "auth/popup-closed-by-user": "Bạn đã đóng cửa sổ đăng nhập Google.",
    "auth/network-request-failed": "Lỗi kết nối mạng.",
    "auth/operation-not-allowed": "Phương thức đăng nhập chưa được bật."
  };
  return map[code] || `Lỗi: ${code}`;
}
