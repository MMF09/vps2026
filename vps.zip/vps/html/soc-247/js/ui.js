// UI Rendering Module
import { MODULES, ARCHITECTURE, PLAYBOOKS, AUTOMATION, OPERATIONS, HUNTING, DASHBOARDS_CONTENT, ROLES, RESOURCES } from "./content.js";
import { getIncidents, createIncident, updateIncident, listenIncidents, getLatestKpis } from "./db.js";

let currentUser = null;
let currentModule = "dashboard";
let incidentsCache = [];

export function setCurrentUser(user) {
  currentUser = user;
}

export function renderAppShell(user) {
  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="app-layout">
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
          <div class="logo-icon">S</div>
          <div class="logo-text">SOC <span>24/7</span></div>
        </div>
        <nav class="sidebar-nav" id="sidebarNav"></nav>
        <div class="sidebar-footer">
          <div class="user-chip">
            <div class="avatar" id="sidebarAvatar">${(user.displayName || "A")[0].toUpperCase()}</div>
            <div class="user-meta">
              <div class="name" id="sidebarName">${user.displayName || user.email}</div>
              <div class="role">SOC Analyst</div>
            </div>
          </div>
          <button class="btn-logout" id="logoutBtn">Đăng xuất</button>
        </div>
      </aside>
      <main class="main">
        <header class="topbar">
          <button class="sidebar-toggle" id="sidebarToggle">☰</button>
          <h1 class="page-title" id="pageTitle">Dashboard</h1>
          <div class="topbar-actions">
            <span class="badge-live"><span class="dot"></span> 24/7 Live</span>
          </div>
        </header>
        <div class="content" id="contentArea"></div>
      </main>
    </div>
  `;

  // Build sidebar
  const nav = document.getElementById("sidebarNav");
  nav.innerHTML = MODULES.map(m => `
    <a href="#${m.id}" class="nav-item ${m.id === currentModule ? "active" : ""}" data-module="${m.id}">
      <span class="nav-num">${m.number}</span>
      <span class="nav-icon">${m.icon}</span>
      <span class="nav-label">${m.title}</span>
    </a>
  `).join("");

  // Events
  nav.querySelectorAll(".nav-item").forEach(el => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo(el.dataset.module);
    });
  });

  document.getElementById("sidebarToggle").addEventListener("click", () => {
    const sb = document.getElementById("sidebar");
    const main = document.querySelector(".main");
    sb.classList.toggle("collapsed");
    if (main) {
      main.style.marginLeft = sb.classList.contains("collapsed") ? "72px" : "";
    }
  });

  // Hash routing
  window.addEventListener("hashchange", () => {
    const hash = location.hash.replace("#", "") || "dashboard";
    navigateTo(hash);
  });

  navigateTo(location.hash.replace("#", "") || "dashboard");
}

function navigateTo(moduleId) {
  currentModule = moduleId;
  document.querySelectorAll(".nav-item").forEach(el => {
    el.classList.toggle("active", el.dataset.module === moduleId);
  });
  const mod = MODULES.find(m => m.id === moduleId) || MODULES[0];
  document.getElementById("pageTitle").textContent = mod.title;
  location.hash = moduleId;
  renderModule(moduleId);
}

function renderModule(id) {
  const area = document.getElementById("contentArea");
  switch (id) {
    case "dashboard": renderDashboard(area); break;
    case "architecture": renderArchitecture(area); break;
    case "playbooks": renderPlaybooks(area); break;
    case "automation": renderAutomation(area); break;
    case "operations": renderOperations(area); break;
    case "hunting": renderHunting(area); break;
    case "dashboards": renderDashboards(area); break;
    case "roles": renderRoles(area); break;
    case "resources": renderResources(area); break;
    case "incidents": renderIncidents(area); break;
    default: renderDashboard(area);
  }
}

/* ========== DASHBOARD ========== */
async function renderDashboard(area) {
  area.innerHTML = `
    <div class="kpi-grid" id="kpiGrid">
      <div class="kpi-card"><div class="kpi-label">MTTD Target</div><div class="kpi-value accent">&lt;30m</div><div class="kpi-sub">Mean Time to Detect</div></div>
      <div class="kpi-card"><div class="kpi-label">MTTR Target</div><div class="kpi-value accent">&lt;60m</div><div class="kpi-sub">Mean Time to Respond</div></div>
      <div class="kpi-card"><div class="kpi-label">False Positive</div><div class="kpi-value">&lt;5%</div><div class="kpi-sub">Target rate</div></div>
      <div class="kpi-card"><div class="kpi-label">Closure Rate</div><div class="kpi-value success">&gt;95%</div><div class="kpi-sub">Within SLA</div></div>
      <div class="kpi-card"><div class="kpi-label">SOC Coverage</div><div class="kpi-value">&gt;98%</div><div class="kpi-sub">Log sources</div></div>
      <div class="kpi-card"><div class="kpi-label">Automation</div><div class="kpi-value">&gt;50%</div><div class="kpi-sub">Auto-handled</div></div>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-header"><h3>Quick Navigation</h3></div>
        <div class="quick-nav">
          ${MODULES.filter(m => m.id !== "dashboard").map(m => `
            <a href="#${m.id}" class="quick-item" data-module="${m.id}">
              <span>${m.icon}</span>
              <div><strong>${m.number} · ${m.title}</strong><small>${m.short}</small></div>
            </a>
          `).join("")}
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <h3>Recent Incidents</h3>
          <a href="#incidents" class="link">Xem tất cả →</a>
        </div>
        <div id="recentIncidents"><div class="empty">Đang tải...</div></div>
      </div>
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Framework Alignment</h3></div>
      <div class="tag-list">
        <span class="tag">NIST 800-61</span>
        <span class="tag">ISO/IEC 27035</span>
        <span class="tag">MITRE ATT&CK</span>
        <span class="tag">CIS Controls</span>
        <span class="tag">PCI DSS</span>
        <span class="tag">GDPR</span>
      </div>
    </div>
  `;

  area.querySelectorAll(".quick-item").forEach(el => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo(el.dataset.module);
    });
  });

  // Load recent incidents
  try {
    const list = await getIncidents(5);
    const box = document.getElementById("recentIncidents");
    if (!list.length) {
      box.innerHTML = `<div class="empty">Chưa có sự cố nào. <a href="#incidents">Tạo sự cố mới</a></div>`;
    } else {
      box.innerHTML = list.map(i => `
        <div class="incident-row">
          <span class="sev sev-${i.severity}">${i.severity}</span>
          <div class="inc-info">
            <strong>${escapeHtml(i.title)}</strong>
            <small>${i.status} · ${formatDate(i.createdAt)}</small>
          </div>
        </div>
      `).join("");
    }
  } catch (e) {
    document.getElementById("recentIncidents").innerHTML = `<div class="empty">Không thể tải dữ liệu</div>`;
  }
}

/* ========== ARCHITECTURE ========== */
function renderArchitecture(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${ARCHITECTURE.title}</h2>
      <p>${ARCHITECTURE.intro}</p>
    </div>
    <div class="comp-grid">
      ${ARCHITECTURE.components.map(c => `
        <div class="card comp-card">
          <div class="comp-name">${c.name}</div>
          <div class="comp-full">${c.full}</div>
          <p>${c.desc}</p>
          <div class="tag-list">${c.tools.map(t => `<span class="tag">${t}</span>`).join("")}</div>
          <ul class="list">${c.responsibilities.map(r => `<li>${r}</li>`).join("")}</ul>
        </div>
      `).join("")}
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Design Principles</h3></div>
      <div class="tag-list">${ARCHITECTURE.principles.map(p => `<span class="tag">${p}</span>`).join("")}</div>
    </div>
  `;
}

/* ========== PLAYBOOKS ========== */
function renderPlaybooks(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>Detection & Response Playbooks</h2>
      <p>Hướng dẫn từng bước xử lý sự cố theo NIST 800-61, MITRE ATT&CK, ISO 27035.</p>
    </div>
    <div class="playbook-list">
      ${PLAYBOOKS.map(pb => `
        <div class="card playbook-card" data-id="${pb.id}">
          <div class="pb-header">
            <h3>${pb.title}</h3>
            <span class="sev sev-${pb.severity}">${pb.severity}</span>
          </div>
          <p class="pb-obj">${pb.objective}</p>
          <div class="pb-meta">MITRE: <code>${pb.mitre}</code></div>
          <details>
            <summary>Xem chi tiết playbook</summary>
            <div class="pb-body">
              <h4>Detection Methods</h4>
              <ul>${pb.detection.map(d => `<li>${d}</li>`).join("")}</ul>
              <h4>1. Detection & Identification</h4>
              <ul>${pb.steps.detection.map(s => `<li>${s}</li>`).join("")}</ul>
              <h4>2. Containment</h4>
              <ul>${pb.steps.containment.map(s => `<li>${s}</li>`).join("")}</ul>
              <h4>3. Eradication & Recovery</h4>
              <ul>${pb.steps.eradication.map(s => `<li>${s}</li>`).join("")}</ul>
              <h4>4. Lessons Learned</h4>
              <ul>${pb.steps.lessons.map(s => `<li>${s}</li>`).join("")}</ul>
            </div>
          </details>
        </div>
      `).join("")}
    </div>
  `;
}

/* ========== AUTOMATION ========== */
function renderAutomation(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${AUTOMATION.title}</h2>
      <p>${AUTOMATION.intro}</p>
    </div>
    <div class="grid-3">
      ${AUTOMATION.categories.map(c => `
        <div class="card">
          <h3>${c.name}</h3>
          <ul class="list">${c.items.map(i => `<li>${i}</li>`).join("")}</ul>
        </div>
      `).join("")}
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Automation Goals</h3></div>
      <ul class="list">${AUTOMATION.goals.map(g => `<li>${g}</li>`).join("")}</ul>
    </div>
  `;
}

/* ========== OPERATIONS ========== */
function renderOperations(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${OPERATIONS.title}</h2>
      <p>MTTD, MTTR, Escalation Policies và KPIs theo chuẩn NIST & ISO.</p>
    </div>
    <div class="kpi-grid">
      ${OPERATIONS.kpis.map(k => `
        <div class="kpi-card">
          <div class="kpi-label">${k.name}</div>
          <div class="kpi-value accent">${k.target}</div>
          <div class="kpi-sub">${k.full}</div>
        </div>
      `).join("")}
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Incident Severity & Escalation</h3></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Level</th><th>Mô tả</th><th>Escalation</th><th>Thời gian</th></tr></thead>
          <tbody>
            ${OPERATIONS.severityLevels.map(s => `
              <tr>
                <td><strong>${s.level}</strong></td>
                <td>${s.desc}</td>
                <td>${s.escalate}</td>
                <td>${s.time}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
    <div class="card mt">
      <div class="card-header"><h3>IR Phases (NIST 800-61)</h3></div>
      <div class="phase-grid">
        ${OPERATIONS.irPhases.map((p, i) => `
          <div class="phase">
            <div class="phase-num">${i + 1}</div>
            <div><strong>${p.phase}</strong><p>${p.desc}</p></div>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

/* ========== HUNTING ========== */
function renderHunting(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${HUNTING.title}</h2>
      <p>${HUNTING.intro}</p>
    </div>
    <div class="grid-3">
      ${HUNTING.sources.map(s => `
        <div class="card">
          <h3>${s.name}</h3>
          <ul class="list mono">${s.queries.map(q => `<li><code>${q}</code></li>`).join("")}</ul>
        </div>
      `).join("")}
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Focus Areas</h3></div>
      <div class="tag-list">${HUNTING.focus.map(f => `<span class="tag">${f}</span>`).join("")}</div>
    </div>
  `;
}

/* ========== DASHBOARDS CONTENT ========== */
function renderDashboards(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${DASHBOARDS_CONTENT.title}</h2>
      <p>${DASHBOARDS_CONTENT.intro}</p>
    </div>
    <div class="card">
      <div class="card-header"><h3>Recommended Dashboards</h3></div>
      <ul class="list">${DASHBOARDS_CONTENT.recommendations.map(r => `<li>${r}</li>`).join("")}</ul>
    </div>
  `;
}

/* ========== ROLES ========== */
function renderRoles(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>SOC Roles & Responsibilities</h2>
      <p>Cấu trúc đội ngũ theo tier, trách nhiệm và kỹ năng cần thiết.</p>
    </div>
    <div class="roles-grid">
      ${ROLES.map(r => `
        <div class="card role-card">
          <div class="role-tier">${r.tier}</div>
          <h3>${r.role}</h3>
          <p class="role-func">${r.function}</p>
          <h4>Responsibilities</h4>
          <ul class="list">${r.responsibilities.map(x => `<li>${x}</li>`).join("")}</ul>
          <h4>Skills</h4>
          <div class="tag-list">${r.skills.map(s => `<span class="tag">${s}</span>`).join("")}</div>
        </div>
      `).join("")}
    </div>
  `;
}

/* ========== RESOURCES ========== */
function renderResources(area) {
  area.innerHTML = `
    <div class="page-intro">
      <h2>${RESOURCES.title}</h2>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-header"><h3>Security Frameworks</h3></div>
        <ul class="list">${RESOURCES.frameworks.map(f => `<li><strong>${f.name}</strong> — ${f.desc}</li>`).join("")}</ul>
      </div>
      <div class="card">
        <div class="card-header"><h3>Next Steps</h3></div>
        <ul class="list">${RESOURCES.nextSteps.map(n => `<li>${n}</li>`).join("")}</ul>
      </div>
    </div>
    <div class="card mt">
      <div class="card-header"><h3>Technology Stack</h3></div>
      ${Object.entries(RESOURCES.techStack).map(([k, v]) => `
        <div class="stack-row">
          <strong>${k}</strong>
          <div class="tag-list">${v.map(t => `<span class="tag">${t}</span>`).join("")}</div>
        </div>
      `).join("")}
    </div>
  `;
}

/* ========== INCIDENTS ========== */
function renderIncidents(area) {
  area.innerHTML = `
    <div class="page-intro flex-between">
      <div>
        <h2>Incident Tracker</h2>
        <p>Quản lý sự cố thực tế, liên kết với playbook và escalation.</p>
      </div>
      <button class="btn btn-primary" id="btnNewIncident">+ Tạo sự cố</button>
    </div>
    <div class="card">
      <div id="incidentList"><div class="empty">Đang tải...</div></div>
    </div>
    <div id="incidentModal" class="modal hidden">
      <div class="modal-card">
        <h3>Tạo sự cố mới</h3>
        <form id="incidentForm">
          <div class="form-group">
            <label>Tiêu đề</label>
            <input type="text" id="incTitle" required placeholder="Ví dụ: Phishing email targeting Finance" />
          </div>
          <div class="form-group">
            <label>Mô tả</label>
            <textarea id="incDesc" rows="3" placeholder="Chi tiết ban đầu..."></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Severity</label>
              <select id="incSeverity">
                <option value="low">Low</option>
                <option value="medium" selected>Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
            <div class="form-group">
              <label>Category</label>
              <select id="incCategory">
                <option value="phishing">Phishing</option>
                <option value="ransomware">Ransomware</option>
                <option value="insider">Insider Threat</option>
                <option value="malware">Malware</option>
                <option value="dos">DoS / DDoS</option>
                <option value="data_breach">Data Breach</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Playbook liên kết</label>
            <select id="incPlaybook">
              <option value="">— Không chọn —</option>
              ${PLAYBOOKS.map(p => `<option value="${p.id}">${p.title}</option>`).join("")}
            </select>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-outline" id="btnCancelInc">Hủy</button>
            <button type="submit" class="btn btn-primary">Tạo sự cố</button>
          </div>
        </form>
      </div>
    </div>
  `;

  const modal = document.getElementById("incidentModal");
  document.getElementById("btnNewIncident").onclick = () => modal.classList.remove("hidden");
  document.getElementById("btnCancelInc").onclick = () => modal.classList.add("hidden");

  document.getElementById("incidentForm").onsubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    const data = {
      title: document.getElementById("incTitle").value.trim(),
      description: document.getElementById("incDesc").value.trim(),
      severity: document.getElementById("incSeverity").value,
      category: document.getElementById("incCategory").value,
      playbookId: document.getElementById("incPlaybook").value || null,
      createdBy: currentUser.uid
    };
    try {
      await createIncident(data);
      modal.classList.add("hidden");
      e.target.reset();
      loadIncidentList();
    } catch (err) {
      alert("Lỗi tạo sự cố: " + err.message);
    }
  };

  loadIncidentList();
}

async function loadIncidentList() {
  const box = document.getElementById("incidentList");
  if (!box) return;
  try {
    const list = await getIncidents(50);
    incidentsCache = list;
    if (!list.length) {
      box.innerHTML = `<div class="empty">Chưa có sự cố. Nhấn "Tạo sự cố" để bắt đầu.</div>`;
      return;
    }
    box.innerHTML = `
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Severity</th>
              <th>Title</th>
              <th>Category</th>
              <th>Status</th>
              <th>Created</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${list.map(i => `
              <tr>
                <td><span class="sev sev-${i.severity}">${i.severity}</span></td>
                <td><strong>${escapeHtml(i.title)}</strong></td>
                <td>${i.category || "—"}</td>
                <td><span class="status status-${i.status}">${i.status}</span></td>
                <td>${formatDate(i.createdAt)}</td>
                <td>
                  <select class="status-select" data-id="${i.id}">
                    <option value="open" ${i.status==="open"?"selected":""}>open</option>
                    <option value="investigating" ${i.status==="investigating"?"selected":""}>investigating</option>
                    <option value="contained" ${i.status==="contained"?"selected":""}>contained</option>
                    <option value="resolved" ${i.status==="resolved"?"selected":""}>resolved</option>
                    <option value="closed" ${i.status==="closed"?"selected":""}>closed</option>
                  </select>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
    box.querySelectorAll(".status-select").forEach(sel => {
      sel.onchange = async () => {
        await updateIncident(sel.dataset.id, { status: sel.value });
        loadIncidentList();
      };
    });
  } catch (e) {
    box.innerHTML = `<div class="empty">Lỗi tải danh sách sự cố</div>`;
  }
}

/* ========== HELPERS ========== */
function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str || "";
  return d.innerHTML;
}

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" });
}
