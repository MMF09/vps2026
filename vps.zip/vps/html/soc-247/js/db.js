// Database Service Module - Realtime Database helpers
import { ref, set, get, push, update, remove, query, orderByChild, limitToLast, onValue } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";
import { database } from "./firebase-config.js";

/* ========== USERS ========== */
export async function getUserProfile(uid) {
  const snap = await get(ref(database, `users/${uid}`));
  return snap.exists() ? snap.val() : null;
}

export async function updateUserProfile(uid, data) {
  await update(ref(database, `users/${uid}`), { ...data, updatedAt: new Date().toISOString() });
}

/* ========== INCIDENTS ========== */
export async function createIncident(incident) {
  const newRef = push(ref(database, "incidents"));
  const data = {
    id: newRef.key,
    title: incident.title,
    description: incident.description || "",
    severity: incident.severity || "medium",   // low | medium | high | critical
    status: "open",                            // open | investigating | contained | resolved | closed
    category: incident.category || "other",    // phishing | ransomware | insider | malware | dos | data_breach | other
    playbookId: incident.playbookId || null,
    assignedTo: incident.assignedTo || null,
    createdBy: incident.createdBy,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timeline: [{
      action: "created",
      by: incident.createdBy,
      at: new Date().toISOString(),
      note: "Incident created"
    }]
  };
  await set(newRef, data);
  return data;
}

export async function updateIncident(id, updates) {
  const payload = { ...updates, updatedAt: new Date().toISOString() };
  await update(ref(database, `incidents/${id}`), payload);
}

export async function addIncidentTimeline(id, entry) {
  const snap = await get(ref(database, `incidents/${id}/timeline`));
  const timeline = snap.exists() ? snap.val() : [];
  timeline.push({ ...entry, at: new Date().toISOString() });
  await update(ref(database, `incidents/${id}`), {
    timeline,
    updatedAt: new Date().toISOString()
  });
}

export async function getIncidents(limit = 50) {
  const q = query(ref(database, "incidents"), orderByChild("createdAt"), limitToLast(limit));
  const snap = await get(q);
  if (!snap.exists()) return [];
  return Object.values(snap.val()).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export function listenIncidents(callback) {
  const q = query(ref(database, "incidents"), orderByChild("createdAt"), limitToLast(100));
  return onValue(q, (snap) => {
    if (!snap.exists()) { callback([]); return; }
    const list = Object.values(snap.val()).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    callback(list);
  });
}

/* ========== KPI SNAPSHOTS ========== */
export async function saveKpiSnapshot(kpi) {
  const dateKey = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  await set(ref(database, `kpis/${dateKey}`), {
    date: dateKey,
    mttdMinutes: kpi.mttdMinutes ?? null,
    mttrMinutes: kpi.mttrMinutes ?? null,
    falsePositiveRate: kpi.falsePositiveRate ?? null,
    incidentClosureRate: kpi.incidentClosureRate ?? null,
    socCoverage: kpi.socCoverage ?? null,
    automationEfficiency: kpi.automationEfficiency ?? null,
    totalIncidents: kpi.totalIncidents ?? 0,
    updatedAt: new Date().toISOString()
  });
}

export async function getLatestKpis(days = 30) {
  const snap = await get(ref(database, "kpis"));
  if (!snap.exists()) return [];
  return Object.values(snap.val())
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, days);
}

/* ========== BOOKMARKS / NOTES ========== */
export async function saveBookmark(uid, moduleId, note = "") {
  const id = `${moduleId}_${Date.now()}`;
  await set(ref(database, `users/${uid}/bookmarks/${id}`), {
    id,
    moduleId,
    note,
    createdAt: new Date().toISOString()
  });
}

export async function getBookmarks(uid) {
  const snap = await get(ref(database, `users/${uid}/bookmarks`));
  return snap.exists() ? Object.values(snap.val()) : [];
}

/* ========== ACTIVITY LOG ========== */
export async function logActivity(uid, action, detail = "") {
  const newRef = push(ref(database, `activity/${uid}`));
  await set(newRef, {
    action,
    detail,
    at: new Date().toISOString()
  });
}
