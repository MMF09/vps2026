// Firebase Configuration Module
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyAdVQH5MK3xZv1B4BmmAOinSsTV_92PwJA",
  authDomain: "project-doidoi.firebaseapp.com",
  databaseURL: "https://project-doidoi-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "project-doidoi",
  storageBucket: "project-doidoi.firebasestorage.app",
  messagingSenderId: "849773176716",
  appId: "1:849773176716:web:8c21c71beffa0693d058a9"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

export { app, auth, database };
