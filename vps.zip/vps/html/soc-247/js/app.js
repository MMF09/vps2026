// Main Application Entry
import { loginWithEmail, loginWithGoogle, logout, onAuthChange } from "./auth.js";
import { renderAppShell, setCurrentUser } from "./ui.js";

const loginOverlay = document.getElementById("loginOverlay");
const appRoot = document.getElementById("app");
const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginBtn = document.getElementById("loginBtn");
const googleBtn = document.getElementById("googleBtn");
const errorMsg = document.getElementById("errorMsg");
const loadingSpinner = document.getElementById("loadingSpinner");

function setLoading(on) {
  loadingSpinner.classList.toggle("hidden", !on);
  loginBtn.disabled = on;
  googleBtn.disabled = on;
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorMsg.classList.remove("hidden");
}

function hideError() {
  errorMsg.classList.add("hidden");
}

function showLogin() {
  loginOverlay.classList.remove("hidden");
  appRoot.classList.add("hidden");
  appRoot.innerHTML = "";
}

function showApp(user) {
  loginOverlay.classList.add("hidden");
  appRoot.classList.remove("hidden");
  setCurrentUser(user);
  renderAppShell(user);

  // Bind logout after shell rendered
  setTimeout(() => {
    const btn = document.getElementById("logoutBtn");
    if (btn) btn.onclick = async () => { await logout(); };
  }, 50);
}

async function handleEmailLogin(e) {
  e.preventDefault();
  hideError();
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if (!email || !password) {
    showError("Vui lòng nhập email và mật khẩu.");
    return;
  }
  setLoading(true);
  const res = await loginWithEmail(email, password);
  setLoading(false);
  if (!res.success) showError(res.error);
}

async function handleGoogleLogin() {
  hideError();
  setLoading(true);
  const res = await loginWithGoogle();
  setLoading(false);
  if (!res.success) showError(res.error);
}

function init() {
  onAuthChange((user) => {
    if (user) showApp(user);
    else showLogin();
  });

  loginForm.addEventListener("submit", handleEmailLogin);
  googleBtn.addEventListener("click", handleGoogleLogin);
}

document.addEventListener("DOMContentLoaded", init);
