<?php
/**
 * Folder Dashboard – Scan API
 * Quét thư mục gốc, phân loại folder (có/không index.html) và file lẻ.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, no-store, must-revalidate');

$baseDir = __DIR__;

// Các mục không hiển thị
$exclude = [
    '.', '..',
    'scan.php', 'index.html',
    'css', 'js',
    '.htaccess', '.git', '.gitignore',
    'README.md', 'huong-dan.txt'
];

$result = [
    'folders_with_index'    => [],
    'folders_without_index' => [],
    'files'                 => []
];

$items = @scandir($baseDir);
if ($items === false) {
    echo json_encode(['error' => 'Không thể đọc thư mục'], JSON_UNESCAPED_UNICODE);
    exit;
}

foreach ($items as $item) {
    if (in_array($item, $exclude, true)) {
        continue;
    }

    $fullPath = $baseDir . DIRECTORY_SEPARATOR . $item;

    // === FOLDER ===
    if (is_dir($fullPath)) {
        $hasIndex = is_file($fullPath . DIRECTORY_SEPARATOR . 'index.html');
        $count    = count(array_diff(@scandir($fullPath) ?: [], ['.', '..']));

        $folderData = [
            'name'        => $item,
            'path'        => $item,
            'description' => $hasIndex ? 'Có trang index.html' : 'Không có index.html',
            'icon'        => $hasIndex ? '📂' : '📁',
            'hasIndex'    => $hasIndex,
            'items'       => $count,
            'modified'    => date('d/m/Y H:i', filemtime($fullPath))
        ];

        if ($hasIndex) {
            $result['folders_with_index'][] = $folderData;
        } else {
            $result['folders_without_index'][] = $folderData;
        }
    }
    // === FILE ===
    elseif (is_file($fullPath)) {
        $ext  = strtolower(pathinfo($item, PATHINFO_EXTENSION));
        $size = filesize($fullPath);

        $result['files'][] = [
            'name'     => $item,
            'path'     => $item,
            'ext'      => $ext,
            'size'     => formatBytes($size),
            'icon'     => getFileIcon($ext),
            'modified' => date('d/m/Y H:i', filemtime($fullPath))
        ];
    }
}

// Sắp xếp theo tên (không phân biệt hoa thường)
usort($result['folders_with_index'],    fn($a, $b) => strcasecmp($a['name'], $b['name']));
usort($result['folders_without_index'], fn($a, $b) => strcasecmp($a['name'], $b['name']));
usort($result['files'],                 fn($a, $b) => strcasecmp($a['name'], $b['name']));

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

// ===== Helpers =====
function formatBytes(int $bytes, int $precision = 2): string {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow   = $bytes > 0 ? floor(log($bytes) / log(1024)) : 0;
    $pow   = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}

function getFileIcon(string $ext): string {
    $map = [
        'pdf'  => '📄',
        'doc'  => '📝', 'docx' => '📝',
        'xls'  => '📊', 'xlsx' => '📊',
        'ppt'  => '📑', 'pptx' => '📑',
        'jpg'  => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️',
        'gif'  => '🖼️', 'webp' => '🖼️', 'svg' => '🖼️', 'bmp' => '🖼️', 'ico' => '🖼️',
        'mp4'  => '🎬', 'mkv'  => '🎬', 'avi' => '🎬', 'webm' => '🎬',
        'mp3'  => '🎵', 'wav'  => '🎵', 'ogg' => '🎵', 'flac' => '🎵',
        'zip'  => '📦', 'rar'  => '📦', '7z'  => '📦', 'tar' => '📦', 'gz' => '📦',
        'txt'  => '📃', 'md'   => '📃', 'log' => '📃',
        'html' => '🌐', 'css'  => '🎨', 'js'  => '⚙️',
        'php'  => '🐘', 'json' => '📋', 'xml' => '📋',
        'csv'  => '📊',
    ];
    return $map[$ext] ?? '📄';
}
