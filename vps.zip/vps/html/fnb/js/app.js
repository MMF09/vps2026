import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getDatabase, ref, push, set, onValue, remove, update
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyC7HE94M-w9chHikRLxlAKMeYsR_71GBpc",
  authDomain: "fbamthucdouong.firebaseapp.com",
  databaseURL: "https://fbamthucdouong-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "fbamthucdouong",
  storageBucket: "fbamthucdouong.firebasestorage.app",
  messagingSenderId: "399700364963",
  appId: "1:399700364963:web:9e200dbce457822fb7b916"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

let currentUser = null;
let userDbRef = null;
let inventoryData = {};
let recipesData = {};
let ordersData = {};
let cart = {};
let unsubscribeInventory = null, unsubscribeRecipes = null, unsubscribeOrders = null;

const $ = id => document.getElementById(id);
const money = n => Number(n || 0).toLocaleString("vi-VN") + "đ";
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

function icons() { if (window.lucide) lucide.createIcons(); }

function showAuthError(msg) {
  const el = $("auth-error");
  el.textContent = msg;
  el.classList.remove("hidden");
}

function clearAuthError() {
  const el = $("auth-error");
  el.textContent = "";
  el.classList.add("hidden");
}

function friendlyAuthError(error) {
  const code = error?.code || "";
  const map = {
    "auth/invalid-credential": "Email hoặc mật khẩu không đúng.",
    "auth/invalid-email": "Email không hợp lệ.",
    "auth/email-already-in-use": "Email này đã được đăng ký.",
    "auth/weak-password": "Mật khẩu cần ít nhất 6 ký tự.",
    "auth/popup-closed-by-user": "Bạn đã đóng cửa sổ Google.",
    "auth/popup-blocked": "Trình duyệt đã chặn popup Google.",
    "auth/operation-not-allowed": "Phương thức đăng nhập này chưa được bật trong Firebase Authentication."
  };
  return map[code] || error?.message || "Đã xảy ra lỗi xác thực.";
}

function resetListeners() {
  [unsubscribeInventory, unsubscribeRecipes, unsubscribeOrders].forEach(fn => {
    if (typeof fn === "function") fn();
  });
  unsubscribeInventory = unsubscribeRecipes = unsubscribeOrders = null;
}

function initDatabaseListener(uid) {
  resetListeners();
  userDbRef = `users/${uid}`;

  unsubscribeInventory = onValue(ref(db, `${userDbRef}/inventory`), snapshot => {
    inventoryData = snapshot.val() || {};
    renderInventory(); renderPosMenu(); renderRecipes(); renderCart();
  }, err => console.error("Inventory listener:", err));

  unsubscribeRecipes = onValue(ref(db, `${userDbRef}/recipes`), snapshot => {
    recipesData = snapshot.val() || {};
    renderRecipes(); renderPosMenu(); renderCart(); renderReports();
  }, err => console.error("Recipes listener:", err));

  unsubscribeOrders = onValue(ref(db, `${userDbRef}/orders`), snapshot => {
    ordersData = snapshot.val() || {};
    renderReports();
  }, err => console.error("Orders listener:", err));
}

onAuthStateChanged(auth, user => {
  const modal = $("auth-modal");
  const badge = $("status-badge");
  const statusText = $("status-text");
  const logout = $("btn-logout");

  if (user) {
    currentUser = user;
    modal.classList.add("hidden");
    logout.classList.remove("hidden");
    $("user-email-display").textContent = user.email || "Google User";
    $("user-uid-display").textContent = user.uid;
    badge.className = "flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs rounded-full";
    statusText.textContent = "Online (Phiên làm việc)";
    initDatabaseListener(user.uid);
  } else {
    currentUser = null; userDbRef = null; cart = {};
    resetListeners();
    inventoryData = {}; recipesData = {}; ordersData = {};
    modal.classList.remove("hidden"); logout.classList.add("hidden");
    $("user-email-display").textContent = "Chưa xác thực";
    $("user-uid-display").textContent = "---";
    badge.className = "flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs rounded-full";
    statusText.textContent = "Chưa đăng nhập";
    renderInventory(); renderRecipes(); renderPosMenu(); renderCart(); renderReports();
  }
});

$("btn-login-google").addEventListener("click", async () => {
  clearAuthError();
  try { await signInWithPopup(auth, googleProvider); }
  catch (e) { showAuthError("Đăng nhập Google thất bại: " + friendlyAuthError(e)); }
});

$("form-auth").addEventListener("submit", async e => {
  e.preventDefault(); clearAuthError();
  try {
    await signInWithEmailAndPassword(auth, $("auth-email").value.trim(), $("auth-password").value);
  } catch (err) { showAuthError(friendlyAuthError(err)); }
});

$("btn-register").addEventListener("click", async () => {
  clearAuthError();
  const email = $("auth-email").value.trim(), password = $("auth-password").value;
  if (!email || !password) return showAuthError("Vui lòng nhập đầy đủ Email và Mật khẩu.");
  try {
    await createUserWithEmailAndPassword(auth, email, password);
    alert("Tạo tài khoản thành công.");
  } catch (err) { showAuthError("Đăng ký thất bại: " + friendlyAuthError(err)); }
});

$("btn-logout").addEventListener("click", async () => {
  if (confirm("Bạn có chắc chắn muốn đăng xuất khỏi phiên làm việc?")) await signOut(auth);
});

$("btn-copy-uid").addEventListener("click", async () => {
  if (!currentUser) return alert("Chưa đăng nhập!");
  try { await navigator.clipboard.writeText(currentUser.uid); alert("Đã copy UID cửa hàng!"); }
  catch { alert("Không thể copy tự động. UID: " + currentUser.uid); }
});

window.switchTab = function(tab) {
  ["inventory","bom","simulate","reports"].forEach(t => {
    $(`tab-${t}`).classList.add("hidden");
    $(`tab-btn-${t}`).classList.remove("border-indigo-500","text-indigo-400");
    $(`tab-btn-${t}`).classList.add("border-transparent","text-slate-400");
    $(`mob-tab-${t}`)?.classList.remove("text-indigo-400");
  });
  $(`tab-${tab}`).classList.remove("hidden");
  $(`tab-btn-${tab}`).classList.add("border-indigo-500","text-indigo-400");
  $(`tab-btn-${tab}`).classList.remove("border-transparent","text-slate-400");
  $(`mob-tab-${tab}`)?.classList.add("text-indigo-400");
  icons();
};

$("form-ingredient").addEventListener("submit", async e => {
  e.preventDefault();
  if (!userDbRef) return alert("Vui lòng đăng nhập!");
  const name = $("ing-name").value.trim();
  const stock = Number($("ing-stock").value), unit = $("ing-unit").value.trim();
  const min_stock = Number($("ing-min").value), cost = Number($("ing-cost").value);
  if (!name || !unit || [stock,min_stock,cost].some(Number.isNaN) || stock < 0 || min_stock < 0 || cost < 0)
    return alert("Vui lòng nhập dữ liệu nguyên liệu hợp lệ.");
  try {
    await set(push(ref(db, `${userDbRef}/inventory`)), {name, stock, unit, min_stock, cost});
    e.target.reset();
  } catch (err) { alert("Lỗi lưu nguyên liệu: " + err.message); }
});

function renderInventory() {
  const tbody = $("inventory-list"); if (!tbody) return;
  tbody.innerHTML = "";
  let low = 0;
  Object.entries(inventoryData).forEach(([id,item]) => {
    const stock=Number(item.stock)||0, min=Number(item.min_stock)||0, cost=Number(item.cost)||0;
    const isLow = stock <= min; if (isLow) low++;
    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-800/40 transition";
    tr.innerHTML = `<td class="p-2.5 md:p-3 font-medium text-slate-200">${esc(item.name)}</td>
      <td class="p-2.5 md:p-3 text-right font-bold ${isLow?'text-amber-400':'text-emerald-400'}">${stock} ${esc(item.unit)}</td>
      <td class="p-2.5 md:p-3 text-right text-slate-400">${min} ${esc(item.unit)}</td>
      <td class="p-2.5 md:p-3 text-right text-slate-300">${money(cost)}</td>
      <td class="p-2.5 md:p-3 text-center"><button data-id="${esc(id)}" class="btn-del-ing text-rose-400 hover:text-rose-300"><i data-lucide="trash-2" class="w-4 h-4 inline"></i></button></td>`;
    tbody.appendChild(tr);
  });
  $("low-stock-count").textContent = `${low} cảnh báo`;
  tbody.querySelectorAll(".btn-del-ing").forEach(btn => btn.addEventListener("click", async () => {
    if (!confirm("Xóa nguyên liệu này? Các BOM đang tham chiếu nguyên liệu này có thể bị thiếu dữ liệu.")) return;
    try { await remove(ref(db, `${userDbRef}/inventory/${btn.dataset.id}`)); }
    catch(e) { alert("Lỗi xóa: " + e.message); }
  }));
  icons();
}

function addBomRow(selectedIngId="", amount="") {
  const container = $("bom-items-container");
  const div = document.createElement("div");
  div.className = "flex gap-2 items-center bom-row";
  const options = `<option value="">-- Chọn Nguyên Liệu --</option>` +
    Object.entries(inventoryData).map(([id,ing]) =>
      `<option value="${esc(id)}" ${id===selectedIngId?"selected":""}>${esc(ing.name)} (${esc(ing.unit)})</option>`).join("");
  div.innerHTML = `<select class="bom-ing-id w-2/3 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs">${options}</select>
    <input type="number" min="0" step="0.001" placeholder="Số lượng" value="${esc(amount)}" class="bom-amount w-1/3 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs">
    <button type="button" class="btn-remove-row text-slate-500 hover:text-rose-400"><i data-lucide="x-circle" class="w-4 h-4"></i></button>`;
  div.querySelector(".btn-remove-row").addEventListener("click", () => div.remove());
  container.appendChild(div); icons();
}
$("btn-add-bom-row").addEventListener("click", () => addBomRow());

$("form-recipe").addEventListener("submit", async e => {
  e.preventDefault();
  if (!userDbRef) return alert("Vui lòng đăng nhập!");
  const dish_name=$("rec-name").value.trim(), category=$("rec-category").value;
  const price=Number($("rec-price").value);
  const bom=[];
  document.querySelectorAll(".bom-row").forEach(row => {
    const ing_id=row.querySelector(".bom-ing-id").value, amount=Number(row.querySelector(".bom-amount").value);
    if (ing_id && Number.isFinite(amount) && amount > 0) bom.push({ing_id, amount});
  });
  if (!dish_name || !Number.isFinite(price) || price < 0) return alert("Tên món và giá bán không hợp lệ.");
  if (!bom.length) return alert("Vui lòng thêm ít nhất 1 định lượng nguyên liệu.");
  const ids=bom.map(x=>x.ing_id);
  if (new Set(ids).size !== ids.length) return alert("Một nguyên liệu chỉ nên xuất hiện một lần trong BOM.");
  try {
    await set(push(ref(db, `${userDbRef}/recipes`)), {dish_name,category,price,bom});
    e.target.reset(); $("bom-items-container").innerHTML=""; addBomRow();
  } catch(err) { alert("Lỗi lưu công thức: " + err.message); }
});

function recipeCost(rec) {
  return (Array.isArray(rec.bom) ? rec.bom : Object.values(rec.bom || {})).reduce((sum,b) => {
    const ing=inventoryData[b.ing_id]; return sum + (ing ? Number(b.amount||0)*Number(ing.cost||0) : 0);
  },0);
}

function renderRecipes() {
  const container=$("recipes-list"); if(!container) return;
  container.innerHTML="";
  Object.entries(recipesData).forEach(([id,rec]) => {
    const totalCost=recipeCost(rec), margin=Number(rec.price||0)-totalCost;
    const marginPct=Number(rec.price)>0 ? (margin/Number(rec.price)*100).toFixed(1) : "0.0";
    const bom=Array.isArray(rec.bom)?rec.bom:Object.values(rec.bom||{});
    const list=bom.map(b=>{
      const ing=inventoryData[b.ing_id];
      return `<li class="flex justify-between text-xs text-slate-400"><span>- ${esc(ing?.name||"Nguyên liệu đã xóa")}: ${Number(b.amount)||0} ${esc(ing?.unit||"")}</span><span>${money((Number(b.amount)||0)*Number(ing?.cost||0))}</span></li>`;
    }).join("");
    const card=document.createElement("div");
    card.className="bg-slate-900 border border-slate-700/80 rounded-xl p-4 space-y-3";
    card.innerHTML=`<div class="flex justify-between items-start"><div><span class="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">${esc(rec.category)}</span><h3 class="font-bold text-slate-100 text-sm md:text-base mt-1">${esc(rec.dish_name)}</h3></div><button data-id="${esc(id)}" class="btn-del-rec text-slate-500 hover:text-rose-400"><i data-lucide="trash-2" class="w-4 h-4"></i></button></div>
      <div class="space-y-1 bg-slate-950/50 p-2.5 rounded-lg border border-slate-800"><span class="text-[10px] font-semibold text-slate-400">Thành phần BOM:</span><ul class="space-y-1">${list}</ul></div>
      <div class="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs"><div><span class="text-slate-400">Giá bán:</span><p class="font-bold text-emerald-400">${money(rec.price)}</p></div><div><span class="text-slate-400">Cost vốn:</span><p class="font-bold text-rose-400">${money(totalCost)}</p></div><div class="col-span-2 pt-1 flex justify-between text-[11px] text-slate-400 border-t border-slate-800/60"><span>Lợi nhuận: <strong class="text-slate-200">${money(margin)}</strong></span><span>Margin: <strong class="text-indigo-400">${marginPct}%</strong></span></div></div>`;
    container.appendChild(card);
  });
  container.querySelectorAll(".btn-del-rec").forEach(btn=>btn.addEventListener("click",async()=>{
    if(!confirm("Xóa công thức này?")) return;
    try{await remove(ref(db,`${userDbRef}/recipes/${btn.dataset.id}`));}catch(e){alert("Lỗi xóa: "+e.message);}
  }));
  icons();
}

function maxServings(rec) {
  const bom=Array.isArray(rec.bom)?rec.bom:Object.values(rec.bom||{});
  if(!bom.length) return 0;
  let max=Infinity;
  for(const b of bom){
    const ing=inventoryData[b.ing_id], amount=Number(b.amount);
    if(!ing || amount<=0 || Number(ing.stock)<=0) return 0;
    max=Math.min(max,Math.floor(Number(ing.stock)/amount));
  }
  return Number.isFinite(max)?max:0;
}

function renderPosMenu() {
  const grid=$("pos-menu-grid"); if(!grid)return;
  grid.innerHTML="";
  if(!Object.keys(recipesData).length){grid.innerHTML=`<div class="col-span-2 text-center py-10 text-slate-500 text-xs">Chưa có công thức món. Hãy sang tab "Định Lượng Món" để thêm món.</div>`;return;}
  Object.entries(recipesData).forEach(([id,rec])=>{
    const available=maxServings(rec);
    const card=document.createElement("div");
    card.className="bg-slate-900 border border-slate-700/70 hover:border-indigo-500/50 p-3.5 rounded-xl flex justify-between items-center transition";
    card.innerHTML=`<div class="space-y-1"><span class="text-[10px] text-indigo-400 font-semibold uppercase">${esc(rec.category)}</span><h4 class="font-bold text-slate-100 text-sm">${esc(rec.dish_name)}</h4><p class="text-xs text-emerald-400 font-semibold">${money(rec.price)}</p><p class="text-[10px] ${available>0?'text-slate-400':'text-rose-400 font-semibold'}">${available>0?`Còn đủ chế biến: ${available} suất`:"Hết nguyên liệu kho!"}</p></div><button data-id="${esc(id)}" ${available===0?'disabled':''} class="btn-add-to-cart bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 p-2.5 rounded-lg text-white transition"><i data-lucide="plus" class="w-4 h-4"></i></button>`;
    grid.appendChild(card);
  });
  grid.querySelectorAll(".btn-add-to-cart").forEach(btn=>btn.addEventListener("click",()=>addToCart(btn.dataset.id)));
  icons();
}

function cartNeeded() {
  const needed={};
  for(const [recipeId,qty] of Object.entries(cart)){
    const rec=recipesData[recipeId]; if(!rec) continue;
    const bom=Array.isArray(rec.bom)?rec.bom:Object.values(rec.bom||{});
    bom.forEach(b=>needed[b.ing_id]=(needed[b.ing_id]||0)+Number(b.amount||0)*qty);
  }
  return needed;
}

function cartCanFit(recipeId, nextQty) {
  const needed={...cartNeeded()};
  const old=cart[recipeId]||0;
  const rec=recipesData[recipeId]; if(!rec)return false;
  const bom=Array.isArray(rec.bom)?rec.bom:Object.values(rec.bom||{});
  bom.forEach(b=>needed[b.ing_id]=(needed[b.ing_id]||0)-Number(b.amount||0)*old+Number(b.amount||0)*nextQty);
  return Object.entries(needed).every(([id,n])=>inventoryData[id] && Number(inventoryData[id].stock)>=n-1e-9);
}

function addToCart(id) {
  const next=(cart[id]||0)+1;
  if(!cartCanFit(id,next)) return alert("Số lượng vượt quá tồn kho hiện tại.");
  cart[id]=next; renderCart();
}

function renderCart() {
  const list=$("cart-list"), empty=$("cart-empty"), btn=$("btn-checkout");
  list.innerHTML="";
  const keys=Object.keys(cart).filter(id=>recipesData[id]);
  if(!keys.length){empty.classList.remove("hidden");btn.disabled=true;$("cart-total").textContent="0đ";return;}
  empty.classList.add("hidden");
  let total=0;
  keys.forEach(id=>{
    const rec=recipesData[id],qty=cart[id],itemTotal=Number(rec.price||0)*qty; total+=itemTotal;
    const el=document.createElement("div");
    el.className="flex justify-between items-center bg-slate-950/60 p-2 rounded-lg border border-slate-800 text-xs";
    el.innerHTML=`<div><p class="font-bold text-slate-200">${esc(rec.dish_name)}</p><p class="text-[10px] text-slate-400">${money(rec.price)} x ${qty}</p></div><div class="flex items-center gap-2"><span class="font-bold text-emerald-400">${money(itemTotal)}</span><div class="flex items-center bg-slate-800 rounded border border-slate-700"><button data-id="${esc(id)}" class="btn-dec-cart px-1.5 py-0.5">−</button><span class="px-1.5 font-bold">${qty}</span><button data-id="${esc(id)}" class="btn-inc-cart px-1.5 py-0.5">+</button></div></div>`;
    list.appendChild(el);
  });
  $("cart-total").textContent=money(total); btn.disabled=false;
  list.querySelectorAll(".btn-dec-cart").forEach(b=>b.addEventListener("click",()=>{const id=b.dataset.id;if(cart[id]>1)cart[id]--;else delete cart[id];renderCart();}));
  list.querySelectorAll(".btn-inc-cart").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.id)));
}

$("btn-checkout").addEventListener("click", async()=>{
  if(!userDbRef)return alert("Vui lòng đăng nhập!");
  const keys=Object.keys(cart); if(!keys.length)return;
  const needed=cartNeeded();
  const missing=[];
  for(const [id,n] of Object.entries(needed)){
    const ing=inventoryData[id];
    if(!ing || Number(ing.stock)<n-1e-9) missing.push(`- ${ing?.name||"N/A"}: cần ${n.toFixed(3)}, còn ${ing?.stock||0}`);
  }
  if(missing.length)return alert("Không thể hoàn tất đơn hàng do thiếu nguyên liệu:\n"+missing.join("\n"));
  const updates={};
  Object.entries(needed).forEach(([id,n])=>{
    const newStock=Number(inventoryData[id].stock)-n;
    updates[`${userDbRef}/inventory/${id}/stock`]=Number(newStock.toFixed(3));
  });
  const orderRef=push(ref(db,`${userDbRef}/orders`));
  const total=keys.reduce((sum,id)=>sum+Number(recipesData[id]?.price||0)*cart[id],0);
  const items=Object.fromEntries(keys.map(id=>[id,cart[id]]));
  updates[`${userDbRef}/orders/${orderRef.key}`]={timestamp:Date.now(),items,total};
  const btn=$("btn-checkout");btn.disabled=true;
  try{await update(ref(db),updates);alert("Thanh toán thành công! Tồn kho đã được trừ và đơn hàng đã được ghi nhận.");cart={};renderCart();}
  catch(err){alert("Lỗi khi thanh toán: "+err.message);renderCart();}
});

function orderCogs(order){
  let cogs=0;
  Object.entries(order.items||{}).forEach(([id,qty])=>{
    const rec=recipesData[id]; if(rec)cogs+=recipeCost(rec)*Number(qty||0);
  });
  return cogs;
}

function renderReports(){
  const tbody=$("orders-history-list");if(!tbody)return;
  tbody.innerHTML="";
  let revenue=0,cogs=0;
  const entries=Object.entries(ordersData).sort((a,b)=>(b[1]?.timestamp||0)-(a[1]?.timestamp||0));
  entries.forEach(([id,order])=>{
    const oc=orderCogs(order), rev=Number(order.total||0), profit=rev-oc; revenue+=rev;cogs+=oc;
    const summary=Object.entries(order.items||{}).map(([rid,qty])=>`${esc(recipesData[rid]?.dish_name||"Món đã xóa")} (x${Number(qty)||0})`).join(", ");
    const tr=document.createElement("tr");tr.className="hover:bg-slate-800/40 transition";
    tr.innerHTML=`<td class="p-2.5 md:p-3 text-slate-400 font-mono text-[11px]">${order.timestamp?new Date(order.timestamp).toLocaleString("vi-VN"):"---"}</td><td class="p-2.5 md:p-3 font-medium text-slate-200">${summary||"---"}</td><td class="p-2.5 md:p-3 text-right font-bold text-emerald-400">${money(rev)}</td><td class="p-2.5 md:p-3 text-right text-rose-400">${money(oc)}</td><td class="p-2.5 md:p-3 text-right font-bold ${profit>=0?"text-indigo-400":"text-rose-500"}">${money(profit)}</td><td class="p-2.5 md:p-3 text-center"><button data-id="${esc(id)}" class="btn-del-order text-slate-500 hover:text-rose-400"><i data-lucide="trash-2" class="w-4 h-4 inline"></i></button></td>`;
    tbody.appendChild(tr);
  });
  const profit=revenue-cogs, margin=revenue>0?(profit/revenue*100).toFixed(1):"0.0";
  $("kpi-revenue").textContent=money(revenue);$("kpi-cogs").textContent=money(cogs);$("kpi-profit").textContent=money(profit);$("kpi-margin").textContent=margin+"%";$("orders-count").textContent=`${entries.length} đơn hàng`;
  tbody.querySelectorAll(".btn-del-order").forEach(btn=>btn.addEventListener("click",async()=>{if(!confirm("Xóa bản ghi đơn hàng này? Lưu ý: xóa lịch sử không hoàn lại tồn kho."))return;try{await remove(ref(db,`${userDbRef}/orders/${btn.dataset.id}`));}catch(e){alert("Lỗi xóa: "+e.message);}}));
  icons();
}

addBomRow();
icons();
