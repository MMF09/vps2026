# F&B Smart Store & Inventory BOM

## Cấu trúc

- `index.html` — giao diện
- `css/app.css` — CSS bổ sung
- `js/app.js` — toàn bộ Firebase/Auth/POS/Kho/BOM/Báo cáo
- `firebase-database.rules.json` — Rules đề xuất cho Firebase Realtime Database

## Bug đã sửa

1. Tách HTML / CSS / JavaScript thành file riêng.
2. Sửa `appId` Firebase bị sai chuỗi escape trong đoạn code gốc.
3. Bỏ các dấu `\` xuất hiện do nội dung HTML bị escape khi copy.
4. Thêm cleanup Firebase listeners khi logout/đổi user để tránh listener cũ tiếp tục chạy.
5. Chuẩn hóa dữ liệu BOM để hỗ trợ cả Array và Object.
6. Escape dữ liệu người dùng trước khi đưa vào `innerHTML`, giảm rủi ro XSS.
7. Kiểm tra số lượng BOM > 0 và không cho trùng nguyên liệu trong cùng công thức.
8. Chặn thêm vào giỏ vượt tồn kho, kể cả khi nhiều món cùng dùng một nguyên liệu.
9. Checkout dùng multi-location `update()` như code gốc để trừ kho + tạo đơn trong cùng một lần ghi.
10. Sắp xếp lịch sử đơn theo thời gian mới nhất.
11. Không dùng giá vốn hiện tại để lưu vào đơn; báo cáo vẫn tính theo BOM hiện tại giống logic gốc.
12. Khi xóa đơn, không tự cộng lại kho vì đây là thao tác xóa lịch sử, tránh hoàn kho ngoài ý muốn.
13. Xử lý lỗi đăng nhập Firebase thân thiện hơn.
14. Fallback khi trình duyệt không cho Clipboard API.

## Firebase

Bật các phương thức Authentication mà bạn muốn dùng:
- Email/Password
- Google

Realtime Database nên dùng Rules trong `firebase-database.rules.json` để mỗi tài khoản chỉ đọc/ghi `users/<UID>` của chính mình.

## Chạy

Có thể mở qua local web server, ví dụ VS Code Live Server hoặc:

`python -m http.server 5500`

Sau đó truy cập `http://localhost:5500`.

Không nên mở `index.html` bằng `file://` nếu trình duyệt chặn module hoặc popup Firebase.

## Lưu ý

Firebase Web API key có thể xuất hiện trong frontend. Quyền bảo vệ dữ liệu phải nằm ở Firebase Authentication + Realtime Database Rules, không phải bằng cách giấu API key.
