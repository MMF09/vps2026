import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.14.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  set,
  get,
  push,
  remove
} from "https://www.gstatic.com/firebasejs/10.14.0/firebase-database.js";

// ========== Firebase config ==========
const firebaseConfig = {
  apiKey: "AIzaSyDsZ9Cgdjsj0N9iyKCC0GKF-WBmN-3ym6o",
  authDomain: "khoanchitrongngay.firebaseapp.com",
  databaseURL: "https://khoanchitrongngay-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "khoanchitrongngay",
  storageBucket: "khoanchitrongngay.firebasestorage.app",
  messagingSenderId: "939154018851",
  appId: "1:939154018851:web:dd060952995b477af91796"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// ========== Currencies ==========
const CURRENCIES = {
  VND: { name: "Việt Nam Đồng", flag: "🇻🇳" },
  USD: { name: "Đô la Mỹ", flag: "🇺🇸" },
  EUR: { name: "Euro", flag: "🇪🇺" },
  JPY: { name: "Yên Nhật", flag: "🇯🇵" },
  KRW: { name: "Won Hàn Quốc", flag: "🇰🇷" },
  CNY: { name: "Nhân dân tệ", flag: "🇨🇳" },
  GBP: { name: "Bảng Anh", flag: "🇬🇧" },
  THB: { name: "Baht Thái", flag: "🇹🇭" },
  SGD: { name: "Đô la Singapore", flag: "🇸🇬" },
  MYR: { name: "Ringgit Malaysia", flag: "🇲🇾" },
  IDR: { name: "Rupiah Indonesia", flag: "🇮🇩" },
  PHP: { name: "Peso Philippines", flag: "🇵🇭" },
  HKD: { name: "Đô la Hồng Kông", flag: "🇭🇰" },
  AUD: { name: "Đô la Úc", flag: "🇦🇺" },
  CAD: { name: "Đô la Canada", flag: "🇨🇦" },
  CHF: { name: "Franc Thụy Sĩ", flag: "🇨🇭" },
  INR: { name: "Rupee Ấn Độ", flag: "🇮🇳" }
};

// pairs: { "USD_VND": { from, to, rate, note, updatedAt }, ... }
let pairs = {};
let currentUser = null;

// ========== Theme ==========
function setTheme(name) {
  document.body.setAttribute("data-theme", name);
  document.querySelectorAll(".theme-dot").forEach((d) => {
    d.classList.toggle("active", d.dataset.theme === name);
  });
  localStorage.setItem("fx-theme", name);
}

document.querySelectorAll(".theme-dot").forEach((btn) => {
  btn.addEventListener("click", () => setTheme(btn.dataset.theme));
});

const savedTheme = localStorage.getItem("fx-theme");
if (savedTheme) setTheme(savedTheme);

// ========== Helpers ==========
function showToast(msg, type = "success") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className =
    "fixed top-4 right-4 z-50 px-5 py-3 rounded-xl shadow-lg text-white font-medium text-sm " +
    (type === "success" ? "bg-emerald-600" : "bg-red-500");
  // ensure visible styles without tailwind
  t.style.position = "fixed";
  t.style.top = "1rem";
  t.style.right = "1rem";
  t.style.zIndex = "9999";
  t.style.padding = "0.75rem 1.25rem";
  t.style.borderRadius = "0.75rem";
  t.style.color = "#fff";
  t.style.fontWeight = "500";
  t.style.fontSize = "0.875rem";
  t.style.boxShadow = "0 10px 15px -3px rgba(0,0,0,.15)";
  t.style.background = type === "success" ? "#059669" : "#ef4444";
  t.classList.remove("hidden");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add("hidden"), 3200);
}

function fmt(n, max = 4) {
  return Number(n).toLocaleString("vi-VN", { maximumFractionDigits: max });
}

function pairKey(from, to) {
  return from + "_" + to;
}

function userPath(sub) {
  return currentUser ? "users/" + currentUser.uid + "/" + sub : null;
}

function flag(code) {
  return (CURRENCIES[code] && CURRENCIES[code].flag) || code;
}

// ========== Populate selects ==========
function fillSelect(sel, prefer) {
  const prev = sel.value || prefer;
  sel.innerHTML = "";
  Object.keys(CURRENCIES).forEach((code) => {
    const opt = document.createElement("option");
    opt.value = code;
    opt.textContent =
      CURRENCIES[code].flag + " " + code + " – " + CURRENCIES[code].name;
    sel.appendChild(opt);
  });
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

function populateAllSelects() {
  fillSelect(document.getElementById("from-currency"), "USD");
  fillSelect(document.getElementById("to-currency"), "VND");
  fillSelect(document.getElementById("pair-from"), "USD");
  fillSelect(document.getElementById("pair-to"), "VND");
  updatePairLabel();
}

function updatePairLabel() {
  const from = document.getElementById("pair-from").value;
  const to = document.getElementById("pair-to").value;
  document.getElementById("pair-label").textContent =
    "1 " + from + " = ? " + to;
}

document.getElementById("pair-from").addEventListener("change", updatePairLabel);
document.getElementById("pair-to").addEventListener("change", updatePairLabel);

// ========== Swap buttons ==========
document.getElementById("swap-pair-btn").addEventListener("click", () => {
  const a = document.getElementById("pair-from");
  const b = document.getElementById("pair-to");
  const tmp = a.value;
  a.value = b.value;
  b.value = tmp;
  updatePairLabel();
  const rateInput = document.getElementById("pair-rate");
  if (rateInput.value && parseFloat(rateInput.value) > 0) {
    rateInput.value = (1 / parseFloat(rateInput.value))
      .toFixed(8)
      .replace(/\.?0+$/, "");
  }
});

document.getElementById("swap-convert-btn").addEventListener("click", () => {
  const a = document.getElementById("from-currency");
  const b = document.getElementById("to-currency");
  const tmp = a.value;
  a.value = b.value;
  b.value = tmp;
  convert();
});

// ========== Auth ==========
document.getElementById("email-login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const errEl = document.getElementById("login-error");
  errEl.classList.add("hidden");
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    errEl.textContent = [
      "auth/user-not-found",
      "auth/wrong-password",
      "auth/invalid-credential"
    ].includes(err.code)
      ? "Email hoặc mật khẩu không đúng."
      : err.message;
    errEl.classList.remove("hidden");
  }
});

document.getElementById("google-login-btn").addEventListener("click", async () => {
  const errEl = document.getElementById("login-error");
  errEl.classList.add("hidden");
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (err) {
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
  }
});

document.getElementById("logout-btn").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, async (user) => {
  currentUser = user;
  if (user) {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("app-screen").classList.remove("hidden");
    document.getElementById("user-email").textContent =
      user.email || user.displayName || "User";
    populateAllSelects();
    await loadPairs();
    loadConversionHistory();
    loadRateLog();
  } else {
    document.getElementById("login-screen").classList.remove("hidden");
    document.getElementById("app-screen").classList.add("hidden");
    pairs = {};
  }
});

// ========== Pairs CRUD ==========
async function loadPairs() {
  if (!currentUser) return;
  try {
    const snap = await get(ref(db, userPath("pairs")));
    pairs = snap.exists() ? snap.val() : {};
    // sanitize: ensure each entry has from/to
    Object.keys(pairs).forEach((k) => {
      if (!pairs[k].from || !pairs[k].to) {
        const parts = k.split("_");
        if (parts.length === 2) {
          pairs[k].from = pairs[k].from || parts[0];
          pairs[k].to = pairs[k].to || parts[1];
        }
      }
    });
    renderPairsList();
    updateAvailablePairsHint();
    convert();
  } catch (err) {
    console.error(err);
    showToast("Lỗi tải cặp: " + err.message, "error");
  }
}

function renderPairsList() {
  const list = document.getElementById("pairs-list");
  const keys = Object.keys(pairs);
  document.getElementById("pair-count").textContent = keys.length
    ? "(" + keys.length + ")"
    : "";

  if (keys.length === 0) {
    list.innerHTML =
      '<p class="text-gray-400 text-sm py-4 text-center">Chưa có cặp nào. Hãy nhập cặp đầu tiên ở trên.</p>';
    return;
  }

  keys.sort((a, b) => a.localeCompare(b));
  list.innerHTML = "";

  keys.forEach((key) => {
    const p = pairs[key];
    const div = document.createElement("div");
    div.className = "pair-card";
    div.innerHTML = `
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-semibold text-gray-900" style="font-size:1rem">
              ${flag(p.from)} ${p.from}
              <span class="text-gray-400" style="margin:0 .25rem">→</span>
              ${flag(p.to)} ${p.to}
            </span>
            <span class="badge-manual">TAY</span>
          </div>
          <p class="font-bold mt-1" style="color:var(--accent);font-size:1.125rem">
            1 ${p.from} = ${fmt(p.rate, 6)} ${p.to}
          </p>
          <p class="text-xs text-gray-400 mt-1">
            Ngược: 1 ${p.to} ≈ ${fmt(1 / p.rate, 6)} ${p.from}
            ${p.note ? " · " + escapeHtml(p.note) : ""}
          </p>
          <p class="text-xs text-gray-400">${p.updatedAt ? new Date(p.updatedAt).toLocaleString("vi-VN") : ""}</p>
        </div>
        <div class="flex gap-2">
          <button data-key="${key}" class="use-pair-btn btn-use">Dùng quy đổi</button>
          <button data-key="${key}" class="delete-pair-btn btn-link-danger">Xóa</button>
        </div>
      </div>
    `;
    list.appendChild(div);
  });

  list.querySelectorAll(".delete-pair-btn").forEach((btn) => {
    btn.addEventListener("click", () => deletePair(btn.dataset.key));
  });
  list.querySelectorAll(".use-pair-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const p = pairs[btn.dataset.key];
      if (!p) return;
      document.getElementById("from-currency").value = p.from;
      document.getElementById("to-currency").value = p.to;
      document.querySelector('[data-tab="converter"]').click();
      convert();
    });
  });
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}

function updateAvailablePairsHint() {
  const el = document.getElementById("available-pairs-hint");
  const keys = Object.keys(pairs);
  if (keys.length === 0) {
    el.innerHTML =
      '<span class="text-gray-400">Chưa có cặp nào. Vào tab “Nhập cặp tỷ giá”.</span>';
    return;
  }
  el.innerHTML = keys
    .map((k) => {
      const p = pairs[k];
      return (
        '<span class="pair-chip">' +
        flag(p.from) +
        " " +
        p.from +
        " → " +
        flag(p.to) +
        " " +
        p.to +
        ' <span class="rate">(' +
        fmt(p.rate, 2) +
        ")</span></span>"
      );
    })
    .join("");
}

async function savePair(from, to, rate, note, alsoInverse) {
  if (!currentUser) return false;
  if (from === to) {
    showToast("Hai loại tiền phải khác nhau", "error");
    return false;
  }
  if (!rate || rate <= 0 || !isFinite(rate)) {
    showToast("Tỷ giá phải > 0", "error");
    return false;
  }

  const key = pairKey(from, to);
  const old = pairs[key];
  const payload = {
    from: from,
    to: to,
    rate: Number(rate),
    note: note || "",
    updatedAt: new Date().toISOString(),
    updatedBy: currentUser.email || currentUser.uid
  };

  try {
    await set(ref(db, userPath("pairs/" + key)), payload);

    await push(ref(db, userPath("rate_change_history")), {
      pairKey: key,
      from: from,
      to: to,
      oldRate: old ? old.rate : null,
      newRate: payload.rate,
      note: payload.note,
      changedAt: payload.updatedAt,
      changedBy: payload.updatedBy
    });

    pairs[key] = payload;

    if (alsoInverse) {
      const invKey = pairKey(to, from);
      const invRate = 1 / payload.rate;
      const invPayload = {
        from: to,
        to: from,
        rate: invRate,
        note: note ? "Ngược của: " + note : "Tự động từ chiều ngược",
        updatedAt: payload.updatedAt,
        updatedBy: payload.updatedBy,
        isInverse: true
      };
      await set(ref(db, userPath("pairs/" + invKey)), invPayload);
      pairs[invKey] = invPayload;
    }

    renderPairsList();
    updateAvailablePairsHint();
    convert();
    return true;
  } catch (err) {
    console.error(err);
    showToast("Lỗi lưu: " + err.message, "error");
    return false;
  }
}

document.getElementById("save-pair-btn").addEventListener("click", async () => {
  const from = document.getElementById("pair-from").value;
  const to = document.getElementById("pair-to").value;
  const rate = parseFloat(document.getElementById("pair-rate").value);
  const note = document.getElementById("pair-note").value.trim();
  const ok = await savePair(from, to, rate, note, false);
  if (ok) {
    showToast("Đã lưu: 1 " + from + " = " + fmt(rate, 6) + " " + to);
    document.getElementById("pair-rate").value = "";
    document.getElementById("pair-note").value = "";
    loadRateLog();
  }
});

document
  .getElementById("save-both-directions-btn")
  .addEventListener("click", async () => {
    const from = document.getElementById("pair-from").value;
    const to = document.getElementById("pair-to").value;
    const rate = parseFloat(document.getElementById("pair-rate").value);
    const note = document.getElementById("pair-note").value.trim();
    const ok = await savePair(from, to, rate, note, true);
    if (ok) {
      showToast("Đã lưu cả 2 chiều: " + from + "↔" + to);
      document.getElementById("pair-rate").value = "";
      document.getElementById("pair-note").value = "";
      loadRateLog();
    }
  });

async function deletePair(key) {
  if (!currentUser || !confirm("Xóa cặp " + key.replace("_", " → ") + "?"))
    return;
  try {
    await remove(ref(db, userPath("pairs/" + key)));
    delete pairs[key];
    renderPairsList();
    updateAvailablePairsHint();
    convert();
    showToast("Đã xóa cặp");
  } catch (err) {
    showToast(err.message, "error");
  }
}

// ========== Conversion ==========
function findRate(from, to) {
  if (from === to) return { rate: 1, source: "same", pairKey: null };

  const directKey = pairKey(from, to);
  if (pairs[directKey]) {
    return {
      rate: pairs[directKey].rate,
      source: "direct",
      pairKey: directKey,
      pair: pairs[directKey]
    };
  }

  const invKey = pairKey(to, from);
  if (pairs[invKey]) {
    return {
      rate: 1 / pairs[invKey].rate,
      source: "inverse",
      pairKey: invKey,
      pair: pairs[invKey]
    };
  }

  return null;
}

function convert() {
  const amount = parseFloat(document.getElementById("amount-input").value) || 0;
  const from = document.getElementById("from-currency").value;
  const to = document.getElementById("to-currency").value;
  const resultEl = document.getElementById("convert-result");
  const rateEl = document.getElementById("convert-rate");
  const infoEl = document.getElementById("convert-pair-info");

  const found = findRate(from, to);
  if (!found) {
    resultEl.textContent = "—";
    rateEl.textContent = "";
    infoEl.textContent =
      "Chưa có cặp " +
      from +
      " → " +
      to +
      " (hoặc chiều ngược). Hãy nhập cặp này ở tab “Nhập cặp tỷ giá”.";
    return;
  }

  const result = amount * found.rate;
  resultEl.textContent = fmt(result, 4) + " " + to;
  rateEl.textContent = "1 " + from + " = " + fmt(found.rate, 8) + " " + to;

  if (found.source === "direct") {
    infoEl.textContent =
      "Dùng cặp đã nhập: " +
      found.pair.from +
      " → " +
      found.pair.to +
      " = " +
      fmt(found.pair.rate, 6);
  } else if (found.source === "inverse") {
    infoEl.textContent =
      "Dùng chiều ngược của cặp đã nhập: " +
      found.pair.from +
      " → " +
      found.pair.to +
      " = " +
      fmt(found.pair.rate, 6) +
      " (lấy 1/rate)";
  } else {
    infoEl.textContent = "";
  }
}

["amount-input", "from-currency", "to-currency"].forEach((id) => {
  document.getElementById(id).addEventListener("input", convert);
  document.getElementById(id).addEventListener("change", convert);
});

// ========== Save conversion ==========
document
  .getElementById("save-conversion-btn")
  .addEventListener("click", async () => {
    if (!currentUser) return;
    const amount =
      parseFloat(document.getElementById("amount-input").value) || 0;
    const from = document.getElementById("from-currency").value;
    const to = document.getElementById("to-currency").value;
    const resultText = document.getElementById("convert-result").textContent;
    const rateText = document.getElementById("convert-rate").textContent;
    const found = findRate(from, to);

    if (!found || resultText === "—" || amount <= 0) {
      showToast("Chưa có kết quả hợp lệ", "error");
      return;
    }

    const entry = {
      amount: amount,
      from: from,
      to: to,
      rate: found.rate,
      result: amount * found.rate,
      resultText: resultText,
      rateText: rateText,
      source: found.source,
      pairKey: found.pairKey,
      savedAt: new Date().toISOString(),
      savedBy: currentUser.email || currentUser.uid
    };

    try {
      await push(ref(db, userPath("conversion_history")), entry);
      showToast("Đã lưu giao dịch quy đổi");
      loadConversionHistory();
    } catch (err) {
      showToast(err.message, "error");
    }
  });

// ========== Histories ==========
async function loadConversionHistory() {
  const list = document.getElementById("conv-history-list");
  if (!currentUser) return;
  list.innerHTML =
    '<p class="text-gray-400 text-center py-6">Đang tải...</p>';
  try {
    const snap = await get(ref(db, userPath("conversion_history")));
    if (!snap.exists()) {
      list.innerHTML =
        '<p class="text-gray-400 text-center py-8">Chưa có giao dịch.</p>';
      return;
    }
    const entries = Object.entries(snap.val())
      .map(([id, v]) => Object.assign({ id: id }, v))
      .sort((a, b) => (b.savedAt || "").localeCompare(a.savedAt || ""));
    list.innerHTML = "";
    entries.forEach((item) => {
      const div = document.createElement("div");
      div.className = "pair-card";
      div.innerHTML = `
        <div class="flex justify-between items-start gap-3">
          <div>
            <p class="font-semibold text-gray-800">
              ${fmt(item.amount)} ${flag(item.from)} ${item.from}
              <span style="color:var(--accent);margin:0 .25rem">→</span>
              ${item.resultText || fmt(item.result) + " " + item.to}
            </p>
            <p class="text-sm text-gray-500 mt-1">${item.rateText || ""}</p>
            <p class="text-xs text-gray-400 mt-1">
              ${item.source === "inverse" ? "↩ chiều ngược · " : ""}
              ${item.savedAt ? new Date(item.savedAt).toLocaleString("vi-VN") : ""}
            </p>
          </div>
          <button data-id="${item.id}" class="delete-conv-btn btn-link-danger">Xóa</button>
        </div>
      `;
      list.appendChild(div);
    });
    list.querySelectorAll(".delete-conv-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Xóa giao dịch này?")) return;
        try {
          await remove(
            ref(db, userPath("conversion_history/" + btn.dataset.id))
          );
          loadConversionHistory();
          showToast("Đã xóa");
        } catch (e) {
          showToast(e.message, "error");
        }
      });
    });
  } catch (err) {
    list.innerHTML =
      '<p class="text-red-500 text-center py-6">' + err.message + "</p>";
  }
}

async function loadRateLog() {
  const list = document.getElementById("rate-log-list");
  if (!currentUser) return;
  list.innerHTML =
    '<p class="text-gray-400 text-center py-6">Đang tải...</p>';
  try {
    const snap = await get(ref(db, userPath("rate_change_history")));
    if (!snap.exists()) {
      list.innerHTML =
        '<p class="text-gray-400 text-center py-8">Chưa có thay đổi.</p>';
      return;
    }
    const entries = Object.entries(snap.val())
      .map(([id, v]) => Object.assign({ id: id }, v))
      .sort((a, b) => (b.changedAt || "").localeCompare(a.changedAt || ""));
    list.innerHTML = "";
    entries.forEach((item) => {
      const oldStr = item.oldRate != null ? fmt(item.oldRate, 6) : "—";
      const div = document.createElement("div");
      div.className = "pair-card";
      div.innerHTML = `
        <p class="font-semibold text-gray-800">
          ${flag(item.from)} ${item.from} → ${flag(item.to)} ${item.to}
        </p>
        <p class="text-sm mt-1">
          <span class="text-red-500 line-through">${oldStr}</span>
          <span style="margin:0 .375rem">→</span>
          <span class="font-semibold" style="color:var(--accent)">${fmt(item.newRate, 6)}</span>
        </p>
        ${item.note ? '<p class="text-xs text-gray-500 mt-1">' + escapeHtml(item.note) + "</p>" : ""}
        <p class="text-xs text-gray-400 mt-1">${item.changedAt ? new Date(item.changedAt).toLocaleString("vi-VN") : ""}</p>
      `;
      list.appendChild(div);
    });
  } catch (err) {
    list.innerHTML =
      '<p class="text-red-500 text-center py-6">' + err.message + "</p>";
  }
}

document
  .getElementById("load-conv-history-btn")
  .addEventListener("click", loadConversionHistory);
document
  .getElementById("load-rate-log-btn")
  .addEventListener("click", loadRateLog);

// ========== Tabs ==========
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => {
      b.classList.remove("tab-active");
      b.classList.add("tab-inactive");
    });
    btn.classList.remove("tab-inactive");
    btn.classList.add("tab-active");
    document.querySelectorAll(".tab-content").forEach((c) =>
      c.classList.add("hidden")
    );
    document
      .getElementById("tab-" + btn.dataset.tab)
      .classList.remove("hidden");
  });
});
