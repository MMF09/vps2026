# Tỷ Giá Cặp Tiền Tệ

Website đăng nhập (Email + Google, không đăng ký công khai) để:

- Nhập **cặp tỷ giá** thủ công (USD→VND, USD→JPY, EUR→KRW…)
- Hoán đổi 2 chiều (nút ⇄)
- Quy đổi & lưu lịch sử theo từng user
- Chọn màu accent: xanh dương / xanh lá / đỏ

## Cấu trúc file

```
currency-app/
├── index.html          # HTML thuần
├── styles.css          # CSS (theme, layout, components)
├── app.js              # Logic Firebase + UI (ES module)
├── favicon.svg
├── database.rules.json # Rules bảo mật Realtime Database
└── README.md
```

## Firebase Rules (bắt buộc)

Vào **Firebase Console → Realtime Database → Rules** và paste toàn bộ nội dung `database.rules.json`.

Rules đảm bảo:

- Chỉ user đã đăng nhập mới đọc/ghi
- Mỗi user **chỉ** truy cập được `users/{uid}/...` của chính mình
- Validate: rate > 0, from ≠ to

## Cách chạy

Cần static server (module ES không chạy file://):

```bash
cd currency-app
npx serve .
# hoặc
python3 -m http.server 5500
```

Mở `http://localhost:3000` (hoặc port tương ứng).

## Cấu hình Firebase

1. Authentication → Sign-in method: bật **Email/Password** + **Google**
2. Realtime Database: tạo DB (region `asia-southeast1`) + paste rules
3. Authorized domains: thêm domain deploy + `localhost`
4. Tạo user email đầu tiên (Console → Authentication → Users → Add user)

## Cấu trúc dữ liệu

```
users/{uid}/
  pairs/
    USD_VND: { from, to, rate, note, updatedAt, updatedBy }
  conversion_history/
    {pushId}: { amount, from, to, rate, result, savedAt, ... }
  rate_change_history/
    {pushId}: { from, to, oldRate, newRate, changedAt, ... }
```
