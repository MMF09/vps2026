// Firebase config (same project as Android app)
const firebaseConfig = {
  apiKey: "AIzaSyCvMzAs3etL30t9-hZa-jVPDTQQorq0ouU",
  authDomain: "ptptt-pcpc.firebaseapp.com",
  databaseURL: "https://ptptt-pcpc-default-rtdb.firebaseio.com",
  projectId: "ptptt-pcpc",
  storageBucket: "ptptt-pcpc.firebasestorage.app",
  messagingSenderId: "334612619008",
  appId: "1:334612619008:web:locationmap"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const database = firebase.database();

// Chỉ cho phép đăng nhập tài khoản này
const ALLOWED_EMAIL = "ducgiang385@gmail.com";

// DOM
const loginScreen = document.getElementById("login-screen");
const mainScreen = document.getElementById("main-screen");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const confirmInput = document.getElementById("confirm-password");
const confirmGroup = document.getElementById("confirm-group");
const btnLogin = document.getElementById("btn-login");
const btnToggleMode = document.getElementById("btn-toggle-mode");
const loginLoading = document.getElementById("login-loading");
const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");
const confirmError = document.getElementById("confirm-error");

const mapEl = document.getElementById("map");
const hintEl = document.getElementById("hint");
const bottomSheet = document.getElementById("bottom-sheet");
const locationList = document.getElementById("location-list");
const emptyList = document.getElementById("empty-list");
const modalOverlay = document.getElementById("modal-overlay");
const locNameInput = document.getElementById("loc-name");
const locLatInput = document.getElementById("loc-lat");
const locLngInput = document.getElementById("loc-lng");
const toastEl = document.getElementById("toast");

let isRegisterMode = false;
let map = null;
let markers = {};
let locationsListener = null;
let pendingLat = null;
let pendingLng = null;
let myLocationMarker = null;
let userLocationWatchId = null;

// ===== Auth state =====
auth.onAuthStateChanged((user) => {
  if (user) {
    // Kiểm tra email được phép
    if (user.email && user.email.toLowerCase() !== ALLOWED_EMAIL.toLowerCase()) {
      auth.signOut();
      showToast("Chỉ tài khoản " + ALLOWED_EMAIL + " được phép đăng nhập.");
      showLogin();
      return;
    }
    showMain();
  } else {
    showLogin();
  }
});

function showLogin() {
  loginScreen.style.display = "flex";
  mainScreen.style.display = "none";
  if (map) {
    map.remove();
    map = null;
  }
  if (locationsListener) {
    locationsListener.off();
    locationsListener = null;
  }
  stopWatchLocation();
}

function showMain() {
  loginScreen.style.display = "none";
  mainScreen.style.display = "block";
  initMap();
  observeLocations();
  requestLocation();
}

// ===== Login / Register =====
btnToggleMode.addEventListener("click", () => {
  isRegisterMode = !isRegisterMode;
  updateLoginUI();
});

function updateLoginUI() {
  if (isRegisterMode) {
    confirmGroup.style.display = "block";
    btnLogin.textContent = "Đăng ký";
    btnToggleMode.textContent = "Đã có tài khoản? Đăng nhập";
  } else {
    confirmGroup.style.display = "none";
    btnLogin.textContent = "Đăng nhập";
    btnToggleMode.textContent = "Chưa có tài khoản? Đăng ký";
  }
  clearErrors();
}

function clearErrors() {
  emailError.textContent = "";
  passwordError.textContent = "";
  confirmError.textContent = "";
}

function validate(email, password) {
  clearErrors();
  let ok = true;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    emailError.textContent = "Email không hợp lệ";
    ok = false;
  }
  if (!password || password.length < 6) {
    passwordError.textContent = "Mật khẩu phải có ít nhất 6 ký tự";
    ok = false;
  }
  return ok;
}

btnLogin.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!validate(email, password)) return;

  // Giới hạn chỉ tài khoản được phép
  if (email.toLowerCase() !== ALLOWED_EMAIL.toLowerCase()) {
    emailError.textContent = "Chỉ tài khoản " + ALLOWED_EMAIL + " được phép.";
    showToast("Chỉ tài khoản " + ALLOWED_EMAIL + " được phép đăng nhập.");
    return;
  }

  if (isRegisterMode) {
    const confirm = confirmInput.value;
    if (password !== confirm) {
      confirmError.textContent = "Mật khẩu không khớp";
      return;
    }
    await doRegister(email, password);
  } else {
    await doLogin(email, password);
  }
});

async function doLogin(email, password) {
  setLoading(true);
  try {
    await auth.signInWithEmailAndPassword(email, password);
    // onAuthStateChanged sẽ xử lý
  } catch (e) {
    const msg = friendlyAuthError(e);
    showToast(msg);
  } finally {
    setLoading(false);
  }
}

async function doRegister(email, password) {
  setLoading(true);
  try {
    await auth.createUserWithEmailAndPassword(email, password);
    showToast("Đăng ký thành công! Vui lòng đăng nhập.");
    isRegisterMode = false;
    updateLoginUI();
    passwordInput.value = "";
    confirmInput.value = "";
    // Đăng xuất ngay để user đăng nhập lại (giống app gốc)
    await auth.signOut();
  } catch (e) {
    const msg = friendlyAuthError(e);
    showToast(msg);
  } finally {
    setLoading(false);
  }
}

function setLoading(show) {
  loginLoading.style.display = show ? "flex" : "none";
  btnLogin.disabled = show;
  btnToggleMode.disabled = show;
}

function friendlyAuthError(e) {
  const m = (e && e.message) || "";
  const code = (e && e.code) || "";
  if (code === "auth/wrong-password" || m.includes("password")) return "Sai mật khẩu";
  if (code === "auth/user-not-found" || m.includes("no user")) return "Email chưa đăng ký";
  if (code === "auth/email-already-in-use" || m.includes("already")) return "Email đã được sử dụng";
  if (code === "auth/network-request-failed" || m.includes("network")) return "Không có mạng";
  if (code === "auth/invalid-email") return "Email không hợp lệ";
  if (code === "auth/invalid-credential") return "Sai email hoặc mật khẩu";
  return m || "Lỗi đăng nhập";
}

// ===== Logout =====
document.getElementById("btn-logout").addEventListener("click", async () => {
  try {
    await auth.signOut();
  } catch (e) {
    showToast("Lỗi đăng xuất");
  }
});

// ===== Map (Leaflet + OSM) =====
function initMap() {
  if (map) return;

  map = L.map("map", {
    center: [21.0285, 105.8542], // Hà Nội
    zoom: 14,
    zoomControl: true,
    attributionControl: true
  });

  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(map);

  // Long-press to add location
  let pressTimer = null;
  let pressLatLng = null;

  map.on("mousedown", (e) => {
    pressLatLng = e.latlng;
    pressTimer = setTimeout(() => {
      if (pressLatLng) {
        showAddDialog(pressLatLng.lat, pressLatLng.lng);
      }
    }, 600);
  });

  map.on("mouseup mouseout", () => {
    clearTimeout(pressTimer);
    pressTimer = null;
  });

  // Touch long-press
  map.on("touchstart", (e) => {
    if (e.originalEvent.touches.length !== 1) return;
    const touch = e.originalEvent.touches[0];
    const point = map.mouseEventToLatLng(touch);
    pressLatLng = point;
    pressTimer = setTimeout(() => {
      if (pressLatLng) {
        showAddDialog(pressLatLng.lat, pressLatLng.lng);
      }
    }, 600);
  });

  map.on("touchend touchmove", () => {
    clearTimeout(pressTimer);
    pressTimer = null;
  });

  // Context menu (right-click) also works
  map.on("contextmenu", (e) => {
    e.originalEvent.preventDefault();
    showAddDialog(e.latlng.lat, e.latlng.lng);
  });

  setTimeout(() => map.invalidateSize(), 100);
}

// ===== Location (GPS) =====
function requestLocation() {
  if (!navigator.geolocation) {
    showToast("Trình duyệt không hỗ trợ định vị");
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      updateMyLocationMarker(lat, lng);
    },
    (err) => {
      console.warn("Geolocation error", err);
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
  );

  // Watch for continuous update
  if (userLocationWatchId == null) {
    userLocationWatchId = navigator.geolocation.watchPosition(
      (pos) => {
        updateMyLocationMarker(pos.coords.latitude, pos.coords.longitude);
      },
      () => {},
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
    );
  }
}

function stopWatchLocation() {
  if (userLocationWatchId != null) {
    navigator.geolocation.clearWatch(userLocationWatchId);
    userLocationWatchId = null;
  }
}

function updateMyLocationMarker(lat, lng) {
  if (!map) return;
  if (myLocationMarker) {
    myLocationMarker.setLatLng([lat, lng]);
  } else {
    const icon = L.divIcon({
      className: "custom-marker",
      html: `<div style="width:16px;height:16px;background:#4285F4;border:3px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,0.4);"></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    });
    myLocationMarker = L.marker([lat, lng], { icon, zIndexOffset: 1000 }).addTo(map);
  }
}

document.getElementById("fab-my-location").addEventListener("click", () => {
  if (!navigator.geolocation) {
    showToast("Trình duyệt không hỗ trợ định vị");
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      updateMyLocationMarker(lat, lng);
      if (map) {
        map.flyTo([lat, lng], 17);
      }
    },
    () => showToast("Không lấy được vị trí. Bật GPS và thử lại."),
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

document.getElementById("fab-add").addEventListener("click", () => {
  if (!navigator.geolocation) {
    showToast("Trình duyệt không hỗ trợ định vị");
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      showAddDialog(pos.coords.latitude, pos.coords.longitude);
    },
    () => showToast("Không lấy được vị trí. Bật GPS và thử lại."),
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

// ===== Bottom sheet =====
document.getElementById("btn-list").addEventListener("click", () => {
  bottomSheet.style.display = bottomSheet.style.display === "none" ? "flex" : "none";
});

document.getElementById("btn-close-sheet").addEventListener("click", () => {
  bottomSheet.style.display = "none";
});

hintEl.addEventListener("click", () => {
  hintEl.style.display = "none";
});

// ===== Add location dialog =====
function showAddDialog(lat, lng) {
  pendingLat = Number(lat.toFixed(7));
  pendingLng = Number(lng.toFixed(7));
  locNameInput.value = "Vị trí hiện tại";
  locLatInput.value = pendingLat.toFixed(6);
  locLngInput.value = pendingLng.toFixed(6);
  modalOverlay.style.display = "flex";
  locNameInput.focus();
}

document.getElementById("btn-cancel-save").addEventListener("click", () => {
  modalOverlay.style.display = "none";
});

document.getElementById("btn-save-loc").addEventListener("click", async () => {
  const name = locNameInput.value.trim() || "Vị trí";
  const lat = parseFloat(locLatInput.value);
  const lng = parseFloat(locLngInput.value);

  if (!name) {
    showToast("Nhập tên vị trí");
    return;
  }
  if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    showToast("Tọa độ không hợp lệ");
    return;
  }

  modalOverlay.style.display = "none";
  await saveLocation(name, lat, lng);
});

// ===== Firebase: save / delete / observe =====
// Cấu trúc giống app Android: users/{uid}/locations/{id}
function userLocationsRef() {
  const user = auth.currentUser;
  if (!user) return null;
  return database.ref("users/" + user.uid + "/locations");
}

async function saveLocation(name, lat, lng) {
  const user = auth.currentUser;
  if (!user) {
    showToast("Chưa đăng nhập. Đăng xuất rồi đăng nhập lại.");
    return;
  }

  if (user.email && user.email.toLowerCase() !== ALLOWED_EMAIL.toLowerCase()) {
    showToast("Không có quyền.");
    return;
  }

  const ref = userLocationsRef();
  if (!ref) {
    showToast("Không lấy được đường dẫn lưu.");
    return;
  }

  try {
    const newRef = ref.push();
    const key = newRef.key;
    const data = {
      id: key,
      name: name || "Vị trí",
      latitude: lat,
      longitude: lng,
      userId: user.uid,
      userEmail: user.email || "",
      timestamp: Date.now()
    };

    await newRef.set(data);
    showToast("Đã lưu: " + name + " (" + lat + ", " + lng + ")");
    if (map) {
      map.flyTo([lat, lng], 16);
    }
  } catch (e) {
    console.error(e);
    const msg = friendlyDbError(e);
    showToast("Lỗi lưu: " + msg);
  }
}

async function deleteLocation(id) {
  if (!id) return;
  const ref = userLocationsRef();
  if (!ref) {
    showToast("Chưa đăng nhập");
    return;
  }
  try {
    await ref.child(id).remove();
  } catch (e) {
    showToast("Lỗi xóa: " + (e.message || e));
  }
}

function observeLocations() {
  const user = auth.currentUser;
  if (!user) return;

  const ref = database.ref("users/" + user.uid + "/locations");
  if (locationsListener) {
    locationsListener.off();
  }
  locationsListener = ref;

  ref.on("value", (snapshot) => {
    const list = [];
    snapshot.forEach((child) => {
      const item = parseLocation(child);
      if (item) list.push(item);
    });
    list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    renderList(list);
    updateMarkers(list);
  }, (err) => {
    console.error("observe error", err);
    showToast("Lỗi tải danh sách");
  });
}

function parseLocation(child) {
  try {
    const val = child.val() || {};
    const id = val.id || child.key;
    const name = val.name || "Vị trí";
    const lat = readDouble(val.latitude);
    const lng = readDouble(val.longitude);
    if (lat == null || lng == null) return null;
    if (lat === 0 && lng === 0) return null;
    return {
      id,
      name,
      latitude: lat,
      longitude: lng,
      userId: val.userId || "",
      userEmail: val.userEmail || "",
      timestamp: val.timestamp || 0
    };
  } catch (e) {
    return null;
  }
}

function readDouble(v) {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const n = parseFloat(v);
    return isNaN(n) ? null : n;
  }
  return null;
}

function friendlyDbError(e) {
  const m = (e && e.message) || "";
  if (m.includes("Permission denied") || m.includes("PERMISSION_DENIED")) {
    return "Không có quyền ghi. Kiểm tra đã đăng nhập và Firebase Rules.";
  }
  if (m.includes("network") || m.includes("Unable to resolve")) {
    return "Không có mạng. Kiểm tra Internet.";
  }
  if (m.includes("timeout") || m.includes("timed out")) {
    return "Hết thời gian chờ. Thử lại.";
  }
  return m || "Lỗi cơ sở dữ liệu";
}

// ===== UI list & markers =====
function renderList(list) {
  locationList.innerHTML = "";
  if (!list.length) {
    emptyList.style.display = "block";
    return;
  }
  emptyList.style.display = "none";

  list.forEach((item) => {
    const li = document.createElement("li");
    li.className = "location-item";
    li.innerHTML = `
      <div class="info">
        <div class="name">${escapeHtml(item.name)}</div>
        <div class="coords">${item.latitude.toFixed(5)}, ${item.longitude.toFixed(5)}</div>
      </div>
      <button class="btn-delete" title="Xóa">
        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
      </button>
    `;
    li.querySelector(".info").addEventListener("click", () => {
      if (map) {
        map.flyTo([item.latitude, item.longitude], 17);
        bottomSheet.style.display = "none";
      }
    });
    li.querySelector(".btn-delete").addEventListener("click", (e) => {
      e.stopPropagation();
      if (confirm('Xóa "' + item.name + '"?')) {
        deleteLocation(item.id);
      }
    });
    locationList.appendChild(li);
  });
}

function updateMarkers(list) {
  if (!map) return;

  const currentIds = new Set(list.map((i) => i.id));

  // Remove old
  Object.keys(markers).forEach((id) => {
    if (!currentIds.has(id)) {
      map.removeLayer(markers[id]);
      delete markers[id];
    }
  });

  // Add new
  list.forEach((item) => {
    if (!markers[item.id]) {
      const icon = L.divIcon({
        className: "custom-marker",
        html: `<svg width="32" height="40" viewBox="0 0 24 30" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 0C5.4 0 0 5.4 0 12c0 9 12 18 12 18s12-9 12-18C24 5.4 18.6 0 12 0z" fill="#E53935"/>
          <circle cx="12" cy="12" r="5" fill="#fff"/>
        </svg>`,
        iconSize: [32, 40],
        iconAnchor: [16, 40],
        popupAnchor: [0, -36]
      });
      const marker = L.marker([item.latitude, item.longitude], { icon })
        .addTo(map)
        .bindPopup(`<b>${escapeHtml(item.name)}</b><br>${item.latitude.toFixed(5)}, ${item.longitude.toFixed(5)}`);
      markers[item.id] = marker;
    }
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ===== Toast =====
let toastTimer = null;
function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastEl.style.display = "none";
  }, 3000);
}

// Enter key on login
passwordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") btnLogin.click();
});
confirmInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") btnLogin.click();
});
