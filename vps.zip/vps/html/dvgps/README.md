# OSM Location – Web

Phiên bản web (HTML/CSS/JS) chuyển thể từ app Android OSM Location.

## Tính năng giữ nguyên logic Firebase

- Đăng nhập / Đăng ký Firebase Auth (Email/Password)
- **Chỉ cho phép đăng nhập tài khoản: `ducgiang385@gmail.com`**
- Bản đồ OpenStreetMap (Leaflet)
- Lấy vị trí GPS (Geolocation API)
- Thêm vị trí: long-press / chuột phải trên bản đồ hoặc nút +
- Lưu vào Firebase Realtime Database theo đúng cấu trúc:
  ```
  users/{uid}/locations/{id}
    id, name, latitude, longitude, userId, userEmail, timestamp
  ```
- Danh sách vị trí + xóa
- Favicon (icon web)

## Cách chạy

1. Mở thư mục `web-app` bằng web server tĩnh (không mở trực tiếp file:// vì CORS/Firebase):
   ```bash
   # Ví dụ với Python
   cd web-app
   python3 -m http.server 8080
   ```
2. Truy cập: http://localhost:8080

Hoặc deploy lên Firebase Hosting / Netlify / Vercel / bất kỳ static host nào.

## Firebase

- Project: `ptptt-pcpc`
- Database URL: `https://ptptt-pcpc-default-rtdb.firebaseio.com`
- Cần bật Email/Password trong Firebase Authentication
- Rules (giống app Android):

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    }
  }
}
```

## Lưu ý

- Trình duyệt cần cấp quyền **Vị trí** để dùng GPS.
- Chỉ email `ducgiang385@gmail.com` mới đăng nhập / đăng ký được (kiểm tra cả phía client).
