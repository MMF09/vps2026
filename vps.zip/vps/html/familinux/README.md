# DumuCTime · Linux Command Vault

Ứng dụng web lưu trữ & tra cứu lệnh Linux theo distro.

## Rules Firebase (bắt buộc dùng)

Dán đúng rules sau vào **Realtime Database → Rules**:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid"
      }
    }
  }
}
```

Dữ liệu lệnh được lưu tại: **`/users/{uid}/commands/{cmdId}`**  
→ khớp 100% với rules trên (chỉ user đó đọc/ghi được data của mình).

## Tối ưu tốc độ load

- **localStorage cache**: lần 2 trở đi hiện lệnh ngay từ cache, Firebase sync nền.
- **Skeleton shimmer** khi chưa có cache.
- **get() trước + onValue** thay vì chỉ listen nặng.
- Font giảm weight + `display=swap`.
- `modulepreload` cho Firebase SDK.
- Debounce search 120ms, DocumentFragment khi render.
- Seed mẫu chỉ chạy 1 lần khi path trống.

## Cấu trúc

```
linux-cmd-vault/
├── index.html
├── styles.css
├── app.js
└── README.md
```

## Setup

1. Authentication → bật **Email/Password** → tạo user `lga775385@gmail.com`.
2. Realtime Database → paste **rules** ở trên → Publish.
3. Chạy local server:

```bash
cd linux-cmd-vault
python3 -m http.server 8080
# http://localhost:8080
```

Lần đầu đăng nhập thành công sẽ tự seed ~24 lệnh mẫu dưới `users/<uid>/commands`.

## Distros

Common · Ubuntu/Debian · Fedora/RHEL · Arch · openSUSE · Alpine

## Categories

Package · System · Network · Files · Security · Process · User · Misc
