import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getDatabase,
  ref,
  push,
  set,
  update,
  remove,
  get,
  onValue
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBkPBVY1n7g114fDY5hx3AdUP7zxfoG1LY",
  authDomain: "dumuctime.firebaseapp.com",
  databaseURL: "https://dumuctime-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "dumuctime",
  storageBucket: "dumuctime.firebasestorage.app",
  messagingSenderId: "1024458948115",
  appId: "1:1024458948115:web:e6bce8837278f0a38689e6"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

const ALLOWED_EMAIL = "lga775385@gmail.com";
const CACHE_KEY = "dumuctime_cmds_v2";

const DISTROS = [
  { id: "all", label: "Tất cả", icon: "◆" },
  { id: "common", label: "Common / Generic", icon: "⬡" },
  { id: "ubuntu", label: "Ubuntu / Debian", icon: "◉" },
  { id: "fedora", label: "Fedora / RHEL", icon: "◈" },
  { id: "arch", label: "Arch Linux", icon: "▲" },
  { id: "opensuse", label: "openSUSE", icon: "◇" },
  { id: "alpine", label: "Alpine Linux", icon: "▣" }
];

const CATEGORIES = [
  { id: "all", label: "Tất cả" },
  { id: "package", label: "Package Management" },
  { id: "system", label: "System Administration" },
  { id: "network", label: "Networking" },
  { id: "files", label: "Files & Storage" },
  { id: "security", label: "Security" },
  { id: "process", label: "Process & Services" },
  { id: "user", label: "User & Permission" },
  { id: "misc", label: "Miscellaneous" }
];

// Sample data loaded lazily via samples.js when seeding

// ========== STATE ==========
let commands = [];
let currentUid = null;
let currentDistro = "all";
let currentCategory = "all";
let currentSearch = "";
let selectedCmdId = null;
let editingId = null;
let viewMode = "grid";
let unsubCommands = null;

// ========== DOM HELPERS ==========
function $(sel, parent = document) {
  return parent.querySelector(sel);
}
function $$(sel, parent = document) {
  return parent.querySelectorAll(sel);
}

const loginScreen = $("#login-screen");
const appScreen = $("#app-screen");
const loginForm = $("#login-form");
const loginError = $("#login-error");
const loginBtn = $("#login-btn");
const emailInput = $("#email");
const passwordInput = $("#password");
const distroNav = $("#distro-nav");
const categoryNav = $("#category-nav");
const commandGrid = $("#command-grid");
const emptyState = $("#empty-state");
const detailPanel = $("#detail-panel");
const breadcrumb = $("#breadcrumb");
const totalCmds = $("#total-cmds");
const userEmailEl = $("#user-email");
const globalSearch = $("#global-search");

// ========== CACHE (tăng tốc load) ==========
function loadCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.items) || !parsed.uid) return null;
    return parsed;
  } catch {
    return null;
  }
}

function saveCache(uid, items) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({
      uid,
      ts: Date.now(),
      items
    }));
  } catch { /* quota */ }
}

function clearCache() {
  try { localStorage.removeItem(CACHE_KEY); } catch {}
}

// ========== AUTH ==========
onAuthStateChanged(auth, (user) => {
  if (user) {
    if (user.email !== ALLOWED_EMAIL) {
      showToast("Email không được phép truy cập", "error");
      signOut(auth);
      return;
    }
    currentUid = user.uid;
    showApp(user);
  } else {
    currentUid = null;
    if (unsubCommands) {
      unsubCommands();
      unsubCommands = null;
    }
    showLogin();
  }
});

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = emailInput.value.trim().toLowerCase();
  const password = passwordInput.value;

  if (email !== ALLOWED_EMAIL) {
    showLoginError("Chỉ email lga775385@gmail.com được phép đăng nhập.");
    return;
  }

  setLoginLoading(true);
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    console.error(err);
    let msg = "Đăng nhập thất bại.";
    if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password" || err.code === "auth/invalid-credential") {
      msg = "Email hoặc mật khẩu không đúng.";
    } else if (err.code === "auth/too-many-requests") {
      msg = "Quá nhiều lần thử. Vui lòng đợi.";
    }
    showLoginError(msg);
  } finally {
    setLoginLoading(false);
  }
});

$("#logout-btn").addEventListener("click", () => {
  clearCache();
  signOut(auth);
});

function showLogin() {
  loginScreen.classList.add("active");
  appScreen.classList.remove("active");
  emailInput.value = ALLOWED_EMAIL;
  passwordInput.value = "";
  loginError.classList.add("hidden");
}

function showApp(user) {
  loginScreen.classList.remove("active");
  appScreen.classList.add("active");
  userEmailEl.textContent = user.email;
  initSidebar();
  setupMobileChrome();

  // 1) Hiện cache ngay (perceived performance)
  const cached = loadCache();
  if (cached && cached.uid === user.uid && cached.items.length) {
    commands = cached.items;
    updateCounts();
    renderCommands();
  } else {
    showSkeleton();
  }

  // 2) Sync từ Firebase (path đúng rules: users/$uid/...)
  loadCommands(user.uid);
}

function setLoginLoading(loading) {
  loginBtn.disabled = loading;
  const text = $(".btn-text", loginBtn);
  const loader = $(".btn-loader", loginBtn);
  if (text) text.style.display = loading ? "none" : "inline";
  if (loader) loader.classList.toggle("hidden", !loading);
}

function showLoginError(msg) {
  loginError.textContent = msg;
  loginError.classList.remove("hidden");
}

// ========== PATH theo rules ==========
function cmdsPath(uid) {
  return `users/${uid}/commands`;
}

// ========== DATA ==========
function loadCommands(uid) {
  if (unsubCommands) {
    unsubCommands();
    unsubCommands = null;
  }

  const commandsRef = ref(db, cmdsPath(uid));

  // Lấy 1 lần nhanh trước, rồi lắng nghe thay đổi
  get(commandsRef)
    .then((snap) => {
      const data = snap.val();
      if (!data) {
        seedSampleData(uid);
        return;
      }
      applyRemoteData(uid, data);
    })
    .catch(async (err) => {
      console.error("get error:", err);
      showToast("Lỗi đọc DB. Kiểm tra Rules / kết nối.", "error");
      if (!commands.length) {
        try {
          const { SAMPLE_COMMANDS } = await import("./samples.js");
          commands = SAMPLE_COMMANDS.map((c, i) => ({ id: "local-" + i, ...c }));
          updateCounts();
          renderCommands();
        } catch (e) { console.error(e); }
      }
    });

  // Realtime nhẹ (chỉ khi có thay đổi)
  unsubCommands = onValue(commandsRef, (snap) => {
    const data = snap.val();
    if (data) applyRemoteData(uid, data);
  }, (err) => {
    console.error("onValue error:", err);
  });
}

function applyRemoteData(uid, data) {
  commands = Object.entries(data).map(([id, val]) => ({ id, ...val }));
  saveCache(uid, commands);
  updateCounts();
  renderCommands();
}

async function seedSampleData(uid) {
  showToast("Đang khởi tạo dữ liệu mẫu...", "success");
  let SAMPLE_COMMANDS;
  try {
    ({ SAMPLE_COMMANDS } = await import("./samples.js"));
  } catch (e) {
    console.error("Load samples failed", e);
    showToast("Không tải được dữ liệu mẫu", "error");
    return;
  }
  const base = ref(db, cmdsPath(uid));
  const writes = SAMPLE_COMMANDS.map((cmd) => {
    const newRef = push(base);
    return set(newRef, {
      ...cmd,
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
  });
  try {
    await Promise.all(writes);
    showToast(`Đã tải ${SAMPLE_COMMANDS.length} lệnh mẫu`, "success");
  } catch (err) {
    console.error(err);
    showToast("Seed thất bại: " + err.message, "error");
    commands = SAMPLE_COMMANDS.map((c, i) => ({ id: "local-" + i, ...c }));
    updateCounts();
    renderCommands();
  }
}

function updateCounts() {
  const distroCounts = { all: commands.length };
  const catCounts = { all: commands.length };
  for (const c of commands) {
    distroCounts[c.distro] = (distroCounts[c.distro] || 0) + 1;
    catCounts[c.category] = (catCounts[c.category] || 0) + 1;
  }
  $$("[data-count-distro]").forEach((el) => {
    el.textContent = distroCounts[el.dataset.countDistro] || 0;
  });
  $$("[data-count-cat]").forEach((el) => {
    el.textContent = catCounts[el.dataset.countCat] || 0;
  });
  totalCmds.textContent = commands.length;
}

// ========== SIDEBAR ==========
function initSidebar() {
  distroNav.innerHTML = DISTROS.map((d) => `
    <button class="nav-item ${d.id === currentDistro ? "active" : ""}" data-distro="${d.id}">
      <span>${d.icon}</span>
      <span>${d.label}</span>
      <span class="count" data-count-distro="${d.id}">0</span>
    </button>
  `).join("");

  categoryNav.innerHTML = CATEGORIES.map((c) => `
    <button class="nav-item ${c.id === currentCategory ? "active" : ""}" data-category="${c.id}">
      <span>${c.label}</span>
      <span class="count" data-count-cat="${c.id}">0</span>
    </button>
  `).join("");

  distroNav.onclick = (e) => {
    const btn = e.target.closest("[data-distro]");
    if (!btn) return;
    currentDistro = btn.dataset.distro;
    $$("#distro-nav .nav-item").forEach((b) => b.classList.toggle("active", b.dataset.distro === currentDistro));
    selectedCmdId = null;
    detailPanel.classList.add("hidden");
    if (isMobile()) closeSidebarMobile();
    renderCommands();
  };

  categoryNav.onclick = (e) => {
    const btn = e.target.closest("[data-category]");
    if (!btn) return;
    currentCategory = btn.dataset.category;
    $$("#category-nav .nav-item").forEach((b) => b.classList.toggle("active", b.dataset.category === currentCategory));
    selectedCmdId = null;
    detailPanel.classList.add("hidden");
    if (isMobile()) closeSidebarMobile();
    renderCommands();
  };
}

// ========== RENDER ==========
function showSkeleton() {
  commandGrid.innerHTML = Array.from({ length: 6 }, () => `
    <div class="cmd-card skeleton-card">
      <div class="skel skel-title"></div>
      <div class="skel skel-code"></div>
      <div class="skel skel-meta"></div>
    </div>
  `).join("");
  emptyState.classList.add("hidden");
}

function getFilteredCommands() {
  const q = currentSearch.toLowerCase();
  return commands.filter((c) => {
    if (currentDistro !== "all" && c.distro !== currentDistro) return false;
    if (currentCategory !== "all" && c.category !== currentCategory) return false;
    if (q) {
      const hay = `${c.title} ${c.command} ${c.explanation} ${(c.tags || []).join(" ")} ${c.distro} ${c.category}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderCommands() {
  const filtered = getFilteredCommands();
  const distroLabel = DISTROS.find((d) => d.id === currentDistro)?.label || "Tất cả";
  const catLabel = CATEGORIES.find((c) => c.id === currentCategory)?.label || "Tất cả";
  breadcrumb.innerHTML = `<span>${distroLabel}</span> · <span>${catLabel}</span> · ${filtered.length} lệnh`;

  if (filtered.length === 0) {
    commandGrid.innerHTML = "";
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  // DocumentFragment để giảm reflow
  const frag = document.createDocumentFragment();
  const tpl = document.createElement("div");

  tpl.innerHTML = filtered.map((c) => `
    <article class="cmd-card ${c.id === selectedCmdId ? "active" : ""}" data-id="${c.id}">
      <div class="cmd-card-header">
        <h3 class="cmd-card-title">${escapeHtml(c.title)}</h3>
        <div class="cmd-card-badges">
          <span class="badge ${c.distro}">${c.distro}</span>
        </div>
      </div>
      <div class="cmd-card-preview">${escapeHtml((c.command || "").split("\n")[0])}</div>
      <div class="cmd-card-meta">
        <span class="diff ${c.difficulty || "easy"}">${c.difficulty || "easy"}</span>
        <span>${CATEGORIES.find((cat) => cat.id === c.category)?.label || c.category}</span>
      </div>
    </article>
  `).join("");

  while (tpl.firstChild) frag.appendChild(tpl.firstChild);
  commandGrid.innerHTML = "";
  commandGrid.appendChild(frag);

  commandGrid.querySelectorAll(".cmd-card").forEach((card) => {
    card.addEventListener("click", () => openDetail(card.dataset.id), { passive: true });
  });
}

function openDetail(id) {
  const cmd = commands.find((c) => c.id === id);
  if (!cmd) return;
  selectedCmdId = id;
  renderCommands();

  $("#detail-title").textContent = cmd.title;
  const distroBadge = $("#detail-distro");
  distroBadge.textContent = cmd.distro;
  distroBadge.className = "badge " + cmd.distro;
  $("#detail-cmd").textContent = cmd.command;
  $("#detail-explanation").innerHTML = formatExplanation(cmd.explanation);
  $("#detail-example").textContent = cmd.example || "(không có ví dụ)";
  $("#example-section").style.display = cmd.example ? "block" : "none";
  $("#detail-category").textContent = CATEGORIES.find((c) => c.id === cmd.category)?.label || cmd.category;
  const diffEl = $("#detail-difficulty");
  diffEl.textContent = cmd.difficulty || "easy";
  diffEl.className = "meta-tag diff " + (cmd.difficulty || "easy");
  $("#detail-tags").innerHTML = (cmd.tags || []).map((t) => `<span class="tag">${escapeHtml(t)}</span>`).join("");

  detailPanel.classList.remove("hidden");
  if (isMobile()) {
    const sidebar = $("#sidebar");
    const overlay = $("#mobile-overlay");
    sidebar.classList.add("collapsed");
    overlay.classList.remove("hidden");
    document.body.classList.add("overlay-open");
  }
}

function formatExplanation(text) {
  if (!text) return "";
  return escapeHtml(text)
    .replace(/\n/g, "<br>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ========== COPY ==========
$("#copy-cmd-btn").addEventListener("click", async () => {
  const text = $("#detail-cmd").textContent;
  try {
    await navigator.clipboard.writeText(text);
    const btn = $("#copy-cmd-btn");
    btn.classList.add("copied");
    $(".copy-text", btn).textContent = "Copied!";
    showToast("Đã copy lệnh vào clipboard", "success");
    setTimeout(() => {
      btn.classList.remove("copied");
      $(".copy-text", btn).textContent = "Copy";
    }, 1600);
  } catch {
    showToast("Không thể copy", "error");
  }
});

$("#close-detail").addEventListener("click", () => {
  detailPanel.classList.add("hidden");
  selectedCmdId = null;
  if (isMobile()) {
    const overlay = $("#mobile-overlay");
    const sidebar = $("#sidebar");
    if (sidebar.classList.contains("collapsed")) {
      overlay.classList.add("hidden");
      document.body.classList.remove("overlay-open");
    }
  }
  renderCommands();
});

// ========== SEARCH ==========
let searchTimer = null;
globalSearch.addEventListener("input", (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    currentSearch = e.target.value.trim();
    renderCommands();
  }, 120);
});

document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "k") {
    e.preventDefault();
    globalSearch.focus();
    globalSearch.select();
  }
  if (e.key === "Escape") {
    if (!$("#cmd-modal").classList.contains("hidden")) closeModal();
    else if (!detailPanel.classList.contains("hidden")) {
      detailPanel.classList.add("hidden");
      selectedCmdId = null;
      renderCommands();
    }
  }
});

// ========== VIEW / SIDEBAR ==========
$$(".view-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    viewMode = btn.dataset.view;
    $$(".view-btn").forEach((b) => b.classList.toggle("active", b.dataset.view === viewMode));
    commandGrid.classList.toggle("list-view", viewMode === "list");
  });
});

function isMobile() {
  return window.matchMedia("(max-width: 900px)").matches;
}

function setupMobileChrome() {
  const sidebar = $("#sidebar");
  const overlay = $("#mobile-overlay");
  if (isMobile()) {
    sidebar.classList.add("collapsed");
    detailPanel.classList.add("hidden");
  }
  // resize handler
  window.addEventListener("resize", () => {
    if (!isMobile()) {
      sidebar.classList.remove("collapsed");
      overlay.classList.add("hidden");
      document.body.classList.remove("overlay-open");
    } else if (!sidebar.classList.contains("collapsed") === false) {
      // keep state
    }
  });
}

function openSidebarMobile() {
  const sidebar = $("#sidebar");
  const overlay = $("#mobile-overlay");
  detailPanel.classList.add("hidden");
  selectedCmdId = null;
  sidebar.classList.remove("collapsed");
  overlay.classList.remove("hidden");
  document.body.classList.add("overlay-open");
}

function closeSidebarMobile() {
  const sidebar = $("#sidebar");
  const overlay = $("#mobile-overlay");
  sidebar.classList.add("collapsed");
  // only hide overlay if detail also closed
  if (detailPanel.classList.contains("hidden")) {
    overlay.classList.add("hidden");
    document.body.classList.remove("overlay-open");
  }
}

$("#sidebar-toggle").addEventListener("click", () => {
  const sidebar = $("#sidebar");
  if (isMobile()) {
    if (sidebar.classList.contains("collapsed")) openSidebarMobile();
    else closeSidebarMobile();
  } else {
    sidebar.classList.toggle("collapsed");
  }
});

const mobileOverlay = $("#mobile-overlay");
if (mobileOverlay) {
  mobileOverlay.addEventListener("click", () => {
    closeSidebarMobile();
    detailPanel.classList.add("hidden");
    selectedCmdId = null;
    mobileOverlay.classList.add("hidden");
    document.body.classList.remove("overlay-open");
    renderCommands();
  });
}

// ========== CRUD (path users/$uid/commands) ==========
$("#add-cmd-btn").addEventListener("click", () => openModal());

$("#edit-cmd-btn").addEventListener("click", () => {
  if (selectedCmdId) openModal(selectedCmdId);
});

$("#delete-cmd-btn").addEventListener("click", async () => {
  if (!selectedCmdId || !currentUid) return;
  if (!confirm("Bạn chắc chắn muốn xóa lệnh này?")) return;
  try {
    await remove(ref(db, `${cmdsPath(currentUid)}/${selectedCmdId}`));
    selectedCmdId = null;
    detailPanel.classList.add("hidden");
    showToast("Đã xóa lệnh", "success");
  } catch (err) {
    console.error(err);
    showToast("Lỗi khi xóa: " + err.message, "error");
  }
});

function openModal(id = null) {
  editingId = id;
  const form = $("#cmd-form");
  form.reset();

  if (id) {
    const cmd = commands.find((c) => c.id === id);
    if (!cmd) return;
    $("#modal-title").textContent = "Sửa lệnh";
    $("#cmd-title").value = cmd.title;
    $("#cmd-distro").value = cmd.distro;
    $("#cmd-category").value = cmd.category;
    $("#cmd-difficulty").value = cmd.difficulty || "easy";
    $("#cmd-command").value = cmd.command;
    $("#cmd-explanation").value = cmd.explanation;
    $("#cmd-example").value = cmd.example || "";
    $("#cmd-tags").value = (cmd.tags || []).join(", ");
  } else {
    $("#modal-title").textContent = "Thêm lệnh mới";
  }
  $("#cmd-modal").classList.remove("hidden");
  $("#cmd-title").focus();
}

function closeModal() {
  $("#cmd-modal").classList.add("hidden");
  editingId = null;
}

$("#close-modal").addEventListener("click", closeModal);
$("#cancel-modal").addEventListener("click", closeModal);
$(".modal-backdrop").addEventListener("click", closeModal);

$("#cmd-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentUid) return;

  const data = {
    title: $("#cmd-title").value.trim(),
    distro: $("#cmd-distro").value,
    category: $("#cmd-category").value,
    difficulty: $("#cmd-difficulty").value,
    command: $("#cmd-command").value.trim(),
    explanation: $("#cmd-explanation").value.trim(),
    example: $("#cmd-example").value.trim(),
    tags: $("#cmd-tags").value.split(",").map((t) => t.trim()).filter(Boolean),
    updatedAt: Date.now()
  };

  try {
    if (editingId) {
      await update(ref(db, `${cmdsPath(currentUid)}/${editingId}`), data);
      showToast("Đã cập nhật lệnh", "success");
    } else {
      data.createdAt = Date.now();
      await push(ref(db, cmdsPath(currentUid)), data);
      showToast("Đã thêm lệnh mới", "success");
    }
    closeModal();
  } catch (err) {
    console.error(err);
    showToast("Lỗi lưu: " + err.message, "error");
  }
});

// ========== TOAST ==========
function showToast(msg, type = "success") {
  const toast = $("#toast");
  toast.textContent = msg;
  toast.className = "toast show " + type;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.classList.add("hidden"), 280);
  }, 2600);
}
