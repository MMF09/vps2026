// Lazy-loaded sample commands
export const SAMPLE_COMMANDS = [
  {
    title: "Cập nhật & nâng cấp hệ thống (apt)",
    distro: "ubuntu",
    category: "package",
    difficulty: "easy",
    command: "sudo apt update && sudo apt upgrade -y",
    explanation: "• sudo: chạy với quyền root.\n• apt update: tải lại danh sách package từ repo.\n• &&: chỉ chạy tiếp nếu lệnh trước thành công.\n• apt upgrade -y: nâng cấp mọi package, -y tự Yes.\n\nKhông dùng dist-upgrade trừ khi hiểu rõ (có thể xóa package).",
    example: "apt list --upgradable\nsudo apt update && sudo apt upgrade -y",
    tags: ["apt", "update", "upgrade"]
  },
  {
    title: "Cài package mới (apt)",
    distro: "ubuntu",
    category: "package",
    difficulty: "easy",
    command: "sudo apt install <package-name>",
    explanation: "Cài 1 hoặc nhiều package.\n• Có thể: sudo apt install pkg1 pkg2\n• Version cụ thể: sudo apt install package=1.2.3",
    example: "sudo apt install nginx git htop",
    tags: ["apt", "install"]
  },
  {
    title: "Gỡ package & dọn dẹp (apt)",
    distro: "ubuntu",
    category: "package",
    difficulty: "easy",
    command: "sudo apt remove <pkg>\nsudo apt purge <pkg>\nsudo apt autoremove",
    explanation: "• remove: gỡ package, giữ config.\n• purge: gỡ + xóa config.\n• autoremove: xóa dependency orphan.",
    example: "sudo apt purge apache2\nsudo apt autoremove --purge",
    tags: ["apt", "remove", "purge"]
  },
  {
    title: "Cập nhật hệ thống (dnf)",
    distro: "fedora",
    category: "package",
    difficulty: "easy",
    command: "sudo dnf upgrade --refresh",
    explanation: "• dnf: package manager Fedora/RHEL 8+.\n• --refresh: tải metadata mới trước khi upgrade.",
    example: "sudo dnf check-update\nsudo dnf upgrade --refresh -y",
    tags: ["dnf", "upgrade"]
  },
  {
    title: "Cài / gỡ package (dnf)",
    distro: "fedora",
    category: "package",
    difficulty: "easy",
    command: "sudo dnf install <pkg>\nsudo dnf remove <pkg>",
    explanation: "dnf resolve dependency tốt.\n• autoremove: dọn orphan.\n• search: dnf search <keyword>",
    example: "sudo dnf install vim-enhanced\nsudo dnf autoremove",
    tags: ["dnf", "install"]
  },
  {
    title: "Cập nhật toàn hệ thống (pacman)",
    distro: "arch",
    category: "package",
    difficulty: "medium",
    command: "sudo pacman -Syu",
    explanation: "• -S: sync, -y: refresh DB, -u: upgrade all.\nArch rolling-release → chạy -Syu thường xuyên.\nKhông chạy -Sy hoặc -Su riêng (partial upgrade nguy hiểm).",
    example: "sudo pacman -Syu",
    tags: ["pacman", "update"]
  },
  {
    title: "Cài package official (pacman)",
    distro: "arch",
    category: "package",
    difficulty: "easy",
    command: "sudo pacman -S <package>",
    explanation: "• -Ss: tìm package.\n• -Si: thông tin chi tiết.\n• Gỡ: sudo pacman -Rns <pkg> (-n config, -s deps).",
    example: "sudo pacman -S neovim\nsudo pacman -Rns old-pkg",
    tags: ["pacman", "install"]
  },
  {
    title: "Cài AUR với yay",
    distro: "arch",
    category: "package",
    difficulty: "medium",
    command: "yay -S <aur-package>",
    explanation: "yay = AUR helper.\nLuôn đọc PKGBUILD trước khi cài từ AUR.\nCập nhật AUR: yay -Syu",
    example: "yay -S visual-studio-code-bin",
    tags: ["yay", "aur"]
  },
  {
    title: "Cập nhật (zypper)",
    distro: "opensuse",
    category: "package",
    difficulty: "easy",
    command: "sudo zypper refresh && sudo zypper update",
    explanation: "• refresh: cập nhật metadata.\n• update: nâng cấp package.\n• zypper dup: distribution upgrade.",
    example: "sudo zypper refresh\nsudo zypper update -y",
    tags: ["zypper"]
  },
  {
    title: "Cài package (Alpine apk)",
    distro: "alpine",
    category: "package",
    difficulty: "easy",
    command: "apk update && apk add <package>",
    explanation: "apk = Alpine Package Keeper.\n• apk del: gỡ.\n• apk search: tìm.\nThường dùng trong Docker.",
    example: "apk add curl bash nano",
    tags: ["apk", "alpine"]
  },
  {
    title: "Thông tin hệ thống",
    distro: "common",
    category: "system",
    difficulty: "easy",
    command: "uname -a\nhostnamectl\ncat /etc/os-release\nuptime\nfree -h\ndf -h",
    explanation: "• uname -a: kernel + arch.\n• hostnamectl: hostname, OS, kernel.\n• /etc/os-release: thông tin distro chuẩn.\n• free -h / df -h: RAM & disk.",
    example: "uname -r\ncat /etc/os-release | grep PRETTY_NAME",
    tags: ["info", "system"]
  },
  {
    title: "Quản lý service (systemctl)",
    distro: "common",
    category: "process",
    difficulty: "easy",
    command: "sudo systemctl status <svc>\nsudo systemctl start|stop|restart|enable|disable <svc>",
    explanation: "systemctl quản lý systemd.\n• enable --now: enable + start ngay.\n• is-active / is-enabled: kiểm tra nhanh.",
    example: "sudo systemctl status nginx\nsudo systemctl enable --now nginx",
    tags: ["systemd", "systemctl"]
  },
  {
    title: "Xem log (journalctl)",
    distro: "common",
    category: "system",
    difficulty: "medium",
    command: "journalctl -xe\njournalctl -u <svc> -f\njournalctl --since \"1 hour ago\"",
    explanation: "• -xe: log gần + giải thích.\n• -u: theo service.\n• -f: follow.\n• -b: boot hiện tại.\n• -p err: chỉ error trở lên.",
    example: "journalctl -u sshd -n 50\njournalctl -b -p warning",
    tags: ["journalctl", "log"]
  },
  {
    title: "Firewall ufw (Ubuntu)",
    distro: "ubuntu",
    category: "security",
    difficulty: "medium",
    command: "sudo ufw status verbose\nsudo ufw allow 22/tcp\nsudo ufw enable",
    explanation: "ufw = frontend iptables/nftables.\nAllow SSH trước khi enable.\nKhuyến nghị: default deny incoming.",
    example: "sudo ufw default deny incoming\nsudo ufw allow OpenSSH\nsudo ufw enable",
    tags: ["ufw", "firewall"]
  },
  {
    title: "Firewalld (Fedora/RHEL)",
    distro: "fedora",
    category: "security",
    difficulty: "medium",
    command: "sudo firewall-cmd --state\nsudo firewall-cmd --list-all\nsudo firewall-cmd --add-service=http --permanent\nsudo firewall-cmd --reload",
    explanation: "• --permanent + --reload để áp dụng lâu dài.\n• Zone mặc định thường là public.",
    example: "sudo firewall-cmd --add-port=8080/tcp --permanent\nsudo firewall-cmd --reload",
    tags: ["firewalld"]
  },
  {
    title: "Tạo user + sudo",
    distro: "common",
    category: "user",
    difficulty: "easy",
    command: "sudo useradd -m -s /bin/bash <user>\nsudo passwd <user>\nsudo usermod -aG sudo <user>",
    explanation: "• -m: tạo home.\n• -s: set shell.\n• Trên Fedora/RHEL dùng group wheel thay sudo.",
    example: "sudo useradd -m -s /bin/bash alice\nsudo usermod -aG sudo alice",
    tags: ["useradd", "sudo"]
  },
  {
    title: "chmod / chown",
    distro: "common",
    category: "user",
    difficulty: "medium",
    command: "chmod 755 <file>\nchmod u+x <file>\nchown user:group <file>\nchown -R user:group <dir>",
    explanation: "• Numeric: 4=r 2=w 1=x → 755 = rwxr-xr-x\n• Symbolic: u+x, g-w, o=r\n• -R: đệ quy.\nTránh 777.",
    example: "chmod +x script.sh\nchown -R www-data:www-data /var/www",
    tags: ["chmod", "chown"]
  },
  {
    title: "Process: ps / kill",
    distro: "common",
    category: "process",
    difficulty: "easy",
    command: "ps aux | grep <name>\npgrep -a <name>\nkill <PID>\nkill -9 <PID>\npkill <name>",
    explanation: "• kill = SIGTERM (15), process có thể dọn dẹp.\n• kill -9 = SIGKILL, buộc thoát ngay.\n• pkill theo tên.",
    example: "pgrep -a nginx\nsudo kill -9 1234",
    tags: ["ps", "kill"]
  },
  {
    title: "Network diagnostics",
    distro: "common",
    category: "network",
    difficulty: "easy",
    command: "ip a\nip r\nss -tuln\nping -c 4 8.8.8.8\ncurl -I https://example.com",
    explanation: "• ip a / ip r: địa chỉ & route.\n• ss -tuln: port listening (thay netstat).\n• curl -I: chỉ header HTTP.",
    example: "ss -tuln | grep :80\nip -br a",
    tags: ["network", "ss", "ip"]
  },
  {
    title: "rsync đồng bộ file",
    distro: "common",
    category: "files",
    difficulty: "medium",
    command: "rsync -avh --progress /src/ /dest/\nrsync -avz -e ssh /local/ user@host:/remote/",
    explanation: "• -a: archive (recursive + preserve).\n• -z: nén qua mạng.\n• -e ssh: dùng SSH.\nDấu / cuối src rất quan trọng.",
    example: "rsync -avh --delete /backup/ /mnt/ext/",
    tags: ["rsync", "backup"]
  },
  {
    title: "SSH key auth",
    distro: "common",
    category: "security",
    difficulty: "medium",
    command: "ssh-keygen -t ed25519 -C \"you@email.com\"\nssh-copy-id user@host\nssh -i ~/.ssh/id_ed25519 user@host",
    explanation: "ed25519 an toàn hơn RSA.\nSau khi copy key, có thể tắt PasswordAuthentication trên server.",
    example: "ssh-keygen -t ed25519 -a 100",
    tags: ["ssh", "key"]
  },
  {
    title: "find / grep",
    distro: "common",
    category: "files",
    difficulty: "easy",
    command: "find /path -name \"*.log\" -mtime -7\ngrep -rn \"error\" /var/log/\nlocate filename",
    explanation: "• find: nhiều tiêu chí (tên, size, thời gian).\n• grep -rn: recursive + số dòng.\n• locate: nhanh (cần updatedb).",
    example: "find ~ -type f -size +100M\ngrep -rn --include=\"*.js\" \"TODO\" ./src",
    tags: ["find", "grep"]
  },
  {
    title: "Cron job",
    distro: "common",
    category: "process",
    difficulty: "medium",
    command: "crontab -e\ncrontab -l\n# phút giờ ngày tháng thứ  lệnh",
    explanation: "5 trường thời gian + lệnh.\nVí dụ: 0 2 * * * /path/backup.sh → 2h sáng mỗi ngày.\n@reboot chạy khi boot.",
    example: "0 */6 * * * /home/user/check.sh\n@reboot /usr/local/bin/start.sh",
    tags: ["cron"]
  },
  {
    title: "Kiểm tra dung lượng disk",
    distro: "common",
    category: "files",
    difficulty: "easy",
    command: "df -hT\ndu -sh /path/*\nncdu /",
    explanation: "• df -hT: filesystem + type.\n• du -sh: size từng item.\n• ncdu: interactive (cần cài).",
    example: "du -sh /var/log/* | sort -hr | head -10",
    tags: ["df", "du"]
  }
];
