# Folder Dashboard

Site tự động quét thư mục trên VPS Ubuntu, phân loại và hiển thị:

- **Folder có `index.html`** → mở trong khung riêng (slide từ phải)
- **Folder không có index** → hiển thị mờ, không mở được
- **File lẻ** → xem trước trong khung (ảnh, PDF, text…) hoặc tải xuống

## Tính năng

- Mở nội dung **trong khung riêng biệt** (không chuyển trang)
- **Breadcrumb navigation**: `Dashboard › Tên folder/file`
- Nút **Quay lại**, **Đóng**, **Mở tab mới**
- Phím **Esc** để đóng khung
- Loading spinner khi đang tải trang / file
- Xem trước ảnh, PDF, file text trực tiếp
- File không hỗ trợ preview → nút tải xuống
- Tìm kiếm realtime + làm mới dữ liệu

## Cấu trúc

```
folder-dashboard/
├── index.html
├── scan.php
├── css/style.css
├── js/app.js
├── page1/index.html
├── page2/index.html
├── about/index.html
├── docs/                   ← folder không có index
├── huong-dan.txt           ← file mẫu (bị ẩn khỏi danh sách)
└── README.md
```

## Cài đặt trên Ubuntu VPS

```bash
sudo apt update
sudo apt install nginx php-fpm php-cli -y

sudo mkdir -p /var/www/folder-dashboard
sudo chown -R $USER:www-data /var/www/folder-dashboard
sudo chmod -R 755 /var/www/folder-dashboard
```

Giải nén vào `/var/www/folder-dashboard/`.

### Cấu hình Nginx

```bash
sudo nano /etc/nginx/sites-available/folder-dashboard
```

```nginx
server {
    listen 80;
    server_name your-domain-or-ip;

    root /var/www/folder-dashboard;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;  # kiểm tra: ls /run/php/
    }
}
```

Kích hoạt:

```bash
sudo ln -s /etc/nginx/sites-available/folder-dashboard /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Cách dùng

1. Upload folder mới (có hoặc không có `index.html`) vào thư mục gốc.
2. Upload file lẻ (pdf, ảnh, zip, txt…) vào thư mục gốc.
3. Mở trang chính → dữ liệu tự cập nhật.
4. Click folder có index hoặc file → nội dung mở **trong khung riêng** với breadcrumb.
5. Bấm Quay lại / Đóng / Esc / click “Dashboard” trên breadcrumb để trở về.
