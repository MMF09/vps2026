// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDVRzkeY2reKjR5Gv0dHx55geqgivUjEAQ",
  authDomain: "urf1forall.firebaseapp.com",
  databaseURL: "https://urf1forall-default-rtdb.firebaseio.com",
  projectId: "urf1forall",
  storageBucket: "urf1forall.firebasestorage.app",
  messagingSenderId: "335719421403",
  appId: "1:335719421403:web:2b4a2b16150b6f6ba4c3fe",
  measurementId: "G-7DWZB1QBWQ"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// State
let isRegisterMode = false;
let currentUser = null;
let allLogs = [];          // toàn bộ logs của user
let logsUnsub = null;
let selectedDateLog = null; // log của ngày đang chọn trên form

// DOM
const loginScreen = document.getElementById("login-screen");
const mainScreen = document.getElementById("main-screen");
const loginForm = document.getElementById("login-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginError = document.getElementById("login-error");
const loginBtn = document.getElementById("login-btn");
const toggleModeBtn = document.getElementById("toggle-mode");
const logoutBtn = document.getElementById("logout-btn");

const dateInput = document.getElementById("date-input");
const kmInput = document.getElementById("km-input");
const noteInput = document.getElementById("note-input");
const saveBtn = document.getElementById("save-btn");
const saveMsg = document.getElementById("save-msg");
const selectedDayInfo = document.getElementById("selected-day-info");
const selectedKm = document.getElementById("selected-km");
const selectedNote = document.getElementById("selected-note");

const fromDateInput = document.getElementById("from-date");
const toDateInput = document.getElementById("to-date");
const applyFilterBtn = document.getElementById("apply-filter");
const clearFilterBtn = document.getElementById("clear-filter");
const logList = document.getElementById("log-list");
const totalKmEl = document.getElementById("total-km");
const emptyHistory = document.getElementById("empty-history");
const navBtns = document.querySelectorAll(".nav-btn");

// Helpers
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function showScreen(screen) {
  loginScreen.classList.toggle("hidden", screen !== "login");
  mainScreen.classList.toggle("hidden", screen !== "main");
}

function switchTab(tabId) {
  document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");
  navBtns.forEach((b) => b.classList.toggle("active", b.dataset.tab === tabId));
}

function pathLogs(uid) {
  return `users/${uid}/logs`;
}

// Auth state
auth.onAuthStateChanged((user) => {
  currentUser = user;
  if (user) {
    showScreen("main");
    // mặc định chọn hôm nay
    dateInput.value = todayStr();
    fromDateInput.value = "";
    toDateInput.value = "";
    listenLogs();
    updateSelectedDayInfo();
  } else {
    showScreen("login");
    if (logsUnsub) {
      logsUnsub();
      logsUnsub = null;
    }
    allLogs = [];
  }
});

// Login / Register
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.textContent = "";
  loginBtn.disabled = true;
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  try {
    if (isRegisterMode) {
      await auth.createUserWithEmailAndPassword(email, password);
    } else {
      await auth.signInWithEmailAndPassword(email, password);
    }
  } catch (err) {
    loginError.textContent = err.message || "Đăng nhập thất bại";
  } finally {
    loginBtn.disabled = false;
  }
});

toggleModeBtn.addEventListener("click", () => {
  isRegisterMode = !isRegisterMode;
  loginBtn.textContent = isRegisterMode ? "Đăng ký" : "Đăng nhập";
  toggleModeBtn.textContent = isRegisterMode
    ? "Đã có tài khoản? Đăng nhập"
    : "Chưa có tài khoản? Đăng ký";
  loginError.textContent = "";
});

logoutBtn.addEventListener("click", () => auth.signOut());

// Tabs
navBtns.forEach((btn) => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

// Listen all logs under users/{uid}/logs
function listenLogs() {
  if (logsUnsub) logsUnsub();
  const uid = currentUser.uid;
  const ref = db.ref(pathLogs(uid));

  logsUnsub = ref.on("value", (snap) => {
    const data = snap.val();
    if (data) {
      allLogs = Object.entries(data).map(([id, v]) => ({ ...v, id }));
      allLogs.sort((a, b) => b.date.localeCompare(a.date));
    } else {
      allLogs = [];
    }
    updateSelectedDayInfo();
    renderHistory(); // render với filter hiện tại
  });
}

// Khi chọn ngày trên form → hiển thị nếu đã có log
function updateSelectedDayInfo() {
  const date = dateInput.value;
  if (!date) {
    selectedDayInfo.classList.add("hidden");
    selectedDateLog = null;
    return;
  }
  selectedDateLog = allLogs.find((l) => l.date === date) || null;
  if (selectedDateLog) {
    selectedDayInfo.classList.remove("hidden");
    selectedKm.textContent = `Đã có: ${selectedDateLog.km} km`;
    selectedNote.textContent = selectedDateLog.note || "";
    // prefill form
    kmInput.value = selectedDateLog.km;
    noteInput.value = selectedDateLog.note || "";
  } else {
    selectedDayInfo.classList.add("hidden");
    kmInput.value = "";
    noteInput.value = "";
  }
}

dateInput.addEventListener("change", updateSelectedDayInfo);

// Save / Update
saveBtn.addEventListener("click", async () => {
  if (!currentUser) return;
  const date = dateInput.value;
  const km = parseFloat(kmInput.value);
  if (!date) {
    saveMsg.textContent = "❌ Vui lòng chọn ngày";
    saveMsg.style.color = "#dc2626";
    return;
  }
  if (isNaN(km) || km < 0) {
    saveMsg.textContent = "❌ Số km không hợp lệ";
    saveMsg.style.color = "#dc2626";
    return;
  }

  saveBtn.disabled = true;
  saveMsg.textContent = "";
  const uid = currentUser.uid;
  const payload = {
    date,
    km,
    note: noteInput.value.trim() || null,
    createdAt: Date.now(),
    userId: uid
  };

  try {
    if (selectedDateLog && selectedDateLog.id) {
      // cập nhật
      await db.ref(`${pathLogs(uid)}/${selectedDateLog.id}`).set({
        ...payload,
        id: selectedDateLog.id
      });
    } else {
      // tạo mới
      const newRef = db.ref(pathLogs(uid)).push();
      await newRef.set({ ...payload, id: newRef.key });
    }
    saveMsg.textContent = "✅ Đã lưu thành công!";
    saveMsg.style.color = "#16a34a";
  } catch (err) {
    saveMsg.textContent = "❌ Lỗi: " + (err.message || "Không lưu được");
    saveMsg.style.color = "#dc2626";
  } finally {
    saveBtn.disabled = false;
  }
});

// History filter + render
function getFilteredLogs() {
  let list = [...allLogs];
  const from = fromDateInput.value;
  const to = toDateInput.value;
  if (from) list = list.filter((l) => l.date >= from);
  if (to) list = list.filter((l) => l.date <= to);
  return list;
}

function renderHistory() {
  const list = getFilteredLogs();
  logList.innerHTML = "";

  if (list.length === 0) {
    emptyHistory.classList.remove("hidden");
    totalKmEl.innerHTML = "Tổng cộng: <strong>0 km</strong>";
    return;
  }
  emptyHistory.classList.add("hidden");

  const total = list.reduce((s, l) => s + (l.km || 0), 0);
  totalKmEl.innerHTML = `Tổng cộng: <strong>${total.toFixed(1)} km</strong> (${list.length} ngày)`;

  list.forEach((log) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span class="date">${log.date}</span>
      <span class="km">${log.km} km</span>
      ${log.note ? `<span class="note">${log.note}</span>` : ""}
    `;
    // click vào log → chuyển sang tab ghi nhận + chọn ngày đó
    li.addEventListener("click", () => {
      dateInput.value = log.date;
      updateSelectedDayInfo();
      switchTab("dashboard");
    });
    logList.appendChild(li);
  });
}

applyFilterBtn.addEventListener("click", renderHistory);
clearFilterBtn.addEventListener("click", () => {
  fromDateInput.value = "";
  toDateInput.value = "";
  renderHistory();
});
