# Hộp Đen KM - Web (Pure HTML)

Ứng dụng ghi nhận số km đi được mỗi ngày (giống hộp đen xe).

## Công nghệ
- Pure HTML + CSS + JavaScript
- Firebase Authentication (Email/Password)
- Firebase Realtime Database

## Cấu trúc dữ liệu (theo rules mới)
```
users/
  {uid}/
    logs/
      {logId}/
        date: "YYYY-MM-DD"
        km: number
        note: string | null
        createdAt: number
        userId: string
        id: string
```

## Rules Firebase (đúng như bạn cung cấp)
```json
{
  "rules": {
    "users": {
      "$user_id": {
        ".read": "$user_id === auth.uid",
        ".write": "$user_id === auth.uid"
      }
    }
  }
}
```

## Tính năng mới
- Chọn **ngày bất kỳ** (không chỉ hôm nay) để ghi / cập nhật km
- Lọc lịch sử theo **khoảng thời gian** (Từ ngày – Đến ngày)
- Click vào một dòng lịch sử → tự động chuyển sang form và chọn ngày đó để sửa

## Cách chạy
1. Mở `index.html` trực tiếp hoặc dùng local server:
   ```bash
   npx serve .
   # hoặc
   python -m http.server 8080
   ```
2. Bật Authentication → Email/Password trong Firebase Console
3. Dán rules ở trên vào Realtime Database → Rules

## Deploy
Upload toàn bộ thư mục lên Netlify / Vercel / Firebase Hosting / GitHub Pages.
