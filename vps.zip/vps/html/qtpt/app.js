/**
 * PrivaSense Hub — Combined App Logic
 * Analysis Node + Health Tracker
 * Firebase Realtime Database
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  set,
  push,
  remove,
  onValue
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

// ========== FIREBASE CONFIG (Analysis project) ==========
const firebaseConfig = {
  apiKey: "AIzaSyA7lia7Q2SN79kZYlRCiR0swc8oZUoUenY",
  authDomain: "day-dg.firebaseapp.com",
  databaseURL: "https://day-dg-default-rtdb.firebaseio.com",
  projectId: "day-dg",
  storageBucket: "day-dg.appspot.com",
  messagingSenderId: "268157993796",
  appId: "1:268157993796:web:a0d74a8100749f7f6dcd11",
  measurementId: "G-GCH6G4LJD3"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// ========== CONSTANTS ==========
const NODE_ANALYSIS = "analysis";
const NODE_HEALTH = "health";
const ITEMS_PER_PAGE = 10;
const DEFAULT_AVATAR = "https://cdn-icons-png.flaticon.com/512/149/149071.png";

// ========== STATE ==========
let currentUser = null;
let rawDataCache = null;
let allDataArray = [];
let filteredDataArray = [];
let currentPage = 1;
let isRegisterMode = false;
let searchDebounceTimer = null;
let currentDevice = null;

// ========== DOM REFS ==========
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ========== TOAST ==========
function showToast(message, isError = false) {
  const toast = $("#toast");
  const icon = $("#toast-icon");
  const msg = $("#toast-message");

  msg.textContent = message;
  icon.className = isError ? "fas fa-exclamation-circle" : "fas fa-check-circle";
  toast.className = `toast show${isError ? " error" : ""}`;

  setTimeout(() => {
    toast.classList.remove("show");
  }, 3200);
}

// ========== DEVICE DETECTION ==========
function getDeviceDetails() {
  const ua = navigator.userAgent;

  let deviceType = "Máy tính (Desktop)";
  if (/mobile/i.test(ua)) deviceType = "Điện thoại (Mobile)";
  if (/tablet|ipad/i.test(ua)) deviceType = "Máy tính bảng (Tablet)";

  let os = "Không xác định";
  if (ua.indexOf("Win") !== -1) os = "Windows";
  else if (ua.indexOf("Mac") !== -1) os = "MacOS";
  else if (ua.indexOf("Linux") !== -1) os = "Linux";
  else if (ua.indexOf("Android") !== -1) os = "Android";
  else if (ua.indexOf("like Mac") !== -1) os = "iOS";

  let browser = "Khác";
  if (ua.indexOf("Edg") !== -1) browser = "Edge";
  else if (ua.indexOf("Chrome") !== -1) browser = "Chrome";
  else if (ua.indexOf("Firefox") !== -1) browser = "Firefox";
  else if (ua.indexOf("Safari") !== -1) browser = "Safari";
  else if (ua.indexOf("OPR") !== -1 || ua.indexOf("Opera") !== -1) browser = "Opera";

  return {
    deviceType,
    os,
    browser,
    screenResolution: `${window.screen.width}x${window.screen.height}`,
    language: navigator.language || navigator.userLanguage,
    platform: navigator.platform
  };
}

async function getUserIP() {
  try {
    const res = await fetch("https://api64.ipify.org?format=json");
    const d = await res.json();
    return d.ip;
  } catch {
    return "Ẩn danh";
  }
}

function initDeviceInfo() {
  currentDevice = getDeviceDetails();
  $("#dev-type").textContent = currentDevice.deviceType;
  $("#dev-browser").textContent = currentDevice.browser;
  $("#dev-os").textContent = currentDevice.os;
  $("#dev-screen").textContent = currentDevice.screenResolution;
  $("#device-type-short").textContent = currentDevice.deviceType.split(" ")[0];

  getUserIP().then((ip) => {
    $("#dev-ip").textContent = ip;
  });
}

// ========== TIMEZONES ==========
function getTime(code) {
  const zones = {
    VN: "Asia/Ho_Chi_Minh",
    KR: "Asia/Seoul",
    CN: "Asia/Shanghai",
    JP: "Asia/Tokyo"
  };
  const localeMap = {
    VN: "vi-VN",
    KR: "ko-KR",
    CN: "zh-CN",
    JP: "ja-JP"
  };
  return new Date().toLocaleString(
    localeMap[code] || "vi-VN",
    { timeZone: zones[code] || "Asia/Ho_Chi_Minh" }
  );
}

// ========== LEVENSHTEIN SIMILARITY ==========
function calculateSimilarityFast(s1, s2, threshold = 0.68) {
  s1 = s1.toLowerCase().trim();
  s2 = s2.toLowerCase().trim();
  if (s1 === s2) return 1.0;

  const len1 = s1.length, len2 = s2.length;
  if (len1 === 0 || len2 === 0) return 0.0;

  const maxLen = Math.max(len1, len2);
  const maxAllowedDiff = Math.floor(maxLen * (1 - threshold));
  if (Math.abs(len1 - len2) > maxAllowedDiff) return 0.0;

  let v0 = new Int32Array(len2 + 1);
  let v1 = new Int32Array(len2 + 1);

  for (let i = 0; i <= len2; i++) v0[i] = i;

  for (let i = 0; i < len1; i++) {
    v1[0] = i + 1;
    let minDistance = v1[0];

    for (let j = 0; j < len2; j++) {
      const cost = s1[i] === s2[j] ? 0 : 1;
      v1[j + 1] = Math.min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost);
      if (v1[j + 1] < minDistance) minDistance = v1[j + 1];
    }

    if (minDistance > maxAllowedDiff) return 0.0;
    for (let j = 0; j <= len2; j++) v0[j] = v1[j];
  }

  return (maxLen - v0[len2]) / maxLen;
}

function highlightText(text, search) {
  if (!search) return text;
  return String(text).replace(
    new RegExp(`(${search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi"),
    '<span class="search-highlight">$1</span>'
  );
}

// ========== AUTH ==========
function toggleAuthMode() {
  isRegisterMode = !isRegisterMode;
  const nameGroup = $("#display-name-group");
  const submitBtn = $("#btn-auth-submit");
  const toggleText = $("#auth-toggle-text");
  const toggleBtn = $("#btn-toggle-auth");

  nameGroup.style.display = isRegisterMode ? "block" : "none";
  submitBtn.innerHTML = isRegisterMode
    ? '<i class="fas fa-user-plus"></i><span>Đăng ký</span>'
    : '<i class="fas fa-sign-in-alt"></i><span>Đăng nhập</span>';
  toggleText.textContent = isRegisterMode ? "Đã có tài khoản?" : "Chưa có tài khoản?";
  toggleBtn.textContent = isRegisterMode ? "Đăng nhập" : "Đăng ký ngay";
}

async function handleEmailAuth(e) {
  e.preventDefault();
  const email = $("#auth-email").value.trim();
  const pwd = $("#auth-password").value;
  const displayName = $("#display-name").value.trim();

  if (!email || !pwd) {
    showToast("Vui lòng nhập Email và Mật khẩu!", true);
    return;
  }

  try {
    if (isRegisterMode) {
      if (!displayName) {
        showToast("Vui lòng nhập tên hiển thị!", true);
        return;
      }
      const res = await createUserWithEmailAndPassword(auth, email, pwd);
      await updateProfile(res.user, { displayName });
      showToast("Đăng ký tài khoản thành công!");
    } else {
      await signInWithEmailAndPassword(auth, email, pwd);
      showToast("Đăng nhập thành công!");
    }
    $("#auth-form").reset();
  } catch (err) {
    let msg = err.message;
    if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password" || err.code === "auth/invalid-credential") {
      msg = "Email hoặc mật khẩu không chính xác.";
    } else if (err.code === "auth/email-already-in-use") {
      msg = "Email này đã được đăng ký.";
    } else if (err.code === "auth/weak-password") {
      msg = "Mật khẩu quá yếu (tối thiểu 6 ký tự).";
    }
    showToast("Lỗi: " + msg, true);
  }
}

async function handleGoogleLogin() {
  try {
    await signInWithPopup(auth, googleProvider);
    showToast("Đăng nhập Google thành công!");
  } catch (err) {
    showToast("Lỗi đăng nhập: " + err.message, true);
  }
}

// ========== TAB NAVIGATION ==========
function switchTab(tabName) {
  // Update nav items
  $$(".nav-item").forEach((el) => {
    el.classList.toggle("active", el.dataset.tab === tabName);
  });
  $$(".bottom-nav-item").forEach((el) => {
    el.classList.toggle("active", el.dataset.tab === tabName);
  });

  // Update content
  $$(".tab-content").forEach((el) => {
    el.classList.toggle("active", el.id === `tab-${tabName}`);
  });

  // Update title
  const titles = {
    analysis: "Node Analysis",
    health: "Health Tracker"
  };
  $("#page-title").textContent = titles[tabName] || tabName;

  // Close sidebar on mobile
  closeSidebar();
}

// ========== SIDEBAR ==========
function openSidebar() {
  $("#sidebar").classList.add("open");
  $("#sidebar-overlay").classList.add("show");
}

function closeSidebar() {
  $("#sidebar").classList.remove("open");
  $("#sidebar-overlay").classList.remove("show");
}

// ========== ANALYSIS LOGIC ==========
function applyFilterAndRender() {
  const query = $("#search-input").value.toLowerCase().trim();

  if (!query) {
    filteredDataArray = allDataArray;
  } else {
    filteredDataArray = allDataArray.filter((d) =>
      (d.sha && d.sha.toLowerCase().includes(query)) ||
      (d.sha512 && d.sha512.toLowerCase().includes(query)) ||
      (d.hashedKey && d.hashedKey.toLowerCase().includes(query)) ||
      (d.deviceInfo && (
        (d.deviceInfo.os || "").toLowerCase().includes(query) ||
        (d.deviceInfo.browser || "").toLowerCase().includes(query) ||
        (d.deviceInfo.deviceType || "").toLowerCase().includes(query)
      ))
    );
  }

  renderAnalysisPage();
}

function renderAnalysisPage() {
  const tbody = $("#data-table");
  const paginationBar = $("#pagination-bar");
  const searchWord = $("#search-input").value.toLowerCase().trim();
  const totalItems = filteredDataArray.length;

  if (totalItems === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="3" class="empty-state">
          <i class="fas fa-search"></i>
          <p>Không tìm thấy dữ liệu trong node [${NODE_ANALYSIS}]</p>
        </td>
      </tr>`;
    paginationBar.style.display = "none";
    return;
  }

  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE) || 1;
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;

  const start = (currentPage - 1) * ITEMS_PER_PAGE;
  const end = Math.min(start + ITEMS_PER_PAGE, totalItems);
  const pageData = filteredDataArray.slice(start, end);

  const fragment = document.createDocumentFragment();

  pageData.forEach((d) => {
    const tr = document.createElement("tr");
    const devInfo = d.deviceInfo || {};
    const devBadge = devInfo.deviceType
      ? `<span class="device-tag"><i class="fas fa-desktop"></i> ${devInfo.deviceType} | ${devInfo.os} | ${devInfo.browser} (${devInfo.screenResolution})</span>`
      : "";

    tr.innerHTML = `
      <td class="hash-cell">
        <div><strong>SHA-256:</strong> ${highlightText(d.sha || "N/A", searchWord)}</div>
        <div style="margin-top:3px;"><strong>SHA-512:</strong> ${highlightText(d.sha512 || "N/A", searchWord)}</div>
        <div class="meta-info">
          <span><i class="far fa-clock"></i> VN: ${d.timeVN || "—"}</span>
          <span><i class="far fa-clock"></i> KR: ${d.timeKR || "—"}</span>
          <span><i class="far fa-clock"></i> JP: ${d.timeJP || "—"}</span>
        </div>
      </td>
      <td class="hash-cell">
        ${highlightText(d.hashedKey || "N/A", searchWord)}
        <div class="meta-info" style="margin-top:6px;">
          <span><i class="fas fa-globe"></i> IP: ${d.ip || "Unknown"}</span>
        </div>
        <div class="meta-info" style="margin-top:4px;">
          ${devBadge}
        </div>
      </td>
      <td>
        <button class="btn btn-danger" data-delete-key="${d.key}">
          <i class="fas fa-trash-alt"></i> Xóa
        </button>
      </td>
    `;
    fragment.appendChild(tr);
  });

  tbody.innerHTML = "";
  tbody.appendChild(fragment);

  // Bind delete buttons
  tbody.querySelectorAll("[data-delete-key]").forEach((btn) => {
    btn.addEventListener("click", () => deleteAnalysisData(btn.dataset.deleteKey));
  });

  $("#page-from").textContent = start + 1;
  $("#page-to").textContent = end;
  $("#page-total").textContent = totalItems;
  $("#current-page-display").textContent = currentPage;

  $("#btn-prev").disabled = currentPage <= 1;
  $("#btn-next").disabled = currentPage >= totalPages;

  // Page numbers
  const pageNumbers = $("#page-numbers");
  pageNumbers.innerHTML = "";

  const maxVisible = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
  let endPage = Math.min(totalPages, startPage + maxVisible - 1);
  if (endPage - startPage + 1 < maxVisible) {
    startPage = Math.max(1, endPage - maxVisible + 1);
  }

  for (let i = startPage; i <= endPage; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    if (i === currentPage) btn.classList.add("active");
    btn.addEventListener("click", () => {
      currentPage = i;
      renderAnalysisPage();
    });
    pageNumbers.appendChild(btn);
  }

  paginationBar.style.display = "flex";
}

async function addAnalysisData() {
  if (!currentUser) return;
  const input = $("#data-input");
  const data = input.value.trim();
  if (!data) {
    showToast("Vui lòng nhập dữ liệu!", true);
    input.focus();
    return;
  }

  // Similarity check
  if (rawDataCache) {
    const values = Object.values(rawDataCache);
    for (let i = 0; i < values.length; i++) {
      if (values[i].original) {
        const sim = calculateSimilarityFast(data, values[i].original, 0.68);
        if (sim > 0.68) {
          showToast(`Dữ liệu tương đồng ${(sim * 100).toFixed(1)}% với bản ghi đã tồn tại! Từ chối nhập.`, true);
          return;
        }
      }
    }
  }

  const md5Key = CryptoJS.MD5(data).toString();
  const userRef = ref(db, `${NODE_ANALYSIS}/users/${currentUser.uid}/data/${md5Key}`);

  try {
    const ip = await getUserIP();
    await set(userRef, {
      sha: CryptoJS.SHA256(data).toString(),
      sha512: CryptoJS.SHA512(data).toString(),
      original: data,
      hashedKey: md5Key,
      ip,
      deviceInfo: currentDevice,
      timeVN: getTime("VN"),
      timeKR: getTime("KR"),
      timeCN: getTime("CN"),
      timeJP: getTime("JP")
    });
    input.value = "";
    input.focus();
    showToast("Đã thêm dữ liệu thành công!");
  } catch (err) {
    showToast("Không thể lưu dữ liệu: " + err.message, true);
  }
}

function deleteAnalysisData(key) {
  if (!currentUser) return;
  if (confirm("Xác nhận xóa bản ghi này?")) {
    remove(ref(db, `${NODE_ANALYSIS}/users/${currentUser.uid}/data/${key}`));
    showToast("Đã xóa bản ghi!");
  }
}

// ========== BACKUP / IMPORT ==========
function showModal(id) {
  $(`#${id}`).classList.add("show");
}

function hideModal(id) {
  $(`#${id}`).classList.remove("show");
  const pwdId = id === "backup-modal" ? "backup-password" : "import-password";
  $(`#${pwdId}`).value = "";
}

function performBackup() {
  const pwd = $("#backup-password").value;
  if (!pwd) {
    showToast("Vui lòng nhập mật khẩu mã hóa!", true);
    return;
  }
  if (!rawDataCache) {
    hideModal("backup-modal");
    showToast("Không có dữ liệu để backup!", true);
    return;
  }

  try {
    const encrypted = {};
    Object.keys(rawDataCache).forEach((key) => {
      const item = rawDataCache[key];
      encrypted[key] = {
        ...item,
        original: CryptoJS.AES.encrypt(String(item.original || ""), pwd).toString()
      };
    });

    const blob = new Blob([JSON.stringify(encrypted, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `AnalysisDB-Backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    hideModal("backup-modal");
    showToast("Backup thành công!");
  } catch (err) {
    showToast("Lỗi mã hóa: " + err.message, true);
  }
}

function performImport() {
  const pwd = $("#import-password").value;
  const file = $("#file-input").files[0];
  if (!pwd || !file) {
    showToast("Vui lòng chọn file và nhập mật khẩu!", true);
    return;
  }

  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      let success = 0, skipped = 0;
      const currentOriginals = rawDataCache
        ? Object.values(rawDataCache).map((v) => v.original).filter(Boolean)
        : [];

      for (const key of Object.keys(imported)) {
        const item = imported[key];
        const decrypted = CryptoJS.AES.decrypt(item.original, pwd).toString(CryptoJS.enc.Utf8);
        if (!decrypted) continue;

        let isDup = false;
        for (let i = 0; i < currentOriginals.length; i++) {
          if (calculateSimilarityFast(decrypted, currentOriginals[i], 0.68) > 0.68) {
            isDup = true;
            break;
          }
        }

        if (!isDup) {
          const md5Key = item.hashedKey || CryptoJS.MD5(decrypted).toString();
          await set(ref(db, `${NODE_ANALYSIS}/users/${currentUser.uid}/data/${md5Key}`), {
            ...item,
            sha512: item.sha512 || CryptoJS.SHA512(decrypted).toString(),
            original: decrypted,
            deviceInfo: item.deviceInfo || currentDevice,
            timeVN: item.timeVN || getTime("VN"),
            timeKR: item.timeKR || getTime("KR"),
            timeCN: item.timeCN || getTime("CN"),
            timeJP: item.timeJP || getTime("JP")
          });
          currentOriginals.push(decrypted);
          success++;
        } else {
          skipped++;
        }
      }

      showToast(
        `Nhập thành công ${success} bản ghi` +
        (skipped ? ` (Bỏ qua ${skipped} bản trùng >68%)` : "")
      );
      hideModal("import-modal");
      $("#file-input").value = "";
      $("#file-label").innerHTML = '<i class="fas fa-cloud-upload-alt"></i><span>Chọn file JSON để nhập</span>';
    } catch {
      showToast("Lỗi giải mã hoặc tệp tin bị hỏng!", true);
    }
  };
  reader.readAsText(file);
}

// ========== HEALTH LOGIC ==========
function setDatetimeToNow() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  $("#custom-datetime").value = now.toISOString().slice(0, 16);
}

async function addHealthLog() {
  if (!currentUser) return;

  const selectedValue = $("#custom-datetime").value;
  if (!selectedValue) {
    showToast("Vui lòng chọn thời gian hợp lệ!", true);
    return;
  }

  const timestamp = new Date(selectedValue).getTime();

  try {
    const logsListRef = ref(db, `${NODE_HEALTH}/users/${currentUser.uid}/logs`);
    const newLogRef = push(logsListRef);

    await set(newLogRef, {
      timestamp,
      createdAt: new Date(timestamp).toISOString()
    });

    showToast("Lưu mốc thời gian thành công!");
    setDatetimeToNow();
  } catch (err) {
    showToast("Không thể ghi dữ liệu: " + err.message, true);
  }
}

function listenToHealthLogs(userId) {
  const userLogsRef = ref(db, `${NODE_HEALTH}/users/${userId}/logs`);

  onValue(userLogsRef, (snapshot) => {
    const data = snapshot.val();
    const logs = [];

    if (data) {
      Object.keys(data).forEach((key) => {
        logs.push({ id: key, ...data[key] });
      });
      logs.sort((a, b) => b.timestamp - a.timestamp);
    }

    renderHealthLogs(logs, userId);
  }, (error) => {
    showToast("Không thể tải dữ liệu health: " + error.message, true);
  });
}

function renderHealthLogs(logs, userId) {
  $("#stat-total").textContent = logs.length;
  const container = $("#logs-container");

  if (logs.length === 0) {
    $("#stat-last-time").textContent = "Chưa có dữ liệu";
    container.innerHTML = `
      <div class="empty-text">
        Chưa có bản ghi nào. Hãy lưu mốc thời gian đầu tiên.
      </div>`;
    return;
  }

  const latestLog = logs[0];
  if (latestLog.timestamp) {
    $("#stat-last-time").textContent = new Date(latestLog.timestamp).toLocaleString("vi-VN");
  }

  container.innerHTML = logs.map((log) => {
    const dateStr = log.timestamp
      ? new Date(log.timestamp).toLocaleString("vi-VN", { dateStyle: "full", timeStyle: "medium" })
      : "Không xác định";

    return `
      <div class="log-item">
        <div class="log-left">
          <div class="log-icon"><i class="fas fa-activity"></i></div>
          <span class="log-date">${dateStr}</span>
        </div>
        <button class="btn-delete-log" data-log-id="${log.id}" title="Xóa">
          <i class="fas fa-trash-2"></i>
        </button>
      </div>
    `;
  }).join("");

  // Bind delete
  container.querySelectorAll("[data-log-id]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (confirm("Bạn có chắc chắn muốn xóa bản ghi thời gian này?")) {
        try {
          await remove(ref(db, `${NODE_HEALTH}/users/${userId}/logs/${btn.dataset.logId}`));
          showToast("Đã xóa bản ghi thành công!");
        } catch (err) {
          showToast("Lỗi khi xóa: " + err.message, true);
        }
      }
    });
  });
}

// ========== AUTH STATE ==========
function listenToAnalysisData(userId) {
  onValue(ref(db, `${NODE_ANALYSIS}/users/${userId}/data`), (snapshot) => {
    rawDataCache = snapshot.exists() ? snapshot.val() : null;
    allDataArray = rawDataCache
      ? Object.entries(rawDataCache).map(([key, val]) => ({ key, ...val }))
      : [];
    $("#data-count").textContent = allDataArray.length;
    applyFilterAndRender();
  });
}

onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    $("#auth-section").classList.add("hidden");
    $("#app-layout").classList.remove("hidden");

    const displayName = user.displayName || user.email.split("@")[0];
    $("#user-name").textContent = displayName;
    $("#user-email").textContent = user.email;
    $("#user-avatar").src = user.photoURL || DEFAULT_AVATAR;

    listenToAnalysisData(user.uid);
    listenToHealthLogs(user.uid);
  } else {
    currentUser = null;
    rawDataCache = null;
    allDataArray = [];
    $("#auth-section").classList.remove("hidden");
    $("#app-layout").classList.add("hidden");
  }
});

// ========== EVENT BINDINGS ==========
function initEvents() {
  // Auth
  $("#btn-toggle-auth").addEventListener("click", toggleAuthMode);
  $("#auth-form").addEventListener("submit", handleEmailAuth);
  $("#btn-google").addEventListener("click", handleGoogleLogin);
  $("#btn-logout").addEventListener("click", () => signOut(auth));

  // Sidebar / Nav
  $("#btn-menu").addEventListener("click", openSidebar);
  $("#btn-sidebar-close").addEventListener("click", closeSidebar);
  $("#sidebar-overlay").addEventListener("click", closeSidebar);

  $$(".nav-item").forEach((el) => {
    el.addEventListener("click", () => switchTab(el.dataset.tab));
  });
  $$(".bottom-nav-item").forEach((el) => {
    el.addEventListener("click", () => switchTab(el.dataset.tab));
  });

  // Analysis
  $("#btn-add-data").addEventListener("click", addAnalysisData);
  $("#data-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") addAnalysisData();
  });
  $("#search-input").addEventListener("input", () => {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
      currentPage = 1;
      applyFilterAndRender();
    }, 150);
  });
  $("#btn-prev").addEventListener("click", () => {
    currentPage--;
    renderAnalysisPage();
  });
  $("#btn-next").addEventListener("click", () => {
    currentPage++;
    renderAnalysisPage();
  });

  // File label
  $("#file-input").addEventListener("change", (e) => {
    const label = $("#file-label");
    if (e.target.files && e.target.files[0]) {
      label.innerHTML = `<i class="fas fa-file-code"></i><span>${e.target.files[0].name}</span>`;
    } else {
      label.innerHTML = '<i class="fas fa-cloud-upload-alt"></i><span>Chọn file JSON để nhập</span>';
    }
  });

  // Modals
  $("#btn-backup").addEventListener("click", () => showModal("backup-modal"));
  $("#btn-import").addEventListener("click", () => showModal("import-modal"));
  $("#btn-cancel-backup").addEventListener("click", () => hideModal("backup-modal"));
  $("#btn-cancel-import").addEventListener("click", () => hideModal("import-modal"));
  $("#btn-confirm-backup").addEventListener("click", performBackup);
  $("#btn-confirm-import").addEventListener("click", performImport);

  // Close modal on backdrop
  $$(".modal").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) hideModal(modal.id);
    });
  });

  // Health
  setDatetimeToNow();
  $("#btn-set-now").addEventListener("click", setDatetimeToNow);
  $("#btn-add-log").addEventListener("click", addHealthLog);
}

// ========== INIT ==========
initDeviceInfo();
initEvents();
