<?php
// Gửi mã phản hồi HTTP 404 để thông báo cho trình duyệt và SEO
http_response_code(404);

// Cấu hình các thông tin cơ bản
$site_name = "Tên Website Của Bạn";
$home_url = "/"; // Đường dẫn về trang chủ
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Không Tìm Thấy Trang | <?php echo $site_name; ?></title>
    <link href="https://googleapis.com" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
            color: #ffffff;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            text-align: center;
        }
        .container {
            max-width: 600px;
            padding: 2rem;
            z-index: 10;
        }
        .error-code {
            font-size: 10rem;
            font-weight: 800;
            line-height: 1;
            background: linear-gradient(to right, #38bdf8, #818cf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
            animation: float 6s ease-in-out infinite;
        }
        .error-title {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #f1f5f9;
        }
        .error-message {
            font-size: 1rem;
            color: #94a3b8;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        .search-box {
            margin-bottom: 2rem;
        }
        .search-box input {
            width: 70%;
            padding: 0.8rem 1.2rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50px 0 0 50px;
            color: #fff;
            outline: none;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        .search-box input:focus {
            background: rgba(255, 255, 255, 0.1);
            border-color: #38bdf8;
        }
        .search-box button {
            width: 25%;
            padding: 0.8rem 1.2rem;
            border: none;
            background: linear-gradient(to right, #38bdf8, #6366f1);
            color: #fff;
            font-weight: 600;
            border-radius: 0 50px 50px 0;
            cursor: pointer;
            font-size: 1rem;
            transition: opacity 0.3s ease;
        }
        .search-box button:hover {
            opacity: 0.9;
        }
        .btn-home {
            display: inline-block;
            padding: 0.8rem 2rem;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }
        .btn-home:hover {
            background: #fff;
            color: #0f172a;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .countdown {
            margin-top: 2rem;
            font-size: 0.85rem;
            color: #64748b;
        }
        #seconds {
            color: #38bdf8;
            font-weight: 600;
        }
        /* Hiệu ứng trôi nổi cho số 404 */
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        /* Các hạt bụi mờ ảo phía sau */
        .background-glow {
            position: absolute;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, rgba(0,0,0,0) 70%);
            top: 20%;
            left: 20%;
            z-index: 1;
            animation: pulse 8s ease-in-out infinite alternate;
        }
        .background-glow-2 {
            position: absolute;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(99, 102, 241, 0.15) 0%, rgba(0,0,0,0) 70%);
            bottom: 20%;
            right: 20%;
            z-index: 1;
            animation: pulse 10s ease-in-out infinite alternate-reverse;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            100% { transform: scale(1.2); }
        }
    </style>
</head>
<body>

    <div class="background-glow"></div>
    <div class="background-glow-2"></div>

    <div class="container">
        <div class="error-code">404</div>
        <h1 class="error-title">Hình như bạn đang lạc đường?</h1>
        <p class="error-message">
            Trang bạn đang tìm kiếm không tồn tại hoặc đã bị di chuyển sang một địa chỉ khác. 
            Thử tìm kiếm nội dung khác bên dưới hoặc quay lại trang chủ nhé!
        </p>

        <!-- Thanh tìm kiếm tích hợp sẵn -->
        <form class="search-box" action="<?php echo $home_url; ?>" method="GET">
            <input type="text" name="s" placeholder="Tìm kiếm nội dung..." required>
            <button type="submit">Tìm kiếm</button>
        </form>

        <a href="<?php echo $home_url; ?>" class="btn-home">Quay Lại Trang Chủ</a>

        <div class="countdown">
            Tự động chuyển hướng về trang chủ sau <span id="seconds">15</span> giây...
        </div>
    </div>

    <script>
        // Xử lý đếm ngược và tự động chuyển hướng
        let seconds = 15;
        const countdownElement = document.getElementById('seconds');
        const homeUrl = "<?php echo $home_url; ?>";

        const interval = setInterval(() => {
            seconds--;
            countdownElement.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(interval);
                window.location.href = homeUrl;
            }
        }, 1000);
    </script>
</body>
</html>
